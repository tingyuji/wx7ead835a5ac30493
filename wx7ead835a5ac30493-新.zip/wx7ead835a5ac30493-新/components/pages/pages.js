Component({
    properties: {
        pageCount: {
            type: Number,
            value: 0
        },
        page: {
            type: Number,
            value: 0,
            observer: function(e, t) {
                this.setData({
                    page: e
                });
            }
        }
    },
    data: {},
    methods: {
        getPageBtn: function(e) {
            var t = e.currentTarget.dataset.page;
            this.triggerEvent("pageBtn", {
                page: t
            });
        }
    }
});