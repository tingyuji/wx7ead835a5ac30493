var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), i = require("../../../utils/common"), s = require("../../../utils/requestData"), o = new i.Common(), n = new s.requestData();

Component({
    properties: {
        item: {
            type: Object,
            value: {},
            observer: function(e) {
                this.setData({
                    item: e
                });
            }
        },
        style: {
            type: String,
            value: "",
            observer: function(e) {
                this.setData({
                    style: e
                });
            }
        },
        checkBoxState: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                e && this.closeRight(), this.setData({
                    checkBoxState: e
                });
            }
        }
    },
    data: {
        isCellOpened: !1
    },
    methods: {
        onActionClick: function(e) {
            var t = e.detail;
            wx.showToast({
                title: "你点击了".concat(t.text),
                icon: "none"
            });
        },
        onDelete: function() {
            var e = wx.getStorageSync("loginResData").data.user, t = null;
            if (o.isExampleChild(this.data.item.childid) && this.data.item.recorder != e.id) return t = "当前是演示记录，不能删除", 
            o.showmsg(t), void this.closeRight();
            if (this.data.item.recorder != e.id) {
                var i = o.findOtherMember(e.otherMembers, this.data.item.recorder), s = i.notes ? "(" + i.notes + ")" : "";
                return t = "该条记录由【" + i.users.nickname + s + "】添加，您无权删除！", o.showmsg(t), void this.closeRight();
            }
            this.delScoresConfirm(this.data.item.id);
        },
        delScoresConfirm: function(i) {
            var s, a = this;
            wx.showModal({
                title: "提示",
                content: "确定要删除该条记录吗？",
                complete: (s = t(e().mark(function t(s) {
                    var r;
                    return e().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (!s.confirm) {
                                e.next = 6;
                                break;
                            }
                            return e.next = 3, n.mainDataReq({
                                delScoresid: i
                            }, "delScoresRecord");

                          case 3:
                            0 == (r = e.sent).data.code && a.triggerEvent("delSuccess", {
                                scoresid: a.data.item.id
                            }), o.showmsg(r.data.msg.title, r.data.msg.icon);

                          case 6:
                          case "end":
                            return e.stop();
                        }
                    }, t);
                })), function(e) {
                    return s.apply(this, arguments);
                })
            });
        },
        onEdit: function() {
            wx.showToast({
                title: "你点击了编辑",
                icon: "none"
            }), this.triggerEvent("onEdit", {
                scoresid: this.data.item.id
            }), this.closeRight();
        },
        onFavor: function() {
            wx.showToast({
                title: "你点击了收藏",
                icon: "none"
            });
        },
        onChoice: function() {
            wx.showToast({
                title: "你点击了选择",
                icon: "none"
            }), this.closeRight();
        },
        click: function(e) {
            this.closeRight();
        },
        closeRight: function() {
            this.selectComponent("#swipe-cell").close();
        },
        openSuccess: function(e) {
            this.setData({
                isCellOpened: !0
            });
        },
        closeSuccess: function(e) {
            this.setData({
                isCellOpened: !1
            });
        },
        handleCellChange: function(e) {
            this.setData({
                isCellOpened: e.detail.opened
            });
        },
        showScoresDetail: function() {
            this.data.isCellOpened || this.data.checkBoxState ? this.closeRight() : this.triggerEvent("showScoresDetail", {
                scoresId: this.data.item.id
            });
        }
    }
});