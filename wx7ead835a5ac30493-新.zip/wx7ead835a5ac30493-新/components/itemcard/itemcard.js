var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../utils/requestData"), a = require("../../utils/common"), n = new r.requestData(), o = new a.Common();

Component({
    properties: {
        index: {
            type: Number,
            value: null
        },
        childSex: {
            type: Number,
            value: null
        },
        isCurrentUser: {
            type: Boolean,
            value: !0
        },
        currentUserid: {
            type: Number,
            value: null
        },
        safeCode: {
            type: Boolean,
            value: !1,
            observer: function(e, t) {
                console.log(e), this.setData({
                    safeCode: e
                });
            }
        },
        showDelBtn: {
            type: Boolean,
            value: !1
        },
        childInfo: {
            type: Object,
            value: {},
            observer: function(e, t) {
                this.setData({
                    childInfo: e
                });
            }
        }
    },
    data: {
        app: getApp()
    },
    methods: {
        changeChild: function(e) {},
        goPage: function(e) {
            wx.navigateTo({
                url: e.currentTarget.dataset.url
            });
        },
        delBtn: function(e) {
            var t = e.currentTarget.dataset.childid;
            if (o.isExampleChild(t)) return wx.showToast({
                title: "系统示例，不能删除",
                icon: "none"
            }), void this.setData({
                showDelBtn: !1
            });
            this.setData({
                delchildid: t
            }), this.delPrompt(t);
        },
        delPrompt: function(r) {
            var a = this;
            return t(e().mark(function t() {
                var r, n, i, s, c, l;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (r = a, n = a.data.delchildid, i = o.findChild(n), s = wx.getStorageSync("loginResData"), 
                        c = s.data.user, l = "确定要删除 " + i.nickname + " 吗？", i.creator == c.id || i.user_id == c.id) {
                            e.next = 11;
                            break;
                        }
                        return wx.showModal({
                            title: "提示",
                            content: "当前孩子信息是由【" + i.creatorUser.nickname + "】创建,您不能删除！",
                            confirmText: "好的",
                            showCancel: !1
                        }), e.abrupt("return");

                      case 11:
                        i.creator == c.id && i.user_id != c.id ? l = "当前孩子信息是在【" + i.users.nickname + "】账号下,您确定要删除吗？" : i.creator != c.id && i.user_id == c.id && (l = "当前孩子信息是由【" + i.creatorUser.nickname + "】创建,您确定要删除吗？");

                      case 12:
                        wx.showModal({
                            title: "提示",
                            content: l,
                            complete: function(e) {
                                e.confirm && (r.data.safeCode ? r.selectComponent("#checkSafecodeBox").show() : r.confirmDel(n));
                            }
                        }), a.selectComponent("#checkSafecodeBox").close();

                      case 15:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        confirmDel: function(r) {
            var a = this;
            return t(e().mark(function t() {
                var i;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, n.mainDataReq({
                            delchildid: r
                        }, "delchild", !0);

                      case 2:
                        0 == (i = e.sent).data.code && (o.delLocalChild(r), a.triggerEvent("delsuceess")), 
                        o.showmsg(i.data.msg.title, i.data.msg.icon);

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        safeCodeCheckSuceessCallback: function() {
            var e = this.data.delchildid;
            this.confirmDel(e);
        }
    }
});