Component({
    properties: {
        moveX: {
            type: Boolean,
            value: !0
        },
        moveY: {
            type: Boolean,
            value: !0
        },
        right: {
            type: String,
            value: 0
        },
        bottom: {
            type: String,
            value: 0
        },
        opacity: {
            type: Number,
            value: .65
        }
    },
    data: {
        startX: 0,
        startY: 0
    },
    methods: {
        handleTouchStart: function(t) {
            this.data.startX = t.touches[0].clientX, this.data.startY = 0 - t.touches[0].clientY;
        },
        handleTouchMove: function(t) {
            var a = 0, e = 0;
            this.data.moveX && (a = t.touches[0].clientX - this.data.startX), this.data.moveY && (e = 0 - t.touches[0].clientY - this.data.startY), 
            this.setData({
                right: parseInt(this.data.right) - a,
                bottom: parseInt(this.data.bottom) + e
            }), this.data.startX = t.touches[0].clientX, this.data.startY = 0 - t.touches[0].clientY;
        },
        handleTouchEnd: function() {
            this.triggerEvent("handleTouchEnd", {
                right: this.data.right,
                bottom: this.data.bottom
            });
        }
    }
});