var a = getApp();

Component({
    properties: {
        colorTheme: {
            type: String,
            value: ""
        },
        showGoBack: {
            type: Boolean,
            value: !0
        },
        topTitle: {
            type: String,
            value: "顶部标题"
        }
    },
    data: {
        isShowNavbar: !0,
        isShowCapsule: !0,
        CustomBar: a.globalData.CustomBar
    },
    options: {
        styleIsolation: "apply-shared"
    },
    attached: function() {
        var a = getCurrentPages(), e = a[a.length - 1];
        "Windows" == getApp().globalData.model && (console.log(getApp().globalData.model), 
        this.setData({
            isShowNavbar: !1
        })), "pages/index/index" == e.route && this.setData({
            isShowCapsule: !1
        }), a.length <= 1 && this.setData({
            showGoBack: !1
        });
    },
    methods: {
        handleBack: function() {
            wx.navigateBack();
        },
        onGoHome: function() {
            wx.reLaunch({
                url: "/pages/index/index"
            });
        }
    }
});