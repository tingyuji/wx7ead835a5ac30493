Component({
    properties: {
        title_Left_Btn: {
            type: Boolean,
            value: !1
        },
        title_Left_Btntxt: {
            type: String,
            value: ""
        },
        title: {
            type: String,
            value: "提示"
        },
        onVisibleChange: {
            type: Boolean,
            value: !1
        },
        width: {
            type: String,
            value: "92vw"
        },
        placement: {
            type: String,
            value: null
        },
        needvip: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        cur: {}
    },
    methods: {
        titleLbtn: function(t) {
            this.triggerEvent("title_Left_Btntxt_Click", {
                data: t
            });
        },
        handlePopup: function() {
            this.setData({
                visible: !0
            });
        },
        close: function() {
            this.setData({
                visible: !1,
                needvip: !1
            }), this.triggerEvent("popupCloseCallback");
        },
        onVisibleChange: function(t) {
            this.setData({
                visible: t.detail.visible
            }), this.triggerEvent("popupCloseCallback");
        }
    }
});