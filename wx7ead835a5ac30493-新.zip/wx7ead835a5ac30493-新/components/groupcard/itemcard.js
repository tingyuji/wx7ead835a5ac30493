var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../utils/requestData"), n = require("../../utils/common"), a = new r.requestData(), o = new n.Common();

Component({
    properties: {
        showDelBtn: {
            type: Boolean,
            value: !1
        },
        childInfo: {
            type: Object,
            value: {},
            observer: function(e, t) {
                this.setData({
                    childInfo: e
                });
            }
        }
    },
    data: {
        app: getApp()
    },
    methods: {
        changeChild: function(e) {
            console.log(e);
        },
        goPage: function(e) {
            wx.navigateTo({
                url: e.currentTarget.dataset.url
            }), console.log(e);
        },
        delBtn: function(r) {
            var n, a = this, i = r.currentTarget.dataset.childid, s = r.currentTarget.dataset.nickname;
            wx.showModal({
                title: "提示",
                content: "确定要删除【" + s + "】吗？",
                complete: (n = t(e().mark(function t(r) {
                    var n;
                    return e().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (!r.confirm) {
                                e.next = 5;
                                break;
                            }
                            return e.next = 3, a.delChild(i);

                          case 3:
                            n = e.sent, o._showMsg(n.data.msg);

                          case 5:
                          case "end":
                            return e.stop();
                        }
                    }, t);
                })), function(e) {
                    return n.apply(this, arguments);
                })
            }), console.log(i);
        },
        delChild: function(r) {
            var n = this;
            return t(e().mark(function t() {
                var i;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, a.mainDataReq({
                            childid: r
                        }, "delchild", !0);

                      case 2:
                        return 0 == (i = e.sent).data.code && (o.delLocalChild(r), n.triggerEvent("delsuceess")), 
                        e.abrupt("return", i);

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    }
});