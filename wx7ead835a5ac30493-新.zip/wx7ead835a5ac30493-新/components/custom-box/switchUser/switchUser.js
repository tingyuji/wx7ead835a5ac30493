var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), s = new (require("../../../utils/requestData").requestData)();

Component({
    properties: {
        currentUser: {
            type: Object,
            value: [],
            observer: function(e, t) {
                this.setData({
                    currentUser: e
                });
            }
        },
        parentUsersList: {
            type: Object,
            value: []
        }
    },
    data: {
        app: getApp()
    },
    methods: {
        switchUser: function(e) {
            var t = e.detail.value;
            t != this.data.lastParentUserid ? this.switchUserDo(t) : this.close();
        },
        switchUserDo: function(r) {
            var a = this;
            return t(e().mark(function t() {
                var i;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, s.mainDataReq({
                            parentUserid: r
                        }, "switchUser");

                      case 2:
                        (i = e.sent).data.state ? a.triggerEvent("success", {
                            parentUserid: r,
                            childsList: i.data.childsList
                        }) : wx.showModal({
                            title: "提示",
                            content: i.data.msg.title,
                            confirmText: "关闭",
                            showCancel: !1
                        }), a.close();

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        show: function() {
            this.setData({
                visible: !0
            });
        },
        close: function() {
            this.setData({
                visible: !1
            });
        }
    }
});