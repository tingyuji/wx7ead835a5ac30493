var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../../utils/common"), a = require("../../../utils/requestData"), n = new r.Common(), s = new a.requestData();

Component({
    properties: {
        lotteryPrizes: {
            type: Object,
            value: {}
        },
        editprizes: {
            type: Object,
            value: {}
        },
        dotype: {
            type: String,
            value: "addnewPrizes"
        }
    },
    data: {},
    methods: {
        addSubmit: function(r) {
            var a = this;
            return t(e().mark(function t() {
                var i, u, o, d;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (i = r.detail.value.prizesname, u = r.detail.value.range, console.log(u), 0 != u && n.isIntegerInVariable(u) && "" !== u && !(n.strlen(i) <= 0)) {
                            e.next = 5;
                            break;
                        }
                        return e.abrupt("return");

                      case 5:
                        return o = {
                            prizesname: i,
                            range: u
                        }, e.next = 8, s.mainDataReq(o, "addLotteryPrizes");

                      case 8:
                        0 === (d = e.sent).data.code ? (a.triggerEvent("success", {
                            lotteryPrizes: d.data.lotteryPrizes
                        }), n._showMsg(d.data.msg)) : n.vipshowmsg(d.data.msg.title, "none", 0);

                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        editSubmit: function(r) {
            var a = this;
            return t(e().mark(function t() {
                var i, u, o, d, l, c;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (console.log(a.data), !a.data.lotteryPrizes.isDefault) {
                            e.next = 4;
                            break;
                        }
                        return n.showmsg("当前是系统示例，不能修改！请新增自己的奖品！"), e.abrupt("return");

                      case 4:
                        if (i = a, u = r.detail.value.prizesname, 0 != (o = r.detail.value.range) && n.isIntegerInVariable(o) && "" !== o && !(n.strlen(o) <= 0) && "" != u) {
                            e.next = 9;
                            break;
                        }
                        return e.abrupt("return");

                      case 9:
                        if (o = Number(o), d = {
                            prizesname: u,
                            range: o,
                            id: a.data.editprizes.id
                        }, l = a.data.lotteryPrizes.list.find(function(e) {
                            return e.id === i.data.editprizes.id;
                        }), u != l.prizesname || o != l.range) {
                            e.next = 14;
                            break;
                        }
                        return e.abrupt("return");

                      case 14:
                        return e.next = 16, s.mainDataReq(d, "editLotteryPrizes");

                      case 16:
                        0 === (c = e.sent).data.code && a.triggerEvent("success", {
                            lotteryPrizes: c.data.lotteryPrizes
                        }), n._showMsg(c.data.msg);

                      case 19:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    }
});