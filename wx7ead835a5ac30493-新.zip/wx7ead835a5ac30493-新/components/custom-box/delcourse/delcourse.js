var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../../utils/common"), a = require("../../../utils/requestData"), n = new r.Common(), i = new a.requestData();

Component({
    properties: {
        childid: {
            type: Number,
            value: null
        },
        couresList: {
            type: Object,
            value: null
        }
    },
    data: {
        checkedValueList: []
    },
    methods: {
        onChange: function(e) {
            this.setData({
                checkedValueList: e.detail.value
            }), console.log(this.data);
        },
        delCourseBtn: function(r) {
            var a = this;
            return t(e().mark(function t() {
                var r, s, u, o;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (r = a.data.checkedValueList, console.log(r), !(r.length <= 0)) {
                            e.next = 5;
                            break;
                        }
                        return wx.showToast({
                            title: "请先选择科目",
                            icon: "error"
                        }), e.abrupt("return");

                      case 5:
                        if (s = a.data.childid, !n.isExampleChild(s)) {
                            e.next = 12;
                            break;
                        }
                        return a, wx.showModal({
                            title: "提示",
                            content: "当前是示例，不能删除。请先在首页创建孩子信息！",
                            confirmText: "去创建",
                            cancelText: "看看再说",
                            complete: function(e) {
                                e.confirm && wx.reLaunch({
                                    url: "/pages/index/index"
                                });
                            }
                        }), e.abrupt("return");

                      case 12:
                        return e.next = 14, i.mainDataReq({
                            delCourseidList: r,
                            childid: s
                        }, "batchDelCourse");

                      case 14:
                        0 == (u = e.sent).data.code && (o = u.data.list, a.triggerEvent("success", {
                            list: o
                        })), n.showmsg(u.data.msg.title, u.data.msg.icon);

                      case 17:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    }
});