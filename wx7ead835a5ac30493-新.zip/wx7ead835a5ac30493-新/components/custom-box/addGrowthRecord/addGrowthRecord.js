var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../../utils/common"), a = require("../../../utils/requestData"), i = new r.Common(), n = new a.requestData();

Component({
    properties: {
        childid: {
            type: Number,
            value: 0
        },
        weightValue: {
            type: String,
            value: null
        },
        heightValue: {
            type: String,
            value: null
        }
    },
    data: {},
    methods: {
        testInput: function(e) {
            return !!/^(0|[1-9]\d{0,2}|[12]\d{2})(\.\d{1,2})?$/.test(e);
        },
        addGrowthRecordBtn: function(e) {
            var t = "", r = e.detail.value.height, a = e.detail.value.weight, n = e.detail.value.notes;
            return this.testInput(r) ? this.testInput(a) ? void this.addGrowthRecord(r, a, n) : (t = "体重数值不正确", 
            void i.showmsg(t)) : (t = "身高数值不正确", void i.showmsg(t));
        },
        addGrowthRecord: function(r, a, s) {
            var u = this;
            return t(e().mark(function t() {
                var o, d;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return o = u.data.childid, e.next = 3, n.mainDataReq({
                            height: r,
                            weight: a,
                            notes: s,
                            child_id: o
                        }, "addGrowthRecord");

                      case 3:
                        0 == (d = e.sent).data.code && u.triggerEvent("success"), i.showmsg(d.data.msg.title, d.data.msg.icon);

                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    }
});