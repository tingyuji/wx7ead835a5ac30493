var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../../utils/requestData"), n = require("../../../utils/common"), a = new r.requestData(), o = new n.Common();

Component({
    properties: {
        oldLotteryPoints: {
            type: Number,
            value: 0
        },
        newLotteryPionts: {
            type: Number,
            value: 0
        },
        lotteryPionts: {
            type: Number,
            value: 0
        }
    },
    data: {},
    methods: {
        lotteryPiontsChange: function(e) {
            var t = e.detail.value;
            this.setData({
                newLotteryPionts: t
            });
        },
        saveBtn: function(r) {
            var n = this;
            return t(e().mark(function t() {
                var r, s;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if ((r = n.data.newLotteryPionts) != n.data.lotterypoints) {
                            e.next = 5;
                            break;
                        }
                        return e.abrupt("return");

                      case 5:
                        return e.next = 7, a.mainDataReq({
                            value: n.data.newLotteryPionts
                        }, "saveLotteryPionts");

                      case 7:
                        0 == (s = e.sent).data.code && n.triggerEvent("suceess", {
                            newLotteryPoints: r
                        }), o._showMsg(s.data.msg);

                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    }
});