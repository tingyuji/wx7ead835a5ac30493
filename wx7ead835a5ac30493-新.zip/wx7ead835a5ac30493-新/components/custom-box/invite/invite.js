var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../../@babel/runtime/helpers/asyncToGenerator"), t = require("../../../utils/requestData"), n = require("../../../utils/common"), a = new t.requestData(), s = new n.Common();

Component({
    properties: {},
    data: {},
    methods: {
        otherUseridChange: function(e) {
            var r = e.detail.value;
            this.setData({
                otherUserid: r
            });
        },
        sendBtn: function(t) {
            var n = this;
            return r(e().mark(function r() {
                var t;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, a.mainDataReq({
                            toUseridcode: n.data.otherUserid
                        }, "sendInvite");

                      case 2:
                        t = e.sent, s._showMsg(t.data.msg);

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, r);
            }))();
        }
    }
});