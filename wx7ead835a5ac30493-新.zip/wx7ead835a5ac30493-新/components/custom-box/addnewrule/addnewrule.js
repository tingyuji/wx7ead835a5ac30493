var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../../@babel/runtime/helpers/defineProperty"), l = new (require("../../../utils/requestData").requestData)();

Component({
    observers: {
        ruleInfo: function(e) {
            console.log(e);
            var t = !1, a = !1;
            null != e && (t = e.public > 0, a = e.default > 0), this.setData({
                switchVal_isPublic: t,
                switchVal_isDefault: a
            });
        }
    },
    properties: {
        ruleInfo: {
            type: Object,
            value: null
        }
    },
    data: {
        switchVal_isPublic: !1,
        switchVal_isDefault: !1,
        isDisabled: !1,
        value: ""
    },
    methods: {
        changeNewRulename: function(e) {
            var t = e.detail.value;
            this.setData({
                value: t
            });
        },
        switchHandleChange: function(e) {
            var t = e.currentTarget.dataset.target;
            this.setData(a(a({}, "ruleInfo.".concat(t), e.detail.value), "switchVal_".concat(t), e.detail.value));
        },
        addNewRuleBtn: function(a) {
            return t(e().mark(function t() {
                var u, i, r, n;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (a.detail.value.editRulename) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return");

                      case 2:
                        return u = {
                            rulename: a.detail.value.editRulename,
                            isPublic: a.detail.value.isPublic ? 1 : 0,
                            isDefault: a.detail.value.isDefault ? 1 : 0,
                            desc: a.detail.value.desc
                        }, e.next = 5, l.mainDataReq(u, "addNewRule");

                      case 5:
                        (i = e.sent).data.state && (r = getCurrentPages(), (n = r[r.length - 1]).setData({
                            ruleList: i.data.list
                        }), n.popup.close()), wx.showToast({
                            title: i.data.msg.title,
                            icon: i.data.msg.icon
                        });

                      case 8:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        editRuleBtn: function(u) {
            var i = this;
            return t(e().mark(function t() {
                var r, n, s, c;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (console.log(u), 1001 != i.data.ruleInfo.create_userid) {
                            e.next = 5;
                            break;
                        }
                        return i.data.popup.close(), wx.showModal({
                            title: "提示",
                            content: "这是系统默认规则作为演示用，不能修改！"
                        }), e.abrupt("return");

                      case 5:
                        return r = {
                            ruleid: i.data.ruleInfo.id,
                            rulename: u.detail.value.editRulename,
                            ruledesc: u.detail.value.desc,
                            isPublic: u.detail.value.isPublic ? 1 : 0,
                            isDefault: u.detail.value.isDefault ? 1 : 0
                        }, e.next = 8, l.mainDataReq(r, "editRuleinfo");

                      case 8:
                        n = e.sent, console.log(n), n.data.state && (s = getCurrentPages(), (c = s[s.length - 1]).popup.close(), 
                        c.setData(a(a(a(a({}, "rule.info.rulename", r.rulename), "rule.info.public", r.isPublic), "rule.info.default", r.isDefault), "rule.info.desc", r.ruledesc))), 
                        wx.showToast({
                            title: n.data.msg.title,
                            icon: n.data.msg.icon
                        });

                      case 12:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    }
});