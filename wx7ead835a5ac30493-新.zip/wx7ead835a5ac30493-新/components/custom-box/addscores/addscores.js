var e = require("../../../@babel/runtime/helpers/defineProperty"), a = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../../utils/requestData"), s = require("../../../utils/common"), n = new r.requestData(), i = new s.Common();

new Date();

Component({
    properties: {
        dotype: {
            type: String,
            value: "add"
        },
        courseName: {
            type: String,
            value: ""
        },
        scoresDetail: {
            type: Object,
            value: null,
            observer: function(e) {
                var a = [], t = [];
                null !== e.piclist && e.piclist.forEach(function(e) {
                    a.push({
                        filepath: e.url,
                        fileid: e.fileid
                    }), t.push({
                        url: e.url,
                        fileid: e.fileid,
                        type: "image"
                    }), console.log(a), console.log(t);
                }), this.setData({
                    scoreFiles: a,
                    originFiles: t
                });
            }
        },
        couresid: {
            type: Number,
            value: 0
        },
        childid: {
            type: Number,
            value: null
        },
        picNumMax: {
            type: Number,
            value: 2,
            observer: function(e) {
                this.setData({
                    picNumMax: e
                });
            }
        }
    },
    data: {
        newItem: {},
        examname: "",
        scoresValue: "",
        totalScoresValue: "",
        classrankValue: "",
        graderankValue: "",
        notes: "",
        mode: "",
        dateVisible: !1,
        date: "",
        dateText: "",
        start: "",
        end: "",
        gridConfig: {
            column: 2,
            width: 120,
            height: 120
        },
        scoreFiles: [],
        formShowMore: !1
    },
    methods: {
        submit: function(e) {
            var r = this;
            return t(a().mark(function t() {
                var s, n, o, l, c, u, d, m, g, h, f, p, v, x, w, D;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (s = e.currentTarget.dataset.submittype, n = r.data.scoreFiles, o = JSON.stringify(n), 
                        l = "add" == s ? parseFloat(r.data.scoresValue) : parseFloat(r.data.scoresValue) || parseFloat(r.data.scoresDetail.scores), 
                        c = "add" == s ? parseFloat(r.data.totalScoresValue) : parseFloat(r.data.totalScoresValue) || parseFloat(r.data.scoresDetail.total_score), 
                        u = "add" == s ? r.data.classrankValue : r.data.classrankValue || r.data.scoresDetail.classrank, 
                        d = "add" == s ? r.data.graderankValue : r.data.graderankValue || r.data.scoresDetail.graderank, 
                        m = null, isNaN(c) && (c = e.detail.value.totalscores), isNaN(l) && (m = "请输入本次成绩"), 
                        g = "add" == s ? e.detail.value : e.detail.value || r.data.scoresDetail.examname, 
                        (!(h = g.examname) || h.length <= 0) && (m = "请输入考试内容"), f = e.detail.value.hasOwnProperty("notes") ? e.detail.value.notes : null, 
                        (!(p = r.data.dateText || r.data.scoresDetail.examdate).length || p.length <= 0) && (m = "请选择考试日期"), 
                        null == m) {
                            a.next = 18;
                            break;
                        }
                        return wx.showToast({
                            title: m,
                            icon: "error"
                        }), a.abrupt("return");

                      case 18:
                        if (!(l > c)) {
                            a.next = 23;
                            break;
                        }
                        return console.log(l), console.log(c), i.showmsg("输入有误：本次成绩不得大于试卷总分"), a.abrupt("return");

                      case 23:
                        v = {}, a.t0 = s, a.next = "add" === a.t0 ? 27 : "edit" === a.t0 ? 32 : 36;
                        break;

                      case 27:
                        return x = r.data.couresid, w = r.data.childid, v = {
                            notes: f,
                            childid: w,
                            couresid: x,
                            examdate: p,
                            examname: h,
                            totalScoresValue: c,
                            scoresValue: l,
                            classrankValue: u,
                            graderankValue: d,
                            pics: o
                        }, r.add(v), a.abrupt("break", 36);

                      case 32:
                        return D = r.data.scoresDetail.id, v = {
                            recordId: D,
                            notes: f,
                            examdate: p,
                            examname: h,
                            totalScoresValue: c,
                            scoresValue: l,
                            classrankValue: u,
                            graderankValue: d,
                            pics: o
                        }, r.edit(v), a.abrupt("break", 36);

                      case 36:
                      case "end":
                        return a.stop();
                    }
                }, t);
            }))();
        },
        add: function(e) {
            var r = this;
            return t(a().mark(function t() {
                var s;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return a.next = 2, n.mainDataReq(e, "addScoresRecord");

                      case 2:
                        0 == (s = a.sent).data.code && (r.setData({
                            scoresValue: null,
                            dateText: null,
                            examname: null,
                            examdate: null,
                            notes: null,
                            originFiles: []
                        }), r.triggerEvent("success", {
                            dotype: "add",
                            newitem: s.data.newitem
                        })), r.setData({
                            scoreFiles: []
                        }), i.showmsg(s.data.msg.title, s.data.msg.icon);

                      case 6:
                      case "end":
                        return a.stop();
                    }
                }, t);
            }))();
        },
        edit: function(e) {
            var r = this;
            return t(a().mark(function t() {
                var s;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return a.next = 2, n.mainDataReq(e, "editScoresRecord");

                      case 2:
                        0 == (s = a.sent).data.code && (r.setData({
                            scoresValue: null,
                            dateText: null,
                            examname: null,
                            examdate: null,
                            notes: null,
                            originFiles: []
                        }), r.triggerEvent("success", {
                            dotype: "edit",
                            newitem: s.data.newitem
                        })), r.setData({
                            scoreFiles: []
                        }), i.showmsg(s.data.msg.title, s.data.msg.icon);

                      case 6:
                      case "end":
                        return a.stop();
                    }
                }, t);
            }))();
        },
        addScoresSubmit: function(e) {
            var r = this;
            return t(a().mark(function t() {
                var s, o, l, c, u, d, m, g, h, f, p, v, x;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (s = r.data.scoreFiles, o = JSON.stringify(s), l = parseFloat(r.data.scoresValue), 
                        c = parseFloat(r.data.totalScoresValue), u = r.data.classrankValue, d = r.data.graderankValue, 
                        m = null, isNaN(c) && (c = e.detail.value.totalscores), isNaN(l) && (m = "请输入本次成绩"), 
                        (!(g = e.detail.value.examname) || g.length <= 0) && (m = "请输入考试内容"), h = e.detail.value.hasOwnProperty("notes") ? e.detail.value.notes : null, 
                        (f = r.data.dateText).length <= 0 && (m = "请选择考试日期"), null == m) {
                            a.next = 17;
                            break;
                        }
                        return wx.showToast({
                            title: m,
                            icon: "error"
                        }), a.abrupt("return");

                      case 17:
                        if (!(l > c)) {
                            a.next = 20;
                            break;
                        }
                        return i.showmsg("输入有误：本次成绩不得大于试卷总分"), a.abrupt("return");

                      case 20:
                        return p = r.data.couresid, v = r.data.childid, a.next = 24, n.mainDataReq({
                            notes: h,
                            childid: v,
                            couresid: p,
                            examdate: f,
                            examname: g,
                            totalScoresValue: c,
                            scoresValue: l,
                            classrankValue: u,
                            graderankValue: d,
                            pics: o
                        }, "addScoresRecord");

                      case 24:
                        0 == (x = a.sent).data.code && (r.setData({
                            scoresValue: null,
                            dateText: null,
                            examname: null,
                            examdate: null,
                            notes: null,
                            originFiles: []
                        }), r.triggerEvent("success", {
                            newitem: x.data.newitem
                        })), r.setData({
                            scoreFiles: []
                        }), i.showmsg(x.data.msg.title, x.data.msg.icon);

                      case 28:
                      case "end":
                        return a.stop();
                    }
                }, t);
            }))();
        },
        editScoresSubmit: function(e) {
            return t(a().mark(function t() {
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        console.log(e);

                      case 1:
                      case "end":
                        return a.stop();
                    }
                }, t);
            }))();
        },
        formShowMore: function() {
            this.setData({
                formShowMore: !this.data.formShowMore
            });
        },
        handleInput_Rank: function(a) {
            var t = a.detail.value, r = a.target.dataset.field;
            "" != t && isNaN(parseInt(t)) && (t = "", wx.showToast({
                title: "格式不正确",
                icon: "error"
            })), this.setData(e({}, "".concat(r), t));
        },
        handleInput: function(a) {
            var t = a.target.dataset.field, r = a.detail.value;
            if ("examname" == t) {
                var s = a.detail.value;
                return console.log(s), void (s.length > 6 && (s = s.substring(0, 6), this.setData({
                    examname: s
                })));
            }
            var n = a.currentTarget.dataset.decimalplaces;
            if (r && !(r <= 0)) {
                var i = 0 == n ? "^\\d+$" : "^\\d+(\\.\\d{".concat(n, "})?$"), o = new RegExp(i).test(r);
                o ? this.setData(e({}, "".concat(t), r)) : wx.showToast({
                    title: "格式不正确",
                    icon: "error"
                }), this.setData({
                    isValid: o
                });
            }
        },
        showPicker: function(a) {
            var t = a.currentTarget.dataset.mode;
            this.setData(e({
                mode: t,
                start: this.getCurrentDate(2),
                end: this.getCurrentDate(0)
            }, "".concat(t, "Visible"), !0)), console.log(this.data);
        },
        hidePicker: function() {
            var a = this.data.mode;
            this.setData(e({}, "".concat(a, "Visible"), !1));
        },
        onConfirm: function(a) {
            var t = a.detail.value, r = this.data.mode;
            console.log("confirm", t), this.setData(e(e({}, r, t), "".concat(r, "Text"), t)), 
            this.hidePicker();
        },
        onColumnChange: function(e) {
            console.log("pick", e.detail.value);
        },
        getCurrentDate: function(e) {
            e > 11 && (e = 11);
            var a = new Date(), t = new Date(a), r = t.getMonth();
            return 0 === r && (r = 11, t.setFullYear(t.getFullYear() - e)), t.setMonth(r - e), 
            this.formatDate(t);
        },
        formatDate: function(e) {
            var a = e.getFullYear(), t = ("0" + (e.getMonth() + 1)).slice(-2), r = ("0" + e.getDate()).slice(-2);
            return "".concat(a, "-").concat(t, "-").concat(r);
        },
        selectChange: function(e) {
            var r = this;
            return t(a().mark(function t() {
                var s, o, l, c, u, d, m;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        s = e.detail.currentSelectedFiles[0], o = 0;

                      case 2:
                        if (!(o < s.length)) {
                            a.next = 9;
                            break;
                        }
                        if (!(s[o].size > 2e6)) {
                            a.next = 6;
                            break;
                        }
                        return i.showmsg("上传失败：图片大小不得大于2M，原因第" + [ o + 1 ] + "张。"), a.abrupt("return");

                      case 6:
                        o++, a.next = 2;
                        break;

                      case 9:
                        if (l = wx.getStorageSync("loginResData"), !(parseInt(l.data.user.viplevel) < 2)) {
                            a.next = 13;
                            break;
                        }
                        return i.vipshowmsg("该功能需要VIP才能使用"), a.abrupt("return");

                      case 13:
                        c = e.detail.files, u = r.data.scoreFiles, wx.showLoading({
                            title: "上传中..."
                        }), d = 0;

                      case 17:
                        if (!(d < e.detail.currentSelectedFiles[0].length)) {
                            a.next = 30;
                            break;
                        }
                        return wx.showLoading({
                            title: "上传中..."
                        }), a.next = 21, n.uploadFile(e.detail.currentSelectedFiles[0][d].url, 5);

                      case 21:
                        m = a.sent, wx.hideLoading(), console.log("upfileRes", m), 0 == m.code ? (c.push(e.detail.currentSelectedFiles[0][d]), 
                        u.push(m)) : i.showmsg(m.msg), r.setData({
                            originFiles: c
                        }), console.log("originFiles", r.data.originFiles);

                      case 27:
                        d++, a.next = 17;
                        break;

                      case 30:
                        wx.hideLoading(), console.log("originFiles", r.data.originFiles), console.log("scoreFiles", r.data.scoreFiles);

                      case 33:
                      case "end":
                        return a.stop();
                    }
                }, t);
            }))();
        },
        uploadFileSuccess: function(e) {
            return t(a().mark(function e() {
                return a().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }))();
        },
        fileRemove: function(e) {
            var r = this;
            return t(a().mark(function t() {
                var s, i, o, l, c;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return s = e.detail.index, i = r.data.originFiles, o = r.data.scoreFiles, l = o[s].fileid, 
                        c = {
                            fileid: l
                        }, console.log(o), console.log(l), a.next = 9, n.mainDataReq({
                            file: JSON.stringify(c)
                        }, "delfile");

                      case 9:
                        0 == a.sent.data.code && (i.splice(s, 1), o.splice(s, 1), r.setData({
                            originFiles: i,
                            scoreFiles: o
                        }));

                      case 11:
                      case "end":
                        return a.stop();
                    }
                }, t);
            }))();
        },
        fileClick: function(e) {
            console.log(e.detail.file);
        },
        fileDrop: function(e) {
            var a = e.detail.files;
            this.setData({
                originFiles: a
            });
        },
        showPic: function(e) {
            var a = e.currentTarget.dataset.index, t = this.data.scoresDetail.piclist;
            console.log(t), wx.previewImage({
                current: t[a],
                urls: t
            }), console.log(e);
        }
    }
});