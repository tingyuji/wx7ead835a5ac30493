var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../../@babel/runtime/helpers/defineProperty"), i = require("../../../utils/common"), r = new (require("../../../utils/requestData").requestData)(), n = new i.Common();

Component({
    properties: {
        userid: a({
            type: Number
        }, "type", null)
    },
    data: {
        birthday: "",
        sex: "",
        headimg: "",
        gridConfig: {
            column: 1,
            width: 118,
            height: 118
        },
        thisPage: void 0
    },
    methods: {
        DateChange: function(e) {
            this.setData(a({}, "birthday", e.detail.value)), console.log(e);
        },
        changeSex: function(e) {
            var t = e.detail.value;
            this.setData({
                sex: t
            });
        },
        ChooseImage: function() {
            var e = this;
            console.log("ChooseImage"), wx.chooseMedia({
                count: 1,
                mediaType: [ "image" ],
                sourceType: [ "album", "camera" ],
                camera: "back",
                success: function(t) {
                    wx.cropImage({
                        src: t.tempFiles[0].tempFilePath,
                        cropScale: "1:1",
                        success: function(t) {
                            e.setData({
                                headimg: t.tempFilePath
                            }), console.log(e.data.headimg);
                        }
                    });
                },
                fail: function() {
                    console.log("fail");
                }
            });
        },
        addChildBtn: function(a) {
            var i = this;
            return t(e().mark(function t() {
                var s, o, c, d, l;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (console.log("addChildBtn"), s = a.detail.value.nickname, o = i.data.birthday, 
                        c = i.data.sex, s) {
                            e.next = 9;
                            break;
                        }
                        return wx.showToast({
                            title: "请填写名字",
                            icon: "error"
                        }), e.abrupt("return");

                      case 9:
                        if (null != c && "" != c) {
                            e.next = 12;
                            break;
                        }
                        return wx.showToast({
                            title: "请选择性别",
                            icon: "error"
                        }), e.abrupt("return");

                      case 12:
                        return d = {
                            nickname: s,
                            birthday: o,
                            sex: c
                        }, e.next = 15, r.mainDataReq(d, "addchild");

                      case 15:
                        0 === (l = e.sent).data.code && (wx.setStorageSync("childsList", l.data.list), i.triggerEvent("success", {
                            childsList: l.data.list,
                            newChildid: l.data.child_id
                        }), i.setData({
                            nickname: "",
                            birthday: "",
                            headimg: ""
                        })), 2 == l.data.code ? n.vipshowmsg(l.data.msg.title, l.data.msg.icon) : wx.showToast({
                            title: l.data.msg.title,
                            icon: l.data.msg.icon
                        });

                      case 18:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    }
});