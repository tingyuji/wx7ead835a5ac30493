var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../../utils/common"), a = require("../../../utils/requestData"), u = new r.Common(), n = new a.requestData();

Component({
    properties: {
        ruleList: {
            type: Array,
            value: null
        },
        childid: {
            type: Number,
            value: 0
        },
        userid: {
            type: Number,
            value: 0
        },
        checkedRule: {
            type: Object,
            value: null,
            observer: function(e, t) {
                this.setData({
                    checkedRule: e
                });
            }
        }
    },
    data: {},
    methods: {
        changeDefaultRule: function(r) {
            var a = this;
            return t(e().mark(function t() {
                var u, n;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        u = r.currentTarget.dataset.target, null !== a.data.checkedRule && u === a.data.checkedRule.id && (u = null), 
                        n = null, null !== u && (n = a.data.ruleList.find(function(e) {
                            return e.id === u;
                        })), a.setData({
                            checkedRule: n
                        }), a.triggerEvent("changed", {
                            checkedRuleId: u
                        });

                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        saveBtn: function() {
            var r = this;
            return t(e().mark(function t() {
                var a, i, c, d;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return a = null, r.data.checkedRule && (a = r.data.checkedRule.id), i = r.data.childid, 
                        c = r.data.userid, e.next = 6, n.mainDataReq({
                            checkedRuleId: a,
                            childid: i,
                            userid: c
                        }, "bindChildRule");

                      case 6:
                        0 == (d = e.sent).data.code ? (r.triggerEvent("Confirmed", {
                            checkedRuleId: a
                        }), u._showMsg(d.data.msg)) : 1 == d.data.code ? u._showMsg(d.data.msg) : 2 == d.data.code && u.vipshowmsg(d.data.msg.title, "error", 1);

                      case 8:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        goPage: function(e) {
            wx.navigateTo({
                url: "/pages/pointsrule/rulelist/rulelist"
            });
        }
    }
});