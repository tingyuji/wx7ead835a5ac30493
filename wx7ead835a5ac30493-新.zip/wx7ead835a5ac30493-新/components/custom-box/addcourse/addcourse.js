var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../../@babel/runtime/helpers/asyncToGenerator"), t = require("../../../utils/requestData"), r = require("../../../utils/common"), n = new t.requestData(), s = new r.Common();

Component({
    properties: {
        childid: {
            type: Number,
            value: 0
        }
    },
    data: {
        coursename: ""
    },
    methods: {
        handleInput: function(e) {
            var a = e.detail.value;
            console.log(a), a.length > 4 && (a = a.substring(0, 4)), this.setData({
                coursename: a
            });
        },
        addCourseSubmit: function(t) {
            var r = this;
            return a(e().mark(function a() {
                var t, i;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return t = r.data.coursename, e.next = 3, n.mainDataReq({
                            childid: r.data.childid,
                            coursename: t
                        }, "addCourse");

                      case 3:
                        0 == (i = e.sent).data.code && (r.setData({
                            coursename: ""
                        }), r.triggerEvent("success", {
                            coursename: t,
                            newid: i.data.newid
                        })), i.data.code < 1 ? s.showmsg(i.data.msg.title, i.data.msg.icon) : s.vipshowmsg(i.data.msg.title, i.data.msg.icon);

                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        }
    }
});