var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = getApp();

Component({
    properties: {},
    data: {
        app: a
    },
    methods: {
        clearHandle: function() {
            this.setData({
                searchResult: null
            });
        },
        changeHandle: function(e) {
            var t = e.detail.value, a = wx.getStorageSync("childsList");
            a = t ? a.filter(function(e) {
                return e.nickname.includes(t);
            }) : null, console.log(a), this.setData({
                searchValue: t,
                searchResult: a,
                radioValue: -1
            });
        },
        blurHandle: function(e) {
            this.setData({
                actionText: ""
            });
        },
        actionHandle: function() {
            this.setData({
                value: "",
                actionText: ""
            });
        },
        changeChild: function(a) {
            var n = this;
            return t(e().mark(function t() {
                var r;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if ((r = a.detail.value) != n.data.childid) {
                            e.next = 3;
                            break;
                        }
                        return e.abrupt("return");

                      case 3:
                        n.triggerEvent("success", {
                            newChildid: r
                        }), getApp().globalData.pageChildId = r;

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    }
});