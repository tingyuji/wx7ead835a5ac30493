var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../../utils/requestData"), s = require("../../../utils/common"), i = new a.requestData(), n = new s.Common();

Component({
    properties: {
        headerTitle: {
            type: String,
            value: "请输入安全码"
        },
        checkSuceessFunName: {
            type: String,
            value: null
        },
        numberLength: {
            type: Number,
            value: 4
        },
        isFocus: {
            type: Boolean,
            value: !1
        },
        firstValue: {
            type: String,
            value: ""
        },
        type: {
            type: Number,
            value: 1
        }
    },
    data: {
        tips: "该操作需要验证安全码",
        iptValue: ""
    },
    methods: {
        show: function() {
            this.setData({
                isFocus: !0,
                visible: !0
            });
        },
        close: function() {
            this.setData({
                isFocus: !1,
                visible: !1
            });
        },
        cancel: function() {
            this.close(), this.triggerEvent("cancel");
        },
        onFocus: function() {
            this.setData({
                isFocus: !0
            });
        },
        setValue: function(e) {
            var t = {
                iptValue: e.detail.value
            };
            if (this.setData(t), console.log(e.detail.value.length), console.log(this.data.numberLength), 
            e.detail.value.length >= this.data.numberLength) if (0 == this.data.type && (this.data.firstValue.length < this.data.numberLength && (this.set_firstValue(e.detail.value), 
            console.log(this.data)), this.data.firstValue.length == this.data.numberLength && this.setData({
                tips: "请再输入一遍"
            })), 1 == this.data.type) this.confirmBtn(); else if (0 == this.data.type && this.data.iptValue.length == this.data.numberLength && this.data.iptValue.length == this.data.firstValue.length) {
                if (this.data.iptValue != this.data.firstValue) return this.setData({
                    boxTitle: "设置安全码",
                    tips: "请输入6位数字",
                    isShow: !0,
                    firstValue: "",
                    iptValue: "",
                    type: 0
                }), void wx.showToast({
                    title: "两次输入不一样",
                    icon: "error"
                });
                this.confirmBtn();
            }
        },
        set_firstValue: function(e) {
            this.setData({
                firstValue: e,
                isFocus: !0,
                iptValue: ""
            });
        },
        confirmBtn: function(e) {
            console.log(this.data);
            var t = this.data.iptValue;
            if (console.log(t), console.log(t.length), console.log(this.data.numberLength), 
            t.length < this.data.numberLength) return wx.showToast({
                title: "请输入完整",
                icon: "error"
            }), void this.setData({
                isFocus: !0
            });
            1 == this.data.type ? this.checkSafeCode(t) : this.setSafecode(t);
        },
        checkSafeCode: function(a) {
            var s = this;
            return t(e().mark(function t() {
                var r;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return s.setData({
                            iptValue: "",
                            isFocus: !0
                        }), e.next = 3, i.mainDataReq({
                            value: a
                        }, "checkSafeCode", !0);

                      case 3:
                        0 == (r = e.sent).data.code ? (s.close(), s.triggerEvent("checkSuceess")) : n._showMsg(r.data.msg);

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        setSafecode: function(a) {
            var s = this;
            return t(e().mark(function t() {
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        s.triggerEvent("checkSuceess", {
                            safecode: a
                        }), s.setData({
                            firstValue: "",
                            iptValue: ""
                        });

                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        safecodeState: function() {
            return t(e().mark(function t() {
                var a, s, n, r;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (a = wx.getStorageSync("loginResData"), s = a.data.user, n = !1, s.safecode) {
                            e.next = 7;
                            break;
                        }
                        n = !0, e.next = 11;
                        break;

                      case 7:
                        return e.next = 9, i.mainDataReq(null, "safecodeState");

                      case 9:
                        r = e.sent, n = r.data.state;

                      case 11:
                        return e.abrupt("return", n);

                      case 12:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    }
});