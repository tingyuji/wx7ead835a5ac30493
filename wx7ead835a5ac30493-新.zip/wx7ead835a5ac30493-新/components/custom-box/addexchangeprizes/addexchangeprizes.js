var e = require("../../../@babel/runtime/helpers/objectSpread2"), t = require("../../../@babel/runtime/helpers/toConsumableArray"), i = require("../../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../../@babel/runtime/helpers/defineProperty"), r = require("../../../@babel/runtime/helpers/asyncToGenerator"), s = require("../../../utils/common"), n = new (require("../../../utils/requestData").requestData)(), o = new s.Common(), l = getApp();

Component({
    observers: {
        editprizes: function(e) {
            var t = this.data.prizesimg;
            e && (t.filepath = e.prizesimg), this.setData({
                prizesimg: t
            });
        }
    },
    properties: {
        editprizes: {
            type: Object,
            value: {},
            observer: function(e) {
                this.setData({
                    editprizes: e
                });
            }
        },
        dotype: {
            type: String,
            value: "addnewPrizes"
        }
    },
    data: {
        app: l,
        prizesimg: {
            fileid: null,
            filepath: null
        },
        showDelicon: !1,
        gridConfig: {
            column: 1,
            width: 128,
            height: 128
        }
    },
    methods: {
        ChooseImage: function() {
            var e = this;
            console.log(this.data), wx.chooseMedia({
                count: 1,
                mediaType: [ "image" ],
                sourceType: [ "album", "camera" ],
                camera: "back",
                success: function(t) {
                    var s;
                    wx.cropImage({
                        src: t.tempFiles[0].tempFilePath,
                        cropScale: "1:1",
                        success: (s = r(i().mark(function t(r) {
                            var s;
                            return i().wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return wx.showLoading({
                                        title: "正在上传...",
                                        mask: !0
                                    }), t.next = 3, n.uploadFile(r.tempFilePath, 3);

                                  case 3:
                                    0 == (s = t.sent).code && e.setData(a(a({}, "prizesimg.filepath", s.filepath), "prizesimg.fileid", s.fileid)), 
                                    wx.hideLoading();

                                  case 6:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        })), function(e) {
                            return s.apply(this, arguments);
                        })
                    });
                },
                fail: function() {
                    console.log("fail");
                }
            });
        },
        popupCloseCallback: function(e) {
            console.log(e);
        },
        deliconbtn: function(e) {
            var t = this;
            return r(i().mark(function e() {
                var r;
                return i().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (r = t.data.prizesimg, t.data.editprizes, "editPrizes" != t.data.dotype) {
                            e.next = 6;
                            break;
                        }
                        t.setData(a(a({}, "prizesimg.fileid", null), "prizesimg.filepath", null)), e.next = 10;
                        break;

                      case 6:
                        return e.next = 8, n.mainDataReq({
                            file: JSON.stringify(r)
                        }, "delfile");

                      case 8:
                        0 == e.sent.data.code && t.setData(a(a({}, "prizesimg.fileid", null), "prizesimg.filepath", null));

                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }))();
        },
        handleAdd: function(e) {
            var i = this.data.fileList, a = e.detail.files;
            this.setData({
                fileList: [].concat(t(i), t(a))
            });
        },
        onUpload: function(i) {
            var r = this, s = this.data.fileList;
            this.setData({
                fileList: [].concat(t(s), [ e(e({}, i), {}, {
                    status: "loading"
                }) ])
            });
            var n = s.length;
            wx.uploadFile({
                url: "https://example.weixin.qq.com/upload",
                filePath: i.url,
                name: "file",
                formData: {
                    user: "test"
                },
                success: function() {
                    r.setData(a({}, "fileList[".concat(n, "].status"), "done"));
                }
            }).onProgressUpdate(function(e) {
                r.setData(a({}, "fileList[".concat(n, "].percent"), e.progress));
            });
        },
        handleRemove: function(e) {
            var t = e.detail.index, i = this.data.fileList;
            i.splice(t, 1), this.setData({
                fileList: i
            });
        },
        addSubmit: function(e) {
            var t = this;
            return r(i().mark(function r() {
                var s, l, p, u, d;
                return i().wrap(function(i) {
                    for (;;) switch (i.prev = i.next) {
                      case 0:
                        if (s = e.detail.value.prizesname, 0 != (l = e.detail.value.needpoints) && o.isIntegerInVariable(l) && "" !== l && !(o.strlen(s) <= 0)) {
                            i.next = 4;
                            break;
                        }
                        return i.abrupt("return");

                      case 4:
                        return p = {
                            prizesname: s,
                            needpoints: l,
                            prizesimg: JSON.stringify(t.data.prizesimg)
                        }, i.next = 7, n.mainDataReq(p, "addExchangePrizes");

                      case 7:
                        0 === (u = i.sent).data.code && ((d = {
                            prizesname: p.prizesname,
                            needpoints: p.needpoints,
                            prizesimg: t.data.prizesimg.filepath
                        }).id = u.data.id, t.triggerEvent("success", {
                            dotype: t.data.dotype,
                            newItem: d
                        }), t.setData(a(a({}, "prizesimg.fileid", null), "prizesimg.filepath", null))), 
                        o.vipshowmsg(u.data.msg.title, u.data.msg.icon);

                      case 10:
                      case "end":
                        return i.stop();
                    }
                }, r);
            }))();
        },
        editSubmit: function(e) {
            var t = this;
            return r(i().mark(function a() {
                var r, s, l, p, u;
                return i().wrap(function(i) {
                    for (;;) switch (i.prev = i.next) {
                      case 0:
                        if (r = t.data.editprizes, s = e.detail.value.prizesname, 0 != (l = e.detail.value.needpoints) && o.isIntegerInVariable(l) && "" !== l && !(o.strlen(s) <= 0)) {
                            i.next = 5;
                            break;
                        }
                        return i.abrupt("return");

                      case 5:
                        if (p = {
                            prizesname: s,
                            needpoints: l,
                            prizesimg: t.data.prizesimg.filepath,
                            id: r.id
                        }, s != r.prizesname || l != r.needpoints || t.data.prizesimg.filepath != r.prizesimg) {
                            i.next = 8;
                            break;
                        }
                        return i.abrupt("return");

                      case 8:
                        return i.next = 10, n.mainDataReq(p, "editExchangePrizes");

                      case 10:
                        0 === (u = i.sent).data.code && t.triggerEvent("success", {
                            dotype: t.data.dotype,
                            newItem: p
                        }), o._showMsg(u.data.msg);

                      case 13:
                      case "end":
                        return i.stop();
                    }
                }, a);
            }))();
        }
    }
});