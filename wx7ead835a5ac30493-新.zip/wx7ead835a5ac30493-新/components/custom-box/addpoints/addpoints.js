var t = require("../../../@babel/runtime/helpers/regeneratorRuntime"), e = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../../@babel/runtime/helpers/defineProperty"), s = require("../../../utils/requestData"), n = require("../../../utils/common"), o = new s.requestData(), i = new n.Common();

Component({
    lifetimes: {
        ready: function() {
            console.log("ready");
        },
        attached: function() {
            console.log("11111111111");
        },
        detached: function() {},
        moved: function() {
            console.log("moved");
        }
    },
    properties: {
        childid: {
            type: String,
            value: 0
        }
    },
    options: {
        styleIsolation: "apply-shared"
    },
    data: {
        childBindRuleid: null,
        actionText: "",
        radioValue: -1,
        searchResult: null,
        searchValue: null,
        radioSelectItem: {
            points: 0
        },
        switchVal: !0,
        customPointsCauseFocus: !1,
        customPointsCause: null,
        pointsVal: 0,
        textareaAutosize: {
            maxHeight: 120,
            minHeight: 10
        },
        saveRuleChecked: !1,
        showBeizhu: !1,
        showBeizhutxt: !0,
        beizhuVal: "",
        noticeBarVisible: !1,
        marquee: {
            speed: 40,
            loop: 1,
            delay: 3e3
        },
        noticeBarContentList: [ "加油，你是最棒的！", "每一步努力都算数，继续前进吧！", "相信自己，你可以做到！", "努力学习，未来属于你！", "今天的学习，明天的骄傲。", "一点一滴的进步，都是成功的积累。", "保持微笑，学习之路会越来越宽广。", "你的努力，爸爸妈妈都看在眼里，为你自豪！", "学海无涯，勇敢探索吧！", "知识是翅膀，带你飞向更高远的地方！", "学习是通往梦想的金钥匙，每一页书都是成功路上的一块砖石。", "不要害怕犯错，错误是学习的一部分，它们让你变得更聪明。", "每天都是一次新的冒险，学习新知识就像探险一样令人兴奋。", "你的努力不会白费，每一步都在积累，总有一天会开花结果。", "学习不只是为了考试，更是为了让你成为更好的自己。", "当你觉得困难重重时，记住，每一项挑战都是一次成长的机会。", "保持好奇心，它会引导你发现世界更多的奥秘。", "不要和别人比较，最重要的是今天的你比昨天更进步了。", "读书不仅是为了获取知识，也是为了开阔眼界，丰富心灵。", "当你感到累的时候，想想那些因为你的努力而感到骄傲的人吧！" ],
        noticeBarContent: ""
    },
    methods: {
        clearHandle: function() {
            this.setData({
                searchResult: null
            });
        },
        changeHandle: function(t) {
            var e = t.detail.value, a = this.data.rule.causelist;
            a = e ? this.data.rule.causelist.filter(function(t) {
                return t.cause.includes(e);
            }) : null, console.log(a), this.setData({
                searchResult: a,
                radioValue: -1
            });
        },
        blurHandle: function(t) {
            this.setData({
                actionText: ""
            });
        },
        onChange_radio: function(t) {
            var e = t.currentTarget.dataset.value, a = this.data.customPointsCauseFocus, s = {}, n = this.data.switchVal;
            99999 != e ? n = (s = this.data.searchResult ? this.data.searchResult[e] : this.data.rule.causelist[e]).points > 0 : a = !0, 
            this.setData({
                customPointsCauseFocus: a,
                radioValue: e,
                radioSelectItem: s,
                pointsVal: Math.abs(s.points),
                switchVal: n,
                showBeizhutxt: !0
            }), console.log(this.data);
        },
        saveRuleChecked: function() {
            this.setData({
                saveRuleChecked: !this.data.saveRuleChecked
            });
        },
        actionHandle: function() {
            this.setData({
                value: "",
                actionText: ""
            });
        },
        switchHandleChange: function(t) {
            this.setData({
                switchVal: t.detail.value
            });
        },
        showKeyboard: function(t) {
            console.log("showKeyboard"), this.keyboard.showKeyboard(t), this.setData({
                cursorIndex: this.data.customInputValue.length
            });
        },
        hideKeyboard: function() {
            this.keyboard.hideKeyboard(), this.setData({
                cursorIndex: -1
            });
        },
        keyboardPageConfirm: function() {
            var t = parseInt(this.data.customInputValue.join(""));
            this.data.labelIcon || (t = 0 - parseInt(t)), this.setData(a({
                cursorIndex: -1
            }, "pointsPostData.points", t));
        },
        changePointsVal: function(t) {
            this.setData({
                pointsVal: t.detail.value
            });
        },
        customPointsCauseBlur: function() {
            this.setData({
                customPointsCauseFocus: !1
            });
        },
        changeCustomPointsCause: function(t) {
            this.setData({
                customPointsCause: t.detail.value
            });
        },
        beizhuChange: function(t) {
            var e = t.detail.value;
            this.setData({
                beizhuVal: e
            });
        },
        showBeizhu: function() {
            this.setData({
                showBeizhu: !this.data.showBeizhu
            }), this.data.showBeizhu || this.setData({
                beizhuVal: ""
            });
        },
        addPointsBtn: function() {
            var a = this;
            return e(t().mark(function e() {
                var s, n;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if ((n = (s = a).data.radioSelectItem).points = a.data.pointsVal, 99999 != a.data.radioValue) {
                            t.next = 9;
                            break;
                        }
                        n.id = 0, n.ruleid = 0, n.cause = a.data.customPointsCause, t.next = 12;
                        break;

                      case 9:
                        if (-1 != a.data.radioValue) {
                            t.next = 12;
                            break;
                        }
                        return wx.showToast({
                            title: "请填写选择奖惩原因",
                            icon: "error"
                        }), t.abrupt("return");

                      case 12:
                        if (n.cause) {
                            t.next = 15;
                            break;
                        }
                        return wx.showToast({
                            title: "请填写奖惩原因",
                            icon: "error"
                        }), t.abrupt("return");

                      case 15:
                        if (!(n.cause.length > 16)) {
                            t.next = 18;
                            break;
                        }
                        return i.showmsg("奖惩原因长度不得大于16个字"), t.abrupt("return");

                      case 18:
                        if (n.points) {
                            t.next = 21;
                            break;
                        }
                        return wx.showToast({
                            title: "请填写奖惩分值",
                            icon: "error"
                        }), t.abrupt("return");

                      case 21:
                        n.beizhuVal = "", a.data.showBeizhu && (n.beizhuVal = a.data.beizhuVal), n.pointsType = a.data.switchVal ? 1 : 0, 
                        n.saveRuleChecked = a.data.saveRuleChecked && 99999 == a.data.radioValue ? 1 : 0, 
                        n.pointsType ? a.addPoints(n) : wx.showModal({
                            title: "提示",
                            cancelText: "这次算了",
                            confirmText: "真的要扣",
                            content: "扣分可能会降低孩子的积极性，尽量以鼓励及正向引导为主。这次真的要扣分吗？",
                            success: function(t) {
                                t.confirm ? s.addPoints(n) : t.cancel && console.log("用户点击取消");
                            }
                        });

                      case 26:
                      case "end":
                        return t.stop();
                    }
                }, e);
            }))();
        },
        addPoints: function(a) {
            var s = this;
            return e(t().mark(function e() {
                var n, i;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return a.childid = s.data.childid, a.ruleid = s.data.rule.id, t.next = 4, o.mainDataReq(a, "addPoints");

                      case 4:
                        (n = t.sent).data.state && (s.triggerEvent("success"), n.data.newCauseId && (i = {
                            id: n.data.newCauseId,
                            ruleid: s.data.rule.id,
                            cause: s.data.customPointsCause,
                            points: n.data.newCausePoints,
                            myorder: 0
                        }, s.data.rule.causelist.push(i), s.setData({
                            rule: s.data.rule
                        })), s.setData({
                            saveRuleChecked: !1
                        })), wx.showToast({
                            title: n.data.msg.title,
                            icon: n.data.msg.icon
                        });

                      case 7:
                      case "end":
                        return t.stop();
                    }
                }, e);
            }))();
        },
        getCauseList: function(a) {
            var s = this;
            return e(t().mark(function e() {
                var n;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.prev = 0, t.next = 3, o.mainDataReq(a, "getRuleCauseList");

                      case 3:
                        return n = t.sent, s.setData({
                            rule: n.data.rule
                        }), t.abrupt("return", n);

                      case 8:
                        throw t.prev = 8, t.t0 = t.catch(0), console.error("Error fetching rule cause list:", t.t0), 
                        t.t0;

                      case 12:
                      case "end":
                        return t.stop();
                    }
                }, e, null, [ [ 0, 8 ] ]);
            }))();
        },
        onLineChange: function(t) {
            console.log(t), console.log("lineCount: ", t.detail);
        },
        goPage: function(t) {
            console.log(t);
            var e = t.currentTarget.dataset.url;
            wx.navigateTo({
                url: e
            });
        },
        onShow: function() {
            console.log("onshow");
        },
        showNoticeBarContent: function() {
            wx.showModal({
                title: "",
                content: this.data.noticeBarContent,
                confirmText: "关闭",
                showCancel: !1
            });
        }
    }
});