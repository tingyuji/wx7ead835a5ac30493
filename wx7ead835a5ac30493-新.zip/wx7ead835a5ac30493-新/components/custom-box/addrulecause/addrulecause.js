var a = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), e = new (require("../../../utils/requestData").requestData)();

Component({
    observers: {
        editItem: function(a) {
            var t = !0, e = "", s = "";
            null != a && (t = a.points > 0, e = Math.abs(a.points), s = a.cause), this.setData({
                switchVal: t,
                pointsVal: e,
                causeVal: s
            }), console.log(this.data);
        }
    },
    properties: {
        type: {
            type: String,
            value: "addRuleCause",
            observer: function(a, t) {
                switch (a) {
                  case "addRuleCause":
                    this.setData({
                        switchVal: !0,
                        pointsVal: "",
                        causeVal: ""
                    });
                }
            }
        },
        editItem: {
            type: Object,
            value: null
        },
        ruleObj: {
            type: Object,
            value: null
        }
    },
    data: {
        switchVal: !0,
        pointsVal: "",
        causeVal: ""
    },
    methods: {
        changeCauseVal: function(a) {
            var t = a.detail.value;
            this.setData({
                causeVal: t
            });
        },
        changePointsVal: function(a) {
            var t = a.detail.value;
            this.setData({
                pointsVal: t
            });
        },
        switchHandleChange: function(a) {
            this.setData({
                switchVal: a.detail.value
            });
        },
        saveCauseBtn: function() {
            console.log(this.data);
            var a = {
                switchVal: this.data.switchVal ? 1 : 0,
                pointsVal: this.data.pointsVal,
                causeVal: this.data.causeVal,
                ruleid: this.data.ruleObj.info.id,
                id: null == this.data.editItem ? 0 : this.data.editItem.id
            };
            this.saveCause(a);
        },
        saveCause: function(s) {
            var i = this;
            return t(a().mark(function t() {
                var n;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (1001 != i.data.ruleObj.info.create_userid) {
                            a.next = 4;
                            break;
                        }
                        return wx.showModal({
                            title: "提示",
                            content: "这是系统默认规则作为演示用，不能编辑！"
                        }), i.triggerEvent("closePopup"), a.abrupt("return");

                      case 4:
                        return a.next = 6, e.mainDataReq(s, "saveRuleCause");

                      case 6:
                        (n = a.sent).data.state && (i.triggerEvent("saveCauseSuccess", {
                            type: i.data.type,
                            causelist: n.data.rule.causelist
                        }), i.setData({
                            pointsVal: "",
                            causeVal: ""
                        }), console.log(i.data.causeVal)), wx.showToast({
                            title: n.data.msg.title,
                            icon: n.data.msg.icon
                        });

                      case 9:
                      case "end":
                        return a.stop();
                    }
                }, t);
            }))();
        }
    }
});