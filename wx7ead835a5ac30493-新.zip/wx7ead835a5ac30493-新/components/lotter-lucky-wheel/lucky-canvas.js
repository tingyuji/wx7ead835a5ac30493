Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.SlotMachine = exports.LuckyWheel = exports.LuckyGrid = void 0, require("../../@babel/runtime/helpers/Arrayincludes");

var t = require("../../@babel/runtime/helpers/typeof"), e = function(t, i) {
    return (e = Object.setPrototypeOf || {
        __proto__: []
    } instanceof Array && function(t, e) {
        t.__proto__ = e;
    } || function(t, e) {
        for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && (t[i] = e[i]);
    })(t, i);
};

/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */ function i(t, i) {
    if ("function" != typeof i && null !== i) throw new TypeError("Class extends value " + String(i) + " is not a constructor or null");
    function n() {
        this.constructor = t;
    }
    e(t, i), t.prototype = null === i ? Object.create(i) : (n.prototype = i.prototype, 
    new n());
}

var n = function() {
    return (n = Object.assign || function(t) {
        for (var e, i = 1, n = arguments.length; i < n; i++) for (var r in e = arguments[i]) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
        return t;
    }).apply(this, arguments);
};

function r(t, e, i, n) {
    return new (i || (i = Promise))(function(r, o) {
        function a(t) {
            try {
                c(n.next(t));
            } catch (t) {
                o(t);
            }
        }
        function s(t) {
            try {
                c(n.throw(t));
            } catch (t) {
                o(t);
            }
        }
        function c(t) {
            var e;
            t.done ? r(t.value) : (e = t.value, e instanceof i ? e : new i(function(t) {
                t(e);
            })).then(a, s);
        }
        c((n = n.apply(t, e || [])).next());
    });
}

function o(t, e) {
    var i, n, r, o, a = {
        label: 0,
        sent: function() {
            if (1 & r[0]) throw r[1];
            return r[1];
        },
        trys: [],
        ops: []
    };
    return o = {
        next: s(0),
        throw: s(1),
        return: s(2)
    }, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
        return this;
    }), o;
    function s(o) {
        return function(s) {
            return function(o) {
                if (i) throw new TypeError("Generator is already executing.");
                for (;a; ) try {
                    if (i = 1, n && (r = 2 & o[0] ? n.return : o[0] ? n.throw || ((r = n.return) && r.call(n), 
                    0) : n.next) && !(r = r.call(n, o[1])).done) return r;
                    switch (n = 0, r && (o = [ 2 & o[0], r.value ]), o[0]) {
                      case 0:
                      case 1:
                        r = o;
                        break;

                      case 4:
                        return a.label++, {
                            value: o[1],
                            done: !1
                        };

                      case 5:
                        a.label++, n = o[1], o = [ 0 ];
                        continue;

                      case 7:
                        o = a.ops.pop(), a.trys.pop();
                        continue;

                      default:
                        if (!((r = (r = a.trys).length > 0 && r[r.length - 1]) || 6 !== o[0] && 2 !== o[0])) {
                            a = 0;
                            continue;
                        }
                        if (3 === o[0] && (!r || o[1] > r[0] && o[1] < r[3])) {
                            a.label = o[1];
                            break;
                        }
                        if (6 === o[0] && a.label < r[1]) {
                            a.label = r[1], r = o;
                            break;
                        }
                        if (r && a.label < r[2]) {
                            a.label = r[2], a.ops.push(o);
                            break;
                        }
                        r[2] && a.ops.pop(), a.trys.pop();
                        continue;
                    }
                    o = e.call(t, a);
                } catch (t) {
                    o = [ 6, t ], n = 0;
                } finally {
                    i = r = 0;
                }
                if (5 & o[0]) throw o[1];
                return {
                    value: o[0] ? o[1] : void 0,
                    done: !0
                };
            }([ o, s ]);
        };
    }
}

function a(t, e) {
    for (var i = 0, n = e.length, r = t.length; i < n; i++, r++) t[r] = e[i];
    return t;
}

var s = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};

function c(t, e, i) {
    return t(i = {
        path: e,
        exports: {},
        require: function(t, e) {
            return function() {
                throw new Error("Dynamic requires are not currently supported by @rollup/plugin-commonjs");
            }(null == e && i.path);
        }
    }, i.exports), i.exports;
}

var u, h, l = function(t) {
    return t && t.Math == Math && t;
}, f = l("object" == ("undefined" == typeof globalThis ? "undefined" : t(globalThis)) && globalThis) || l("object" == ("undefined" == typeof window ? "undefined" : t(window)) && window) || l("object" == ("undefined" == typeof self ? "undefined" : t(self)) && self) || l("object" == t(s) && s) || function() {
    return this;
}() || Function("return this")(), d = function(t) {
    try {
        return !!t();
    } catch (t) {
        return !0;
    }
}, p = !d(function() {
    return 7 != Object.defineProperty({}, 1, {
        get: function() {
            return 7;
        }
    })[1];
}), g = Function.prototype.call, v = g.bind ? g.bind(g) : function() {
    return g.apply(g, arguments);
}, m = {}.propertyIsEnumerable, y = Object.getOwnPropertyDescriptor, w = {
    f: y && !m.call({
        1: 2
    }, 1) ? function(t) {
        var e = y(this, t);
        return !!e && e.enumerable;
    } : m
}, b = function(t, e) {
    return {
        enumerable: !(1 & t),
        configurable: !(2 & t),
        writable: !(4 & t),
        value: e
    };
}, S = Function.prototype, x = S.bind, C = S.call, z = x && x.bind(C), O = x ? function(t) {
    return t && z(C, t);
} : function(t) {
    return t && function() {
        return C.apply(t, arguments);
    };
}, k = O({}.toString), I = O("".slice), T = function(t) {
    return I(k(t), 8, -1);
}, E = f.Object, A = O("".split), P = d(function() {
    return !E("z").propertyIsEnumerable(0);
}) ? function(t) {
    return "String" == T(t) ? A(t, "") : E(t);
} : E, _ = f.TypeError, W = function(t) {
    if (null == t) throw _("Can't call method on " + t);
    return t;
}, $ = function(t) {
    return P(W(t));
}, j = function(t) {
    return "function" == typeof t;
}, F = function(e) {
    return "object" == t(e) ? null !== e : j(e);
}, R = function(t) {
    return j(t) ? t : void 0;
}, D = function(t, e) {
    return arguments.length < 2 ? R(f[t]) : f[t] && f[t][e];
}, L = O({}.isPrototypeOf), H = D("navigator", "userAgent") || "", M = f.process, B = f.Deno, N = M && M.versions || B && B.version, G = N && N.v8;

G && (h = (u = G.split("."))[0] > 0 && u[0] < 4 ? 1 : +(u[0] + u[1])), !h && H && (!(u = H.match(/Edge\/(\d+)/)) || u[1] >= 74) && (u = H.match(/Chrome\/(\d+)/)) && (h = +u[1]);

var X = h, q = !!Object.getOwnPropertySymbols && !d(function() {
    var t = Symbol();
    return !String(t) || !(Object(t) instanceof Symbol) || !Symbol.sham && X && X < 41;
}), U = q && !Symbol.sham && "symbol" == t(Symbol.iterator), Y = f.Object, K = U ? function(e) {
    return "symbol" == t(e);
} : function(t) {
    var e = D("Symbol");
    return j(e) && L(e.prototype, Y(t));
}, V = f.String, J = f.TypeError, Q = function(t) {
    if (j(t)) return t;
    throw J(function(t) {
        try {
            return V(t);
        } catch (t) {
            return "Object";
        }
    }(t) + " is not a function");
}, Z = f.TypeError, tt = Object.defineProperty, et = function(t, e) {
    try {
        tt(f, t, {
            value: e,
            configurable: !0,
            writable: !0
        });
    } catch (i) {
        f[t] = e;
    }
    return e;
}, it = f["__core-js_shared__"] || et("__core-js_shared__", {}), nt = c(function(t) {
    (t.exports = function(t, e) {
        return it[t] || (it[t] = void 0 !== e ? e : {});
    })("versions", []).push({
        version: "3.19.2",
        mode: "global",
        copyright: "© 2021 Denis Pushkarev (zloirock.ru)"
    });
}), rt = f.Object, ot = function(t) {
    return rt(W(t));
}, at = O({}.hasOwnProperty), st = Object.hasOwn || function(t, e) {
    return at(ot(t), e);
}, ct = 0, ut = Math.random(), ht = O(1..toString), lt = function(t) {
    return "Symbol(" + (void 0 === t ? "" : t) + ")_" + ht(++ct + ut, 36);
}, ft = nt("wks"), dt = f.Symbol, pt = dt && dt.for, gt = U ? dt : dt && dt.withoutSetter || lt, vt = function(t) {
    if (!st(ft, t) || !q && "string" != typeof ft[t]) {
        var e = "Symbol." + t;
        q && st(dt, t) ? ft[t] = dt[t] : ft[t] = U && pt ? pt(e) : gt(e);
    }
    return ft[t];
}, mt = f.TypeError, yt = vt("toPrimitive"), wt = function(t) {
    var e = function(t, e) {
        if (!F(t) || K(t)) return t;
        var i, n, r = null == (i = t[yt]) ? void 0 : Q(i);
        if (r) {
            if (void 0 === e && (e = "default"), n = v(r, t, e), !F(n) || K(n)) return n;
            throw mt("Can't convert object to primitive value");
        }
        return void 0 === e && (e = "number"), function(t, e) {
            var i, n;
            if ("string" === e && j(i = t.toString) && !F(n = v(i, t))) return n;
            if (j(i = t.valueOf) && !F(n = v(i, t))) return n;
            if ("string" !== e && j(i = t.toString) && !F(n = v(i, t))) return n;
            throw Z("Can't convert object to primitive value");
        }(t, e);
    }(t, "string");
    return K(e) ? e : e + "";
}, bt = f.document, St = F(bt) && F(bt.createElement), xt = function(t) {
    return St ? bt.createElement(t) : {};
}, Ct = !p && !d(function() {
    return 7 != Object.defineProperty(xt("div"), "a", {
        get: function() {
            return 7;
        }
    }).a;
}), zt = Object.getOwnPropertyDescriptor, Ot = {
    f: p ? zt : function(t, e) {
        if (t = $(t), e = wt(e), Ct) try {
            return zt(t, e);
        } catch (t) {}
        if (st(t, e)) return b(!v(w.f, t, e), t[e]);
    }
}, kt = f.String, It = f.TypeError, Tt = function(t) {
    if (F(t)) return t;
    throw It(kt(t) + " is not an object");
}, Et = f.TypeError, At = Object.defineProperty, Pt = {
    f: p ? At : function(t, e, i) {
        if (Tt(t), e = wt(e), Tt(i), Ct) try {
            return At(t, e, i);
        } catch (t) {}
        if ("get" in i || "set" in i) throw Et("Accessors not supported");
        return "value" in i && (t[e] = i.value), t;
    }
}, _t = p ? function(t, e, i) {
    return Pt.f(t, e, b(1, i));
} : function(t, e, i) {
    return t[e] = i, t;
}, Wt = O(Function.toString);

j(it.inspectSource) || (it.inspectSource = function(t) {
    return Wt(t);
});

var $t, jt, Ft, Rt = it.inspectSource, Dt = f.WeakMap, Lt = j(Dt) && /native code/.test(Rt(Dt)), Ht = nt("keys"), Mt = function(t) {
    return Ht[t] || (Ht[t] = lt(t));
}, Bt = {}, Nt = f.TypeError, Gt = f.WeakMap;

if (Lt || it.state) {
    var Xt = it.state || (it.state = new Gt()), qt = O(Xt.get), Ut = O(Xt.has), Yt = O(Xt.set);
    $t = function(t, e) {
        if (Ut(Xt, t)) throw new Nt("Object already initialized");
        return e.facade = t, Yt(Xt, t, e), e;
    }, jt = function(t) {
        return qt(Xt, t) || {};
    }, Ft = function(t) {
        return Ut(Xt, t);
    };
} else {
    var Kt = Mt("state");
    Bt[Kt] = !0, $t = function(t, e) {
        if (st(t, Kt)) throw new Nt("Object already initialized");
        return e.facade = t, _t(t, Kt, e), e;
    }, jt = function(t) {
        return st(t, Kt) ? t[Kt] : {};
    }, Ft = function(t) {
        return st(t, Kt);
    };
}

var Vt, Jt = {
    set: $t,
    get: jt,
    has: Ft,
    enforce: function(t) {
        return Ft(t) ? jt(t) : $t(t, {});
    },
    getterFor: function(t) {
        return function(e) {
            var i;
            if (!F(e) || (i = jt(e)).type !== t) throw Nt("Incompatible receiver, " + t + " required");
            return i;
        };
    }
}, Qt = Function.prototype, Zt = p && Object.getOwnPropertyDescriptor, te = st(Qt, "name"), ee = {
    EXISTS: te,
    PROPER: te && "something" === function() {}.name,
    CONFIGURABLE: te && (!p || p && Zt(Qt, "name").configurable)
}, ie = c(function(t) {
    var e = ee.CONFIGURABLE, i = Jt.get, n = Jt.enforce, r = String(String).split("String");
    (t.exports = function(t, i, o, a) {
        var s, c = !!a && !!a.unsafe, u = !!a && !!a.enumerable, h = !!a && !!a.noTargetGet, l = a && void 0 !== a.name ? a.name : i;
        j(o) && ("Symbol(" === String(l).slice(0, 7) && (l = "[" + String(l).replace(/^Symbol\(([^)]*)\)/, "$1") + "]"), 
        (!st(o, "name") || e && o.name !== l) && _t(o, "name", l), (s = n(o)).source || (s.source = r.join("string" == typeof l ? l : ""))), 
        t !== f ? (c ? !h && t[i] && (u = !0) : delete t[i], u ? t[i] = o : _t(t, i, o)) : u ? t[i] = o : et(i, o);
    })(Function.prototype, "toString", function() {
        return j(this) && i(this).source || Rt(this);
    });
}), ne = Math.ceil, re = Math.floor, oe = function(t) {
    var e = +t;
    return e != e || 0 === e ? 0 : (e > 0 ? re : ne)(e);
}, ae = Math.max, se = Math.min, ce = Math.min, ue = function(t) {
    return (e = t.length) > 0 ? ce(oe(e), 9007199254740991) : 0;
    var e;
}, he = function(t) {
    return function(e, i, n) {
        var r, o = $(e), a = ue(o), s = function(t, e) {
            var i = oe(t);
            return i < 0 ? ae(i + e, 0) : se(i, e);
        }(n, a);
        if (t && i != i) {
            for (;a > s; ) if ((r = o[s++]) != r) return !0;
        } else for (;a > s; s++) if ((t || s in o) && o[s] === i) return t || s || 0;
        return !t && -1;
    };
}, le = {
    includes: he(!0),
    indexOf: he(!1)
}, fe = le.indexOf, de = O([].push), pe = function(t, e) {
    var i, n = $(t), r = 0, o = [];
    for (i in n) !st(Bt, i) && st(n, i) && de(o, i);
    for (;e.length > r; ) st(n, i = e[r++]) && (~fe(o, i) || de(o, i));
    return o;
}, ge = [ "constructor", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toLocaleString", "toString", "valueOf" ], ve = ge.concat("length", "prototype"), me = {
    f: Object.getOwnPropertyNames || function(t) {
        return pe(t, ve);
    }
}, ye = {
    f: Object.getOwnPropertySymbols
}, we = O([].concat), be = D("Reflect", "ownKeys") || function(t) {
    var e = me.f(Tt(t)), i = ye.f;
    return i ? we(e, i(t)) : e;
}, Se = function(t, e) {
    for (var i = be(e), n = Pt.f, r = Ot.f, o = 0; o < i.length; o++) {
        var a = i[o];
        st(t, a) || n(t, a, r(e, a));
    }
}, xe = /#|\.prototype\./, Ce = function(t, e) {
    var i = Oe[ze(t)];
    return i == Ie || i != ke && (j(e) ? d(e) : !!e);
}, ze = Ce.normalize = function(t) {
    return String(t).replace(xe, ".").toLowerCase();
}, Oe = Ce.data = {}, ke = Ce.NATIVE = "N", Ie = Ce.POLYFILL = "P", Te = Ce, Ee = Ot.f, Ae = function(e, i) {
    var n, r, o, a, s, c = e.target, u = e.global, h = e.stat;
    if (n = u ? f : h ? f[c] || et(c, {}) : (f[c] || {}).prototype) for (r in i) {
        if (a = i[r], o = e.noTargetGet ? (s = Ee(n, r)) && s.value : n[r], !Te(u ? r : c + (h ? "." : "#") + r, e.forced) && void 0 !== o) {
            if (t(a) == t(o)) continue;
            Se(a, o);
        }
        (e.sham || o && o.sham) && _t(a, "sham", !0), ie(n, r, a, e);
    }
}, Pe = Object.keys || function(t) {
    return pe(t, ge);
}, _e = p ? Object.defineProperties : function(t, e) {
    Tt(t);
    for (var i, n = $(e), r = Pe(e), o = r.length, a = 0; o > a; ) Pt.f(t, i = r[a++], n[i]);
    return t;
}, We = D("document", "documentElement"), $e = Mt("IE_PROTO"), je = function() {}, Fe = function(t) {
    return "<script>" + t + "<\/script>";
}, Re = function(t) {
    t.write(Fe("")), t.close();
    var e = t.parentWindow.Object;
    return t = null, e;
}, De = function() {
    try {
        Vt = new ActiveXObject("htmlfile");
    } catch (t) {}
    var t, e;
    De = "undefined" != typeof document ? document.domain && Vt ? Re(Vt) : ((e = xt("iframe")).style.display = "none", 
    We.appendChild(e), e.src = String("javascript:"), (t = e.contentWindow.document).open(), 
    t.write(Fe("document.F=Object")), t.close(), t.F) : Re(Vt);
    for (var i = ge.length; i--; ) delete De.prototype[ge[i]];
    return De();
};

Bt[$e] = !0;

var Le = Object.create || function(t, e) {
    var i;
    return null !== t ? (je.prototype = Tt(t), i = new je(), je.prototype = null, i[$e] = t) : i = De(), 
    void 0 === e ? i : _e(i, e);
}, He = vt("unscopables"), Me = Array.prototype;

null == Me[He] && Pt.f(Me, He, {
    configurable: !0,
    value: Le(null)
});

var Be = function(t) {
    Me[He][t] = !0;
}, Ne = le.includes;

Ae({
    target: "Array",
    proto: !0
}, {
    includes: function(t) {
        return Ne(this, t, arguments.length > 1 ? arguments[1] : void 0);
    }
}), Be("includes"), Ae({
    target: "Object",
    stat: !0,
    forced: !p,
    sham: !p
}, {
    defineProperty: Pt.f
});

var Ge = vt("match"), Xe = f.TypeError, qe = function(t) {
    if (function(t) {
        var e;
        return F(t) && (void 0 !== (e = t[Ge]) ? !!e : "RegExp" == T(t));
    }(t)) throw Xe("The method doesn't accept regular expressions");
    return t;
}, Ue = {};

Ue[vt("toStringTag")] = "z";

var Ye = "[object z]" === String(Ue), Ke = vt("toStringTag"), Ve = f.Object, Je = "Arguments" == T(function() {
    return arguments;
}()), Qe = Ye ? T : function(t) {
    var e, i, n;
    return void 0 === t ? "Undefined" : null === t ? "Null" : "string" == typeof (i = function(t, e) {
        try {
            return t[e];
        } catch (t) {}
    }(e = Ve(t), Ke)) ? i : Je ? T(e) : "Object" == (n = T(e)) && j(e.callee) ? "Arguments" : n;
}, Ze = f.String, ti = function(t) {
    if ("Symbol" === Qe(t)) throw TypeError("Cannot convert a Symbol value to a string");
    return Ze(t);
}, ei = vt("match"), ii = O("".indexOf);

Ae({
    target: "String",
    proto: !0,
    forced: !function(t) {
        var e = /./;
        try {
            "/./"[t](e);
        } catch (i) {
            try {
                return e[ei] = !1, "/./"[t](e);
            } catch (t) {}
        }
        return !1;
    }("includes")
}, {
    includes: function(t) {
        return !!~ii(ti(W(this)), ti(qe(t)), arguments.length > 1 ? arguments[1] : void 0);
    }
});

var ni, ri = le.indexOf, oi = O([].indexOf), ai = !!oi && 1 / oi([ 1 ], 1, -0) < 0, si = !!(ni = [].indexOf) && d(function() {
    ni.call(null, function() {
        throw 1;
    }, 1);
});

Ae({
    target: "Array",
    proto: !0,
    forced: ai || !si
}, {
    indexOf: function(t) {
        var e = arguments.length > 1 ? arguments[1] : void 0;
        return ai ? oi(this, t, e) || 0 : ri(this, t, e);
    }
});

var ci = O(O.bind), ui = Array.isArray || function(t) {
    return "Array" == T(t);
}, hi = function() {}, li = [], fi = D("Reflect", "construct"), di = /^\s*(?:class|function)\b/, pi = O(di.exec), gi = !di.exec(hi), vi = function(t) {
    if (!j(t)) return !1;
    try {
        return fi(hi, li, t), !0;
    } catch (t) {
        return !1;
    }
}, mi = !fi || d(function() {
    var t;
    return vi(vi.call) || !vi(Object) || !vi(function() {
        t = !0;
    }) || t;
}) ? function(t) {
    if (!j(t)) return !1;
    switch (Qe(t)) {
      case "AsyncFunction":
      case "GeneratorFunction":
      case "AsyncGeneratorFunction":
        return !1;
    }
    return gi || !!pi(di, Rt(t));
} : vi, yi = vt("species"), wi = f.Array, bi = function(t, e) {
    return new (function(t) {
        var e;
        return ui(t) && (e = t.constructor, (mi(e) && (e === wi || ui(e.prototype)) || F(e) && null === (e = e[yi])) && (e = void 0)), 
        void 0 === e ? wi : e;
    }(t))(0 === e ? 0 : e);
}, Si = O([].push), xi = function(t) {
    var e = 1 == t, i = 2 == t, n = 3 == t, r = 4 == t, o = 6 == t, a = 7 == t, s = 5 == t || o;
    return function(c, u, h, l) {
        for (var f, d, p = ot(c), g = P(p), v = function(t, e) {
            return Q(t), void 0 === e ? t : ci ? ci(t, e) : function() {
                return t.apply(e, arguments);
            };
        }(u, h), m = ue(g), y = 0, w = l || bi, b = e ? w(c, m) : i || a ? w(c, 0) : void 0; m > y; y++) if ((s || y in g) && (d = v(f = g[y], y, p), 
        t)) if (e) b[y] = d; else if (d) switch (t) {
          case 3:
            return !0;

          case 5:
            return f;

          case 6:
            return y;

          case 2:
            Si(b, f);
        } else switch (t) {
          case 4:
            return !1;

          case 7:
            Si(b, f);
        }
        return o ? -1 : n || r ? r : b;
    };
}, Ci = [ xi(0), xi(1), xi(2), xi(3), xi(4), xi(5), xi(6), xi(7) ][5], zi = !0;

"find" in [] && Array(1).find(function() {
    zi = !1;
}), Ae({
    target: "Array",
    proto: !0,
    forced: zi
}, {
    find: function(t) {
        return Ci(this, t, arguments.length > 1 ? arguments[1] : void 0);
    }
}), Be("find"), Array.prototype.includes || Object.defineProperty(Array.prototype, "includes", {
    value: function(t, e) {
        if (null == this) throw new TypeError('"this" is null or not defined');
        var i = Object(this), n = i.length >>> 0;
        if (0 === n) return !1;
        for (var r, o, a = 0 | e, s = Math.max(a >= 0 ? a : n - Math.abs(a), 0); s < n; ) {
            if ((r = i[s]) === (o = t) || "number" == typeof r && "number" == typeof o && isNaN(r) && isNaN(o)) return !0;
            s++;
        }
        return !1;
    }
}), String.prototype.includes || (String.prototype.includes = function(t, e) {
    return "number" != typeof e && (e = 0), !(e + t.length > this.length) && -1 !== this.indexOf(t, e);
}), Array.prototype.find || Object.defineProperty(Array.prototype, "find", {
    value: function(t) {
        if (null == this) throw new TypeError('"this" is null or not defined');
        var e = Object(this), i = e.length >>> 0;
        if ("function" != typeof t) throw new TypeError("predicate must be a function");
        for (var n = arguments[1], r = 0; r < i; ) {
            var o = e[r];
            if (t.call(n, o, r, e)) return o;
            r++;
        }
    }
});

var Oi = function(e) {
    for (var i = [], n = 1; n < arguments.length; n++) i[n - 1] = arguments[n];
    var r = t(e);
    return "object" !== r ? i.includes(r) : null === r ? i.includes("null") : (Array.isArray(e) && i.includes("array"), 
    i.includes("object"));
}, ki = function(t, e) {
    for (var i = 0, n = e.split("."); i < n.length; i++) {
        var r = t[n[i]];
        if (!Oi(r, "object", "array")) return r;
        t = r;
    }
    return t;
}, Ii = function(t, e) {
    return Object.prototype.hasOwnProperty.call(t, e);
}, Ti = function(t) {
    return [].filter.call(t, function(t) {
        return "\n" !== t;
    }).join("");
}, Ei = function(e) {
    if ("string" != typeof e) return !1;
    if ("transparent" === (e = e.toLocaleLowerCase().trim())) return !1;
    var i;
    if (/^rgba/.test(e) && 0 === (null === (i = /([^\s,]+)\)$/.exec(e)) ? 0 : "object" == t(i) ? NaN : "number" == typeof i ? i : "string" == typeof i ? "%" === i[i.length - 1] ? Number(i.slice(0, -1)) / 100 : Number(i) : NaN)) return !1;
    return !0;
}, Ai = function(t) {
    var e, i = (null === (e = t.padding) || void 0 === e ? void 0 : e.replace(/px/g, "").split(" ").map(function(t) {
        return ~~t;
    })) || [ 0 ], n = 0, r = 0, o = 0, a = 0;
    switch (i.length) {
      case 1:
        n = r = o = a = i[0];
        break;

      case 2:
        n = r = i[0], o = a = i[1];
        break;

      case 3:
        n = i[0], o = a = i[1], r = i[2];
        break;

      default:
        n = i[0], r = i[1], o = i[2], a = i[3];
    }
    var s = {
        paddingTop: n,
        paddingBottom: r,
        paddingLeft: o,
        paddingRight: a
    };
    for (var c in s) s[c] = Object.prototype.hasOwnProperty.call(t, c) && Oi(t[c], "string", "number") ? ~~String(t[c]).replace(/px/g, "") : s[c];
    return [ n, r, o, a ];
}, Pi = function(t) {
    var e = [], i = t.map(function(t) {
        return Number(t);
    }).reduce(function(t, i) {
        if (i > 0) {
            var n = t + i;
            return e.push(n), n;
        }
        return e.push(NaN), t;
    }, 0), n = Math.random() * i;
    return e.findIndex(function(t) {
        return n <= t;
    });
}, _i = function(t, e, i, n) {
    void 0 === n && (n = 1 / 0), n <= 0 && (n = 1 / 0);
    for (var r = "", o = [], a = t.measureText("...").width, s = 0; s < e.length; s++) {
        r += e[s];
        var c = t.measureText(r).width, u = i(o);
        if (n === o.length + 1 && (c += a), u < 0) return o;
        if (c > u && (o.push(r.slice(0, -1)), r = e[s]), n === o.length) return o[o.length - 1] += "...", 
        o;
    }
    return r && o.push(r), o.length || o.push(e), o;
}, Wi = function(t) {
    return Math.PI / 180 * t;
}, $i = function(t) {
    for (var e = [], i = 1; i < arguments.length; i++) e[i - 1] = arguments[i];
    var n = e[0], r = e[1], o = e[2], a = e[3], s = e[4], c = Math.min(o, a), u = Math.PI;
    s > c / 2 && (s = c / 2), t.beginPath(), t.moveTo(n + s, r), t.lineTo(n + s, r), 
    t.lineTo(n + o - s, r), t.arc(n + o - s, r + s, s, -u / 2, 0), t.lineTo(n + o, r + a - s), 
    t.arc(n + o - s, r + a - s, s, 0, u / 2), t.lineTo(n + s, r + a), t.arc(n + s, r + a - s, s, u / 2, u), 
    t.lineTo(n, r + s), t.arc(n + s, r + s, s, u, -u / 2), t.closePath();
}, ji = function(t, e, i, n, r, o) {
    var a = document.createElement("canvas"), s = a.getContext("2d"), c = t.width, u = t.height;
    a.width = c, a.height = u;
    var h = c / n;
    return $i(s, e * h, i * h, n * h, r * h, o * h), s.clip(), s.drawImage(t, 0, 0, c, u), 
    a;
}, Fi = function() {
    function t() {
        this.subs = [];
    }
    return t.prototype.addSub = function(t) {
        this.subs.includes(t) || this.subs.push(t);
    }, t.prototype.notify = function() {
        this.subs.forEach(function(t) {
            t.update();
        });
    }, t;
}(), Ri = "__proto__" in {};

function Di(t, e, i, n) {
    Object.defineProperty(t, e, {
        value: i,
        enumerable: !!n,
        writable: !0,
        configurable: !0
    });
}

var Li = Array.prototype, Hi = Object.create(Li);

[ "push", "pop", "shift", "unshift", "sort", "splice", "reverse" ].forEach(function(t) {
    Hi[t] = function() {
        for (var e = [], i = 0; i < arguments.length; i++) e[i] = arguments[i];
        var n = Li[t].apply(this, e), r = this.__luckyOb__;
        return [ "push", "unshift", "splice" ].includes(t) && r.walk(this), r.dep.notify(), 
        n;
    };
});

var Mi = function() {
    function t(t) {
        this.dep = new Fi(), Di(t, "__luckyOb__", this), Array.isArray(t) && (Ri ? t.__proto__ = Hi : Object.getOwnPropertyNames(Hi).forEach(function(e) {
            Di(t, e, Hi[e]);
        })), this.walk(t);
    }
    return t.prototype.walk = function(t) {
        Object.keys(t).forEach(function(e) {
            Ni(t, e, t[e]);
        });
    }, t;
}();

function Bi(e) {
    if (e && "object" == t(e)) return "__luckyOb__" in e ? e.__luckyOb__ : new Mi(e);
}

function Ni(t, e, i) {
    var n = new Fi(), r = Object.getOwnPropertyDescriptor(t, e);
    if (!r || !1 !== r.configurable) {
        var o = r && r.get, a = r && r.set;
        o && !a || 2 !== arguments.length || (i = t[e]);
        var s = Bi(i);
        Object.defineProperty(t, e, {
            get: function() {
                var e = o ? o.call(t) : i;
                return Fi.target && (n.addSub(Fi.target), s && s.dep.addSub(Fi.target)), e;
            },
            set: function(e) {
                e !== i && (i = e, o && !a || (a ? a.call(t, e) : i = e, s = Bi(e), n.notify()));
            }
        });
    }
}

var Gi = 0, Xi = function() {
    function t(t, e, i, n) {
        void 0 === n && (n = {}), this.id = Gi++, this.$lucky = t, this.expr = e, this.deep = !!n.deep, 
        this.getter = "function" == typeof e ? e : function(t) {
            t += ".";
            for (var e = [], i = "", n = 0; n < t.length; n++) {
                var r = t[n];
                if (/\[|\./.test(r)) e.push(i), i = ""; else {
                    if (/\W/.test(r)) continue;
                    i += r;
                }
            }
            return function(t) {
                return e.reduce(function(t, e) {
                    return t[e];
                }, t);
            };
        }(e), this.cb = i, this.value = this.get();
    }
    return t.prototype.get = function() {
        Fi.target = this;
        var t = this.getter.call(this.$lucky, this.$lucky);
        return this.deep && function(t) {
            !function t(e) {
                Oi(e, "array", "object") && Object.keys(e).forEach(function(i) {
                    var n = e[i];
                    t(n);
                });
            }(t);
        }(t), Fi.target = null, t;
    }, t.prototype.update = function() {
        var t = this.get(), e = this.value;
        this.value = t, this.cb.call(this.$lucky, t, e);
    }, t;
}(), qi = function() {
    function e(t, e) {
        var i = this;
        this.version = "1.7.temp", this.htmlFontSize = 16, this.rAF = function() {}, this.boxWidth = 0, 
        this.boxHeight = 0, "string" == typeof t ? t = {
            el: t
        } : 1 === t.nodeType && (t = {
            el: "",
            divElement: t
        }), t = t, this.config = t, this.data = e, t.flag || (t.flag = "WEB"), t.el && (t.divElement = document.querySelector(t.el)), 
        t.divElement && (t.canvasElement = document.createElement("canvas"), t.divElement.appendChild(t.canvasElement)), 
        t.canvasElement && (t.ctx = t.canvasElement.getContext("2d"), t.canvasElement.setAttribute("package", "lucky-canvas@1.7.temp"), 
        t.canvasElement.addEventListener("click", function(t) {
            return i.handleClick(t);
        })), this.ctx = t.ctx, this.initWindowFunction(), this.config.ctx || console.error("无法获取到 CanvasContext2D"), 
        window && "function" == typeof window.addEventListener && window.addEventListener("resize", function(t, e) {
            void 0 === e && (e = 300);
            var i = null;
            return function() {
                for (var n = this, r = [], o = 0; o < arguments.length; o++) r[o] = arguments[o];
                i || (i = setTimeout(function() {
                    t.apply(n, r), clearTimeout(i), i = null;
                }, e));
            };
        }(function() {
            return i.resize();
        }, 300)), window && "function" == typeof window.MutationObserver && new window.MutationObserver(function() {
            i.resize();
        }).observe(document.documentElement, {
            attributes: !0
        });
    }
    return e.prototype.resize = function() {
        var t, e;
        null === (e = (t = this.config).beforeResize) || void 0 === e || e.call(t), this.setHTMLFontSize(), 
        this.setDpr(), this.resetWidthAndHeight(), this.zoomCanvas();
    }, e.prototype.initLucky = function() {
        if (this.resize(), !this.boxWidth || !this.boxHeight) return console.error("无法获取到宽度或高度");
    }, e.prototype.handleClick = function(t) {}, e.prototype.setHTMLFontSize = function() {
        window && (this.htmlFontSize = +window.getComputedStyle(document.documentElement).fontSize.slice(0, -2));
    }, e.prototype.clearCanvas = function() {
        var t = [ this.boxWidth, this.boxHeight ], e = t[0], i = t[1];
        this.ctx.clearRect(-e, -i, 2 * e, 2 * i);
    }, e.prototype.setDpr = function() {
        var t = this.config;
        t.dpr || (window ? window.dpr = t.dpr = window.devicePixelRatio || 1 : t.dpr || console.error(t, "未传入 dpr 可能会导致绘制异常"));
    }, e.prototype.resetWidthAndHeight = function() {
        var t = this.config, e = this.data, i = 0, n = 0;
        t.divElement && (i = t.divElement.offsetWidth, n = t.divElement.offsetHeight), this.boxWidth = this.getLength(e.width || t.width) || i, 
        this.boxHeight = this.getLength(e.height || t.height) || n, t.divElement && (t.divElement.style.overflow = "hidden", 
        t.divElement.style.width = this.boxWidth + "px", t.divElement.style.height = this.boxHeight + "px");
    }, e.prototype.zoomCanvas = function() {
        var t = this.config, e = this.ctx, i = t.canvasElement, n = t.dpr, r = [ this.boxWidth * n, this.boxHeight * n ], o = r[0], a = r[1];
        i && (i.width = o, i.height = a, i.style.width = o + "px", i.style.height = a + "px", 
        i.style["transform-origin"] = "left top", i.style.transform = "scale(" + 1 / n + ")", 
        e.scale(n, n));
    }, e.prototype.initWindowFunction = function() {
        var t = this.config;
        if (window) return this.rAF = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || function(t) {
            window.setTimeout(t, 1e3 / 60);
        }, t.setTimeout = window.setTimeout, t.setInterval = window.setInterval, t.clearTimeout = window.clearTimeout, 
        void (t.clearInterval = window.clearInterval);
        if (t.rAF) this.rAF = t.rAF; else if (t.setTimeout) {
            var e = t.setTimeout;
            this.rAF = function(t) {
                return e(t, 16.7);
            };
        } else this.rAF = function(t) {
            return setTimeout(t, 16.7);
        };
    }, e.prototype.loadImg = function(t, e, i) {
        var n = this;
        return void 0 === i && (i = "$resolve"), new Promise(function(r, o) {
            if (t || o("=> '" + e.src + "' 不能为空或不合法"), "WEB" !== n.config.flag) return e[i] = r, 
            void (e.$reject = o);
            var a = new Image();
            a.onload = function() {
                return r(a);
            }, a.onerror = function() {
                return o("=> '" + e.src + "' 图片加载失败");
            }, a.src = t;
        });
    }, e.prototype.drawImage = function(t, e) {
        for (var i, n = [], r = 2; r < arguments.length; r++) n[r - 2] = arguments[r];
        var o = this.config, s = o.flag, c = o.dpr;
        if ([ "WEB", "MP-WX" ].includes(s)) i = e; else {
            if (![ "UNI-H5", "UNI-MP", "TARO-H5", "TARO-MP" ].includes(s)) return console.error("意料之外的 flag, 该平台尚未兼容!");
            i = e.path;
        }
        return 8 === n.length && (n = n.map(function(t, e) {
            return e < 4 ? t * c : t;
        })), t.drawImage.apply(t, a([ i ], n));
    }, e.prototype.getLength = function(t) {
        return Oi(t, "number") ? t : Oi(t, "string") ? this.changeUnits(t) : 0;
    }, e.prototype.changeUnits = function(t, e) {
        var i = this;
        return void 0 === e && (e = 1), Number(t.replace(/^([-]*[0-9.]*)([a-z%]*)$/, function(t, n, r) {
            var o = {
                "%": function(t) {
                    return t * (e / 100);
                },
                px: function(t) {
                    return 1 * t;
                },
                rem: function(t) {
                    return t * i.htmlFontSize;
                },
                vw: function(t) {
                    return t / 100 * window.innerWidth;
                }
            }[r];
            if (o) return o(n);
            var a = i.config.unitFunc;
            return a ? a(n, r) : n;
        }));
    }, e.prototype.computedWidthAndHeight = function(t, e, i, n) {
        if (!e.width && !e.height) return [ t.width, t.height ];
        if (e.width && !e.height) {
            var r = this.getWidth(e.width, i);
            return [ r, t.height * (r / t.width) ];
        }
        if (!e.width && e.height) {
            var o = this.getHeight(e.height, n);
            return [ t.width * (o / t.height), o ];
        }
        return [ this.getWidth(e.width, i), this.getHeight(e.height, n) ];
    }, e.prototype.getWidth = function(t, e) {
        return Oi(t, "number") ? t : Oi(t, "string") ? this.changeUnits(t, e) : 0;
    }, e.prototype.getHeight = function(t, e) {
        return Oi(t, "number") ? t : Oi(t, "string") ? this.changeUnits(t, e) : 0;
    }, e.prototype.getOffsetX = function(t, e) {
        return void 0 === e && (e = 0), (e - t) / 2;
    }, e.prototype.getOffscreenCanvas = function(t, e) {
        if (!Ii(this, "_offscreenCanvas")) {
            if (!window || !window.document) return console.error("无法创建离屏Canvas!");
            this._offscreenCanvas = document.createElement("canvas");
        }
        var i = this.config.dpr, n = this._offscreenCanvas;
        n.width = (t || 300) * i, n.height = (e || 150) * i;
        var r = n.getContext("2d");
        return r.clearRect(0, 0, t, e), r.scale(i, i), r.dpr = i, {
            _offscreenCanvas: n,
            _ctx: r
        };
    }, e.prototype.$clip = function(t) {
        for (var e = this, i = [], n = 1; n < arguments.length; n++) i[n - 1] = arguments[n];
        var r = i.map(function(t) {
            return e.getLength(t);
        });
        return ji.apply(void 0, a([ t ], r));
    }, e.prototype.$opacity = function(t, e) {
        return function(t, e) {
            var i = document.createElement("canvas"), n = i.getContext("2d"), r = t.width, o = t.height;
            if (i.width = r, i.height = o, "string" == typeof n.filter) n.filter = "opacity(" + e + "%)", 
            n.drawImage(t, 0, 0, r, o); else {
                n.drawImage(t, 0, 0, r, o);
                for (var a = n.getImageData(0, 0, r, o), s = a.data, c = s.length, u = 0; u < c; u += 4) {
                    var h = s[u + 3];
                    0 !== h && (s[u + 3] = h * e / 100);
                }
                n.putImageData(a, 0, 0);
            }
            return i;
        }(t, this.getLength(e));
    }, e.prototype.$blur = function(t, e) {
        return function(t, e) {
            var i = document.createElement("canvas"), n = i.getContext("2d"), r = t.width, o = t.height;
            i.width = r, i.height = o, n.drawImage(t, 0, 0, r, o);
            var a = n.getImageData(0, 0, r, o), s = a.data, c = function(t, e) {
                e = e || t / 3;
                for (var i = Math.ceil(t), n = e * e, r = 2 * n, o = 1 / (2 * Math.PI * n), a = [], s = 0, c = -i; c <= i; c++) for (var u = -i; u <= i; u++) {
                    var h = o * Math.exp(-(c * c + u * u) / r);
                    a.push(h), s += h;
                }
                for (var l = 0; l < a.length; l++) a[l] /= s;
                return a;
            }(e);
            return s.length, c.length, console.log(a), n.putImageData(a, 0, 0), i;
        }(t, this.getLength(e));
    }, e.prototype.$set = function(e, i, n) {
        e && "object" == t(e) && Ni(e, i, n);
    }, e.prototype.$computed = function(t, e, i) {
        var n = this;
        Object.defineProperty(t, e, {
            get: function() {
                return i.call(n);
            }
        });
    }, e.prototype.$watch = function(e, i, n) {
        void 0 === n && (n = {}), "object" == t(i) && (i = (n = i).handler);
        var r = new Xi(this, e, i, n);
        return n.immediate && i.call(this, r.value), function() {};
    }, e;
}(), Ui = function(t, e, i, n) {
    return t >= n && (t = n), i * (t /= n) * t + e;
}, Yi = function(t, e, i, n) {
    return t >= n && (t = n), -i * (t /= n) * (t - 2) + e;
};

exports.LuckyWheel = function(t) {
    function e(e, i) {
        var n, r = t.call(this, e, {
            width: i.width,
            height: i.height
        }) || this;
        return r.blocks = [], r.prizes = [], r.buttons = [], r.defaultConfig = {}, r.defaultStyle = {}, 
        r._defaultConfig = {}, r._defaultStyle = {}, r.Radius = 0, r.prizeRadius = 0, r.prizeDeg = 0, 
        r.prizeRadian = 0, r.rotateDeg = 0, r.maxBtnRadius = 0, r.startTime = 0, r.endTime = 0, 
        r.stopDeg = 0, r.endDeg = 0, r.FPS = 16.6, r.step = 0, r.ImageCache = {
            blocks: [],
            prizes: [],
            buttons: []
        }, r.initData(i), r.initWatch(), r.initComputed(), null === (n = e.beforeCreate) || void 0 === n || n.call(r), 
        r.init(), r;
    }
    return i(e, t), e.prototype.resize = function() {
        var e, i;
        t.prototype.resize.call(this), this.Radius = Math.min(this.boxWidth, this.boxHeight) / 2, 
        this.ctx.translate(this.Radius, this.Radius), this.draw(), null === (i = (e = this.config).afterResize) || void 0 === i || i.call(e);
    }, e.prototype.initLucky = function() {
        this.Radius = 0, this.prizeRadius = 0, this.prizeDeg = 0, this.prizeRadian = 0, 
        this.rotateDeg = 0, this.maxBtnRadius = 0, this.startTime = 0, this.endTime = 0, 
        this.stopDeg = 0, this.endDeg = 0, this.FPS = 16.6, this.prizeFlag = -1, this.step = 0, 
        t.prototype.initLucky.call(this);
    }, e.prototype.initData = function(t) {
        this.$set(this, "width", t.width || "300px"), this.$set(this, "height", t.height || "300px"), 
        this.$set(this, "blocks", t.blocks || []), this.$set(this, "prizes", t.prizes || []), 
        this.$set(this, "buttons", t.buttons || []), this.$set(this, "defaultConfig", t.defaultConfig || {}), 
        this.$set(this, "defaultStyle", t.defaultStyle || {}), this.$set(this, "startCallback", t.start), 
        this.$set(this, "endCallback", t.end);
    }, e.prototype.initComputed = function() {
        var t = this;
        this.$computed(this, "_defaultConfig", function() {
            return n({
                gutter: "0px",
                offsetDegree: 0,
                speed: 20,
                speedFunction: "quad",
                accelerationTime: 2500,
                decelerationTime: 2500,
                stopRange: 0
            }, t.defaultConfig);
        }), this.$computed(this, "_defaultStyle", function() {
            return n({
                fontSize: "18px",
                fontColor: "#000",
                fontStyle: "sans-serif",
                fontWeight: "400",
                background: "rgba(0,0,0,0)",
                wordWrap: !0,
                lengthLimit: "90%"
            }, t.defaultStyle);
        });
    }, e.prototype.initWatch = function() {
        var t = this;
        this.$watch("width", function(e) {
            t.data.width = e, t.resize();
        }), this.$watch("height", function(e) {
            t.data.height = e, t.resize();
        }), this.$watch("blocks", function(e) {
            t.initImageCache();
        }, {
            deep: !0
        }), this.$watch("prizes", function(e) {
            t.initImageCache();
        }, {
            deep: !0
        }), this.$watch("buttons", function(e) {
            t.initImageCache();
        }, {
            deep: !0
        }), this.$watch("defaultConfig", function() {
            return t.draw();
        }, {
            deep: !0
        }), this.$watch("defaultStyle", function() {
            return t.draw();
        }, {
            deep: !0
        }), this.$watch("startCallback", function() {
            return t.init();
        }), this.$watch("endCallback", function() {
            return t.init();
        });
    }, e.prototype.init = function() {
        var t, e;
        return r(this, void 0, void 0, function() {
            var i;
            return o(this, function(n) {
                switch (n.label) {
                  case 0:
                    return this.initLucky(), i = this.config, null === (t = i.beforeInit) || void 0 === t || t.call(this), 
                    this.draw(), this.draw(), [ 4, this.initImageCache() ];

                  case 1:
                    return n.sent(), null === (e = i.afterInit) || void 0 === e || e.call(this), [ 2 ];
                }
            });
        });
    }, e.prototype.initImageCache = function() {
        var t = this;
        return new Promise(function(e) {
            var i = {
                blocks: t.blocks.map(function(t) {
                    return t.imgs;
                }),
                prizes: t.prizes.map(function(t) {
                    return t.imgs;
                }),
                buttons: t.buttons.map(function(t) {
                    return t.imgs;
                })
            };
            Object.keys(i).forEach(function(n) {
                var r = i[n], o = [];
                r && r.forEach(function(e, i) {
                    e && e.forEach(function(e, r) {
                        o.push(t.loadAndCacheImg(n, i, n, r));
                    });
                }), Promise.all(o).then(function() {
                    t.draw(), e();
                });
            });
        });
    }, e.prototype.handleClick = function(t) {
        var e, i = this.ctx;
        i.beginPath(), i.arc(0, 0, this.maxBtnRadius, 0, 2 * Math.PI, !1), i.isPointInPath(t.offsetX, t.offsetY) && 0 === this.step && (null === (e = this.startCallback) || void 0 === e || e.call(this, t));
    }, e.prototype.loadAndCacheImg = function(t, e, i, n) {
        return r(this, void 0, void 0, function() {
            var r = this;
            return o(this, function(o) {
                return [ 2, new Promise(function(o, a) {
                    var s = r[t][e];
                    if (s && s.imgs) {
                        var c = s.imgs[n];
                        if (c) {
                            var u = r.ImageCache;
                            u[i][e] || (u[i][e] = []), r.loadImg(c.src, c).then(function(t) {
                                "function" == typeof c.formatter && (t = c.formatter.call(r, t)), u[i][e][n] = t, 
                                o();
                            }).catch(function(i) {
                                console.error(t + "[" + e + "].imgs[" + n + "] " + i), a();
                            });
                        }
                    }
                }) ];
            });
        });
    }, e.prototype.draw = function() {
        var t, e, i = this, n = this, r = n.config, o = n.ctx, a = n._defaultConfig, s = n._defaultStyle;
        null === (t = r.beforeDraw) || void 0 === t || t.call(this, o), o.clearRect(-this.Radius, -this.Radius, 2 * this.Radius, 2 * this.Radius), 
        this.prizeRadius = this.blocks.reduce(function(t, e, n) {
            return Ei(e.background) && (o.beginPath(), o.fillStyle = e.background, o.arc(0, 0, t, 0, 2 * Math.PI, !1), 
            o.fill()), e.imgs && e.imgs.forEach(function(e, r) {
                var a = i.ImageCache.blocks;
                if (a && a[n]) {
                    var s = a[n][r];
                    if (s) {
                        var c = i.computedWidthAndHeight(s, e, 2 * t, 2 * t), u = c[0], h = c[1], l = [ i.getOffsetX(u), i.getHeight(e.top, 2 * t) - t ], f = l[0], d = l[1];
                        o.save(), e.rotate && o.rotate(Wi(i.rotateDeg)), i.drawImage(o, s, f, d, u, h), 
                        o.restore();
                    }
                }
            }), t - i.getLength(e.padding && e.padding.split(" ")[0]);
        }, this.Radius), this.prizeDeg = 360 / this.prizes.length, this.prizeRadian = Wi(this.prizeDeg);
        var c = Wi(this.rotateDeg - 90 + this.prizeDeg / 2 + a.offsetDegree), u = function(t) {
            return i.getOffsetX(o.measureText(t).width);
        }, h = function(t, e, n) {
            var r = t.lineHeight || s.lineHeight || t.fontSize || s.fontSize;
            return i.getHeight(t.top, e) + (n + 1) * i.getLength(r);
        };
        o.save(), this.prizes.forEach(function(t, e) {
            var n = c + e * i.prizeRadian, r = i.prizeRadius - i.maxBtnRadius, l = t.background || s.background;
            Ei(l) && (o.fillStyle = l, function(t, e, i, n, r, o) {
                t.beginPath();
                var a, s, c = Wi(90 / Math.PI / i * o), u = n + c, h = r - c;
                t.arc(0, 0, i, u, h, !1), t.lineTo.apply(t, (a = (n + r) / 2, s = o / 2 / Math.abs(Math.sin((n - r) / 2)), 
                [ +(Math.cos(a) * s).toFixed(8), +(Math.sin(a) * s).toFixed(8) ])), t.closePath();
            }(o, i.maxBtnRadius, i.prizeRadius, n - i.prizeRadian / 2, n + i.prizeRadian / 2, i.getLength(a.gutter)), 
            o.fill());
            var f = Math.cos(n) * i.prizeRadius, d = Math.sin(n) * i.prizeRadius;
            o.translate(f, d), o.rotate(n + Wi(90)), t.imgs && t.imgs.forEach(function(t, n) {
                var a = i.ImageCache.prizes;
                if (a && a[e]) {
                    var s = a[e][n];
                    if (s) {
                        var c = i.computedWidthAndHeight(s, t, i.prizeRadian * i.prizeRadius, r), u = c[0], h = c[1], l = [ i.getOffsetX(u), i.getHeight(t.top, r) ], f = l[0], d = l[1];
                        i.drawImage(o, s, f, d, u, h);
                    }
                }
            }), t.fonts && t.fonts.forEach(function(t) {
                var e = t.fontColor || s.fontColor, n = t.fontWeight || s.fontWeight, c = i.getLength(t.fontSize || s.fontSize), l = t.fontStyle || s.fontStyle, f = Object.prototype.hasOwnProperty.call(t, "wordWrap") ? t.wordWrap : s.wordWrap, d = t.lengthLimit || s.lengthLimit, p = t.lineClamp || s.lineClamp;
                o.fillStyle = e, o.font = n + " " + (c >> 0) + "px " + l;
                var g = String(t.text);
                (f ? _i(o, Ti(g), function(e) {
                    var n = (i.prizeRadius - h(t, r, e.length)) * Math.tan(i.prizeRadian / 2) * 2 - i.getLength(a.gutter);
                    return i.getWidth(d, n);
                }, p) : g.split("\n")).filter(function(t) {
                    return !!t;
                }).forEach(function(e, i) {
                    o.fillText(e, u(e), h(t, r, i));
                });
            }), o.rotate(Wi(360) - n - Wi(90)), o.translate(-f, -d);
        }), o.restore(), this.buttons.forEach(function(t, e) {
            var n = i.getHeight(t.radius, i.prizeRadius);
            i.maxBtnRadius = Math.max(i.maxBtnRadius, n), Ei(t.background) && (o.beginPath(), 
            o.fillStyle = t.background, o.arc(0, 0, n, 0, 2 * Math.PI, !1), o.fill()), t.pointer && Ei(t.background) && (o.beginPath(), 
            o.fillStyle = t.background, o.moveTo(-n, 0), o.lineTo(n, 0), o.lineTo(0, 2 * -n), 
            o.closePath(), o.fill()), t.imgs && t.imgs.forEach(function(t, r) {
                var a = i.ImageCache.buttons;
                if (a && a[e]) {
                    var s = a[e][r];
                    if (s) {
                        var c = i.computedWidthAndHeight(s, t, 2 * n, 2 * n), u = c[0], h = c[1], l = [ i.getOffsetX(u), i.getHeight(t.top, n) ], f = l[0], d = l[1];
                        i.drawImage(o, s, f, d, u, h);
                    }
                }
            }), t.fonts && t.fonts.forEach(function(t) {
                var e = t.fontColor || s.fontColor, r = t.fontWeight || s.fontWeight, a = i.getLength(t.fontSize || s.fontSize), c = t.fontStyle || s.fontStyle;
                o.fillStyle = e, o.font = r + " " + (a >> 0) + "px " + c, String(t.text).split("\n").forEach(function(e, i) {
                    o.fillText(e, u(e), h(t, n, i));
                });
            });
        }), null === (e = r.afterDraw) || void 0 === e || e.call(this, o);
    }, e.prototype.carveOnGunwaleOfAMovingBoat = function() {
        var t = this, e = t._defaultConfig, i = t.prizeFlag, n = t.prizeDeg, r = t.rotateDeg;
        this.endTime = Date.now();
        for (var o = this.stopDeg = r, a = e.speed, s = (Math.random() * n - n / 2) * this.getLength(e.stopRange), c = 0, u = 0, h = 0; ++c; ) {
            var l = 360 * c - i * n - r - e.offsetDegree + s - n / 2, f = Yi(this.FPS, o, l, e.decelerationTime) - o;
            if (f > a) {
                this.endDeg = a - u > f - a ? l : h;
                break;
            }
            h = l, u = f;
        }
    }, e.prototype.play = function() {
        var t, e;
        0 === this.step && (this.startTime = Date.now(), this.prizeFlag = void 0, this.step = 1, 
        null === (e = (t = this.config).afterStart) || void 0 === e || e.call(t), this.run());
    }, e.prototype.stop = function(t) {
        if (0 !== this.step && 3 !== this.step) {
            if (!t && 0 !== t) {
                var e = this.prizes.map(function(t) {
                    return t.range;
                });
                t = Pi(e);
            }
            t < 0 ? (this.step = 0, this.prizeFlag = -1) : (this.step = 2, this.prizeFlag = t % this.prizes.length);
        }
    }, e.prototype.run = function(t) {
        var e;
        void 0 === t && (t = 0);
        var i = this, n = i.rAF, r = i.step, o = i.prizeFlag, a = i.stopDeg, s = i.endDeg, c = i._defaultConfig, u = c.accelerationTime, h = c.decelerationTime, l = c.speed;
        if (0 !== r) {
            if (-1 !== o) {
                3 !== r || this.endDeg || this.carveOnGunwaleOfAMovingBoat();
                var f = Date.now() - this.startTime, d = Date.now() - this.endTime, p = this.rotateDeg;
                if (1 === r || f < u) {
                    this.FPS = f / t;
                    var g = Ui(f, 0, l, u);
                    g === l && (this.step = 2), p += g % 360;
                } else 2 === r ? (p += l % 360, void 0 !== o && o >= 0 && (this.step = 3, this.stopDeg = 0, 
                this.endDeg = 0)) : 3 === r ? (p = Yi(d, a, s, h), d >= h && (this.step = 0)) : this.stop(-1);
                this.rotateDeg = p, this.draw(), n(this.run.bind(this, t + 1));
            }
        } else null === (e = this.endCallback) || void 0 === e || e.call(this, this.prizes.find(function(t, e) {
            return e === o;
        }) || {});
    }, e.prototype.conversionAxis = function(t, e) {
        var i = this.config;
        return [ t / i.dpr - this.Radius, e / i.dpr - this.Radius ];
    }, e;
}(qi), exports.LuckyGrid = function(t) {
    function e(e, i) {
        var n, r = t.call(this, e, {
            width: i.width,
            height: i.height
        }) || this;
        return r.rows = 3, r.cols = 3, r.blocks = [], r.prizes = [], r.buttons = [], r.defaultConfig = {}, 
        r.defaultStyle = {}, r.activeStyle = {}, r._defaultConfig = {}, r._defaultStyle = {}, 
        r._activeStyle = {}, r.cellWidth = 0, r.cellHeight = 0, r.startTime = 0, r.endTime = 0, 
        r.currIndex = 0, r.stopIndex = 0, r.endIndex = 0, r.demo = !1, r.timer = 0, r.FPS = 16.6, 
        r.step = 0, r.prizeFlag = -1, r.cells = [], r.ImageCache = {
            blocks: [],
            prizes: [],
            buttons: []
        }, r.initData(i), r.initWatch(), r.initComputed(), null === (n = e.beforeCreate) || void 0 === n || n.call(r), 
        r.init(), r;
    }
    return i(e, t), e.prototype.resize = function() {
        var e, i;
        t.prototype.resize.call(this), this.draw(), null === (i = (e = this.config).afterResize) || void 0 === i || i.call(e);
    }, e.prototype.initLucky = function() {
        this.cellWidth = 0, this.cellHeight = 0, this.startTime = 0, this.endTime = 0, this.currIndex = 0, 
        this.stopIndex = 0, this.endIndex = 0, this.demo = !1, this.timer = 0, this.FPS = 16.6, 
        this.prizeFlag = -1, this.step = 0, t.prototype.initLucky.call(this);
    }, e.prototype.initData = function(t) {
        this.$set(this, "width", t.width || "300px"), this.$set(this, "height", t.height || "300px"), 
        this.$set(this, "rows", Number(t.rows) || 3), this.$set(this, "cols", Number(t.cols) || 3), 
        this.$set(this, "blocks", t.blocks || []), this.$set(this, "prizes", t.prizes || []), 
        this.$set(this, "buttons", t.buttons || []), this.$set(this, "button", t.button), 
        this.$set(this, "defaultConfig", t.defaultConfig || {}), this.$set(this, "defaultStyle", t.defaultStyle || {}), 
        this.$set(this, "activeStyle", t.activeStyle || {}), this.$set(this, "startCallback", t.start), 
        this.$set(this, "endCallback", t.end);
    }, e.prototype.initComputed = function() {
        var t = this;
        this.$computed(this, "_defaultConfig", function() {
            var e = n({
                gutter: 5,
                speed: 20,
                accelerationTime: 2500,
                decelerationTime: 2500
            }, t.defaultConfig);
            return e.gutter = t.getLength(e.gutter), e.speed = e.speed / 40, e;
        }), this.$computed(this, "_defaultStyle", function() {
            return n({
                borderRadius: 20,
                fontColor: "#000",
                fontSize: "18px",
                fontStyle: "sans-serif",
                fontWeight: "400",
                background: "rgba(0,0,0,0)",
                shadow: "",
                wordWrap: !0,
                lengthLimit: "90%"
            }, t.defaultStyle);
        }), this.$computed(this, "_activeStyle", function() {
            return n({
                background: "#ffce98",
                shadow: ""
            }, t.activeStyle);
        });
    }, e.prototype.initWatch = function() {
        var t = this;
        this.$watch("width", function(e) {
            t.data.width = e, t.resize();
        }), this.$watch("height", function(e) {
            t.data.height = e, t.resize();
        }), this.$watch("blocks", function(e) {
            t.initImageCache();
        }, {
            deep: !0
        }), this.$watch("prizes", function(e) {
            t.initImageCache();
        }, {
            deep: !0
        }), this.$watch("buttons", function(e) {
            t.initImageCache();
        }, {
            deep: !0
        }), this.$watch("rows", function() {
            return t.init();
        }), this.$watch("cols", function() {
            return t.init();
        }), this.$watch("defaultConfig", function() {
            return t.draw();
        }, {
            deep: !0
        }), this.$watch("defaultStyle", function() {
            return t.draw();
        }, {
            deep: !0
        }), this.$watch("activeStyle", function() {
            return t.draw();
        }, {
            deep: !0
        }), this.$watch("startCallback", function() {
            return t.init();
        }), this.$watch("endCallback", function() {
            return t.init();
        });
    }, e.prototype.init = function() {
        var t, e;
        return r(this, void 0, void 0, function() {
            var i;
            return o(this, function(n) {
                switch (n.label) {
                  case 0:
                    return this.initLucky(), i = this.config, null === (t = i.beforeInit) || void 0 === t || t.call(this), 
                    this.draw(), [ 4, this.initImageCache() ];

                  case 1:
                    return n.sent(), null === (e = i.afterInit) || void 0 === e || e.call(this), [ 2 ];
                }
            });
        });
    }, e.prototype.initImageCache = function() {
        var t = this;
        return new Promise(function(e) {
            var i = t.buttons.map(function(t) {
                return t.imgs;
            });
            t.button && i.push(t.button.imgs);
            var n = {
                blocks: t.blocks.map(function(t) {
                    return t.imgs;
                }),
                prizes: t.prizes.map(function(t) {
                    return t.imgs;
                }),
                buttons: i
            };
            Object.keys(n).forEach(function(i) {
                var r = n[i], o = [];
                r && r.forEach(function(e, n) {
                    e && e.forEach(function(e, r) {
                        o.push(t.loadAndCacheImg(i, n, i, r));
                    });
                }), Promise.all(o).then(function() {
                    t.draw(), e();
                });
            });
        });
    }, e.prototype.handleClick = function(t) {
        var e = this, i = this.ctx;
        a(a([], this.buttons), [ this.button ]).forEach(function(n) {
            var r;
            if (n) {
                var o = e.getGeometricProperty([ n.x, n.y, n.col || 1, n.row || 1 ]), a = o[0], s = o[1], c = o[2], u = o[3];
                i.beginPath(), i.rect(a, s, c, u), i.isPointInPath(t.offsetX, t.offsetY) && 0 === e.step && ("function" == typeof n.callback && n.callback.call(e, n), 
                null === (r = e.startCallback) || void 0 === r || r.call(e, t, n));
            }
        });
    }, e.prototype.loadAndCacheImg = function(t, e, i, n) {
        return r(this, void 0, void 0, function() {
            var r = this;
            return o(this, function(o) {
                return [ 2, new Promise(function(o, a) {
                    var s = r[t][e];
                    if ("buttons" === t && !r.buttons.length && r.button && (s = r.button), s && s.imgs) {
                        var c = s.imgs[n];
                        if (c) {
                            var u = r.ImageCache;
                            u[i][e] || (u[i][e] = []);
                            var h = [ r.loadImg(c.src, c), c.activeSrc && r.loadImg(c.activeSrc, c, "$activeResolve") ];
                            Promise.all(h).then(function(t) {
                                var a = t[0], s = t[1], h = c.formatter;
                                "function" == typeof h && (a = h.call(r, a), s && (s = h.call(r, s))), u[i][e][n] = {
                                    defaultImg: a,
                                    activeImg: s
                                }, o();
                            }).catch(function(i) {
                                console.error(t + "[" + e + "].imgs[" + n + "] " + i), a();
                            });
                        }
                    }
                }) ];
            });
        });
    }, e.prototype.draw = function() {
        var t, e, i = this, n = this, r = n.config, o = n.ctx, s = n._defaultConfig, c = n._defaultStyle, u = n._activeStyle;
        null === (t = r.beforeDraw) || void 0 === t || t.call(this, o), o.clearRect(0, 0, this.boxWidth, this.boxHeight), 
        this.cells = a(a([], this.prizes), this.buttons), this.button && this.cells.push(this.button), 
        this.cells.forEach(function(t) {
            t.col = t.col || 1, t.row = t.row || 1;
        }), this.prizeArea = this.blocks.reduce(function(t, e, n) {
            var r = t.x, a = t.y, s = t.w, u = t.h, h = Ai(e), l = h[0], f = h[1], d = h[2], p = h[3], g = e.borderRadius ? i.getLength(e.borderRadius) : 0, v = e.background || c.background;
            return Ei(v) && (o.fillStyle = i.handleBackground(r, a, s, u, v), $i(o, r, a, s, u, g), 
            o.fill()), e.imgs && e.imgs.forEach(function(t, e) {
                var c = ki(i.ImageCache, "blocks." + n + "." + e + ".defaultImg");
                if (c) {
                    var h = i.computedWidthAndHeight(c, t, s, u), l = h[0], f = h[1], d = [ i.getOffsetX(l, s), i.getHeight(t.top, u) ], p = d[0], g = d[1];
                    i.drawImage(o, c, r + p, a + g, l, f);
                }
            }), {
                x: r + d,
                y: a + l,
                w: s - d - p,
                h: u - l - f
            };
        }, {
            x: 0,
            y: 0,
            w: this.boxWidth,
            h: this.boxHeight
        }), this.cellWidth = (this.prizeArea.w - s.gutter * (this.cols - 1)) / this.cols, 
        this.cellHeight = (this.prizeArea.h - s.gutter * (this.rows - 1)) / this.rows, this.cells.forEach(function(t, e) {
            var n = i.getGeometricProperty([ t.x, t.y, t.col, t.row ]), a = n[0], s = n[1], h = n[2], l = n[3], f = !1;
            (void 0 === i.prizeFlag || i.prizeFlag > -1) && (f = e === i.currIndex % i.prizes.length >> 0);
            var d = f ? u.background : t.background || c.background;
            if (Ei(d)) {
                var p = (f ? u.shadow : t.shadow || c.shadow).replace(/px/g, "").split(",")[0].split(" ").map(function(t, e) {
                    return e < 3 ? Number(t) : t;
                });
                4 === p.length && (o.shadowColor = p[3], o.shadowOffsetX = p[0] * r.dpr, o.shadowOffsetY = p[1] * r.dpr, 
                o.shadowBlur = p[2], p[0] > 0 ? h -= p[0] : (h += p[0], a -= p[0]), p[1] > 0 ? l -= p[1] : (l += p[1], 
                s -= p[1])), o.fillStyle = i.handleBackground(a, s, h, l, d);
                var g = i.getLength(t.borderRadius ? t.borderRadius : c.borderRadius);
                $i(o, a, s, h, l, g), o.fill(), o.shadowColor = "rgba(0, 0, 0, 0)", o.shadowOffsetX = 0, 
                o.shadowOffsetY = 0, o.shadowBlur = 0;
            }
            var v = "prizes";
            e >= i.prizes.length && (v = "buttons", e -= i.prizes.length), t.imgs && t.imgs.forEach(function(t, n) {
                var r = i.ImageCache[v];
                if (r[e]) {
                    var c = r[e][n];
                    if (c) {
                        var u = f && c.activeImg || c.defaultImg;
                        if (u) {
                            var d = i.computedWidthAndHeight(u, t, h, l), p = d[0], g = d[1], m = [ a + i.getOffsetX(p, h), s + i.getHeight(t.top, l) ], y = m[0], w = m[1];
                            i.drawImage(o, u, y, w, p, g);
                        }
                    }
                }
            }), t.fonts && t.fonts.forEach(function(t) {
                var e = f && u.fontStyle ? u.fontStyle : t.fontStyle || c.fontStyle, n = f && u.fontWeight ? u.fontWeight : t.fontWeight || c.fontWeight, r = f && u.fontSize ? i.getLength(u.fontSize) : i.getLength(t.fontSize || c.fontSize), d = f && u.lineHeight ? u.lineHeight : t.lineHeight || c.lineHeight || t.fontSize || c.fontSize, p = Object.prototype.hasOwnProperty.call(t, "wordWrap") ? t.wordWrap : c.wordWrap, g = t.lengthLimit || c.lengthLimit, v = t.lineClamp || c.lineClamp;
                o.font = n + " " + (r >> 0) + "px " + e, o.fillStyle = f && u.fontColor ? u.fontColor : t.fontColor || c.fontColor;
                var m = [], y = String(t.text);
                if (p) {
                    var w = i.getWidth(g, h);
                    m = _i(o, Ti(y), function() {
                        return w;
                    }, v);
                } else m = y.split("\n");
                m.forEach(function(e, n) {
                    o.fillText(e, a + i.getOffsetX(o.measureText(e).width, h), s + i.getHeight(t.top, l) + (n + 1) * i.getLength(d));
                });
            });
        }), null === (e = r.afterDraw) || void 0 === e || e.call(this, o);
    }, e.prototype.handleBackground = function(t, e, i, n, r) {
        var o = this.ctx;
        return r.includes("linear-gradient") && (r = function(t, e, i, n, r, o) {
            var a = /linear-gradient\((.+)\)/.exec(o)[1].split(",").map(function(t) {
                return t.trim();
            }), s = a.shift(), c = [ 0, 0, 0, 0 ];
            if (s.includes("deg")) {
                var u = function(t) {
                    return Math.tan(t / 180 * Math.PI);
                };
                (s = s.slice(0, -3) % 360) >= 0 && s < 45 ? c = [ e, i + r, e + n, i + r - n * u(s - 0) ] : s >= 45 && s < 90 ? c = [ e, i + r, e + n - r * u(s - 45), i ] : s >= 90 && s < 135 ? c = [ e + n, i + r, e + n - r * u(s - 90), i ] : s >= 135 && s < 180 ? c = [ e + n, i + r, e, i + n * u(s - 135) ] : s >= 180 && s < 225 ? c = [ e + n, i, e, i + n * u(s - 180) ] : s >= 225 && s < 270 ? c = [ e + n, i, e + r * u(s - 225), i + r ] : s >= 270 && s < 315 ? c = [ e, i, e + r * u(s - 270), i + r ] : s >= 315 && s < 360 && (c = [ e, i, e + n, i + r - n * u(s - 315) ]);
            } else s.includes("top") ? c = [ e, i + r, e, i ] : s.includes("bottom") ? c = [ e, i, e, i + r ] : s.includes("left") ? c = [ e + n, i, e, i ] : s.includes("right") && (c = [ e, i, e + n, i ]);
            var h = t.createLinearGradient.apply(t, c.map(function(t) {
                return t >> 0;
            }));
            return a.reduce(function(t, e, i) {
                var n = e.split(" ");
                return 1 === n.length ? t.addColorStop(i, n[0]) : 2 === n.length && t.addColorStop.apply(t, n), 
                t;
            }, h);
        }(o, t, e, i, n, r)), r;
    }, e.prototype.carveOnGunwaleOfAMovingBoat = function() {
        var t = this, e = t._defaultConfig, i = t.prizeFlag, n = t.currIndex;
        this.endTime = Date.now();
        for (var r = this.stopIndex = n, o = e.speed, a = 0, s = 0, c = 0; ++a; ) {
            var u = this.prizes.length * a + i - r, h = Yi(this.FPS, r, u, e.decelerationTime) - r;
            if (h > o) {
                this.endIndex = o - s > h - o ? u : c;
                break;
            }
            c = u, s = h;
        }
    }, e.prototype.play = function() {
        var t, e;
        0 === this.step && (this.startTime = Date.now(), this.prizeFlag = void 0, this.step = 1, 
        null === (e = (t = this.config).afterStart) || void 0 === e || e.call(t), this.run());
    }, e.prototype.stop = function(t) {
        if (0 !== this.step && 3 !== this.step) {
            if (!t && 0 !== t) {
                var e = this.prizes.map(function(t) {
                    return t.range;
                });
                t = Pi(e);
            }
            t < 0 ? (this.step = 0, this.prizeFlag = -1) : (this.step = 2, this.prizeFlag = t % this.prizes.length);
        }
    }, e.prototype.run = function(t) {
        var e;
        void 0 === t && (t = 0);
        var i = this, n = i.rAF, r = i.step, o = i.prizes, a = i.prizeFlag, s = i.stopIndex, c = i.endIndex, u = i._defaultConfig, h = u.accelerationTime, l = u.decelerationTime, f = u.speed;
        if (0 !== r) {
            if (-1 !== a) {
                3 !== r || this.endIndex || this.carveOnGunwaleOfAMovingBoat();
                var d = Date.now() - this.startTime, p = Date.now() - this.endTime, g = this.currIndex;
                if (1 === r || d < h) {
                    this.FPS = d / t;
                    var v = Ui(d, .1, f - .1, h);
                    v === f && (this.step = 2), g += v % o.length;
                } else 2 === r ? (g += f % o.length, void 0 !== a && a >= 0 && (this.step = 3, this.stopIndex = 0, 
                this.endIndex = 0)) : 3 === r ? (g = Yi(p, s, c, l), p >= l && (this.step = 0)) : this.stop(-1);
                this.currIndex = g, this.draw(), n(this.run.bind(this, t + 1));
            }
        } else null === (e = this.endCallback) || void 0 === e || e.call(this, this.prizes.find(function(t, e) {
            return e === a;
        }) || {});
    }, e.prototype.getGeometricProperty = function(t) {
        var e = t[0], i = t[1], n = t[2], r = void 0 === n ? 1 : n, o = t[3], a = void 0 === o ? 1 : o, s = this.cellWidth, c = this.cellHeight, u = this._defaultConfig.gutter, h = [ this.prizeArea.x + (s + u) * e, this.prizeArea.y + (c + u) * i ];
        return r && a && h.push(s * r + u * (r - 1), c * a + u * (a - 1)), h;
    }, e.prototype.conversionAxis = function(t, e) {
        var i = this.config;
        return [ t / i.dpr, e / i.dpr ];
    }, e;
}(qi), exports.SlotMachine = function(e) {
    function a(t, i) {
        var n, r = e.call(this, t, {
            width: i.width,
            height: i.height
        }) || this;
        return r.blocks = [], r.prizes = [], r.slots = [], r.defaultConfig = {}, r._defaultConfig = {}, 
        r.defaultStyle = {}, r._defaultStyle = {}, r.endCallback = function() {}, r.cellWidth = 0, 
        r.cellHeight = 0, r.cellAndSpacing = 0, r.widthAndSpacing = 0, r.heightAndSpacing = 0, 
        r.FPS = 16.6, r.scroll = [], r.stopScroll = [], r.endScroll = [], r.startTime = 0, 
        r.endTime = 0, r.step = 0, r.prizeFlag = void 0, r.ImageCache = {
            blocks: [],
            prizes: []
        }, r.initData(i), r.initWatch(), r.initComputed(), null === (n = t.beforeCreate) || void 0 === n || n.call(r), 
        r.init(), r;
    }
    return i(a, e), a.prototype.resize = function() {
        var t, i;
        e.prototype.resize.call(this), this.draw(), null === (i = (t = this.config).afterResize) || void 0 === i || i.call(t);
    }, a.prototype.initLucky = function() {
        this.cellWidth = 0, this.cellHeight = 0, this.cellAndSpacing = 0, this.widthAndSpacing = 0, 
        this.heightAndSpacing = 0, this.FPS = 16.6, this.scroll = [], this.stopScroll = [], 
        this.endScroll = [], this.startTime = 0, this.endTime = 0, this.prizeFlag = void 0, 
        this.step = 0, e.prototype.initLucky.call(this);
    }, a.prototype.initData = function(t) {
        this.$set(this, "width", t.width || "300px"), this.$set(this, "height", t.height || "300px"), 
        this.$set(this, "blocks", t.blocks || []), this.$set(this, "prizes", t.prizes || []), 
        this.$set(this, "slots", t.slots || []), this.$set(this, "defaultConfig", t.defaultConfig || {}), 
        this.$set(this, "defaultStyle", t.defaultStyle || {}), this.$set(this, "endCallback", t.end);
    }, a.prototype.initComputed = function() {
        var t = this;
        this.$computed(this, "_defaultConfig", function() {
            var e = n({
                mode: "vertical",
                rowSpacing: 0,
                colSpacing: 5,
                speed: 20,
                direction: 1,
                accelerationTime: 2500,
                decelerationTime: 2500
            }, t.defaultConfig);
            return e.rowSpacing = t.getLength(e.rowSpacing), e.colSpacing = t.getLength(e.colSpacing), 
            e;
        }), this.$computed(this, "_defaultStyle", function() {
            return n({
                borderRadius: 0,
                fontColor: "#000",
                fontSize: "18px",
                fontStyle: "sans-serif",
                fontWeight: "400",
                background: "rgba(0,0,0,0)",
                wordWrap: !0,
                lengthLimit: "90%"
            }, t.defaultStyle);
        });
    }, a.prototype.initWatch = function() {
        var t = this;
        this.$watch("width", function(e) {
            t.data.width = e, t.resize();
        }), this.$watch("height", function(e) {
            t.data.height = e, t.resize();
        }), this.$watch("blocks", function(e) {
            t.initImageCache();
        }, {
            deep: !0
        }), this.$watch("prizes", function(e) {
            t.initImageCache();
        }, {
            deep: !0
        }), this.$watch("slots", function(e) {
            t.drawOffscreenCanvas(), t.draw();
        }, {
            deep: !0
        }), this.$watch("defaultConfig", function() {
            return t.draw();
        }, {
            deep: !0
        }), this.$watch("defaultStyle", function() {
            return t.draw();
        }, {
            deep: !0
        }), this.$watch("endCallback", function() {
            return t.init();
        });
    }, a.prototype.init = function() {
        var t, e;
        return r(this, void 0, void 0, function() {
            var i;
            return o(this, function(n) {
                switch (n.label) {
                  case 0:
                    return this.initLucky(), i = this.config, null === (t = i.beforeInit) || void 0 === t || t.call(this), 
                    this.drawOffscreenCanvas(), this.draw(), [ 4, this.initImageCache() ];

                  case 1:
                    return n.sent(), null === (e = i.afterInit) || void 0 === e || e.call(this), [ 2 ];
                }
            });
        });
    }, a.prototype.initImageCache = function() {
        var t = this;
        return new Promise(function(e) {
            var i = {
                blocks: t.blocks.map(function(t) {
                    return t.imgs;
                }),
                prizes: t.prizes.map(function(t) {
                    return t.imgs;
                })
            };
            Object.keys(i).forEach(function(n) {
                var r = i[n], o = [];
                r && r.forEach(function(e, i) {
                    e && e.forEach(function(e, r) {
                        o.push(t.loadAndCacheImg(n, i, n, r));
                    });
                }), Promise.all(o).then(function() {
                    t.drawOffscreenCanvas(), t.draw(), e();
                });
            });
        });
    }, a.prototype.loadAndCacheImg = function(t, e, i, n) {
        return r(this, void 0, void 0, function() {
            var r = this;
            return o(this, function(o) {
                return [ 2, new Promise(function(o, a) {
                    var s = r[t][e];
                    if (s && s.imgs) {
                        var c = s.imgs[n];
                        if (c) {
                            var u = r.ImageCache;
                            u[i][e] || (u[i][e] = []), r.loadImg(c.src, c).then(function(t) {
                                "function" == typeof c.formatter && (t = c.formatter.call(r, t)), u[i][e][n] = t, 
                                o();
                            }).catch(function(i) {
                                console.error(t + "[" + e + "].imgs[" + n + "] " + i), a();
                            });
                        }
                    }
                }) ];
            });
        });
    }, a.prototype.drawOffscreenCanvas = function() {
        var t = this, e = this._defaultConfig, i = this._defaultStyle, n = this.drawBlocks(), r = n.w, o = n.h, a = this.prizes.length, s = this.displacementWidthOrHeight(), c = s.cellWidth, u = s.cellHeight, h = s.widthAndSpacing, l = s.heightAndSpacing, f = new Array(a).fill(void 0).map(function(t, e) {
            return e;
        }), d = 0, p = 0;
        this.slots.forEach(function(e, i) {
            void 0 === t.scroll[i] && (t.scroll[i] = 0), e.order = e.order || f;
            var n = e.order.length;
            d = Math.max(d, r + h * n), p = Math.max(p, o + l * n);
        });
        var g = this.getOffscreenCanvas(d, p), v = g._offscreenCanvas, m = g._ctx;
        this._offscreenCanvas = v, this.slots.forEach(function(n, r) {
            var o = c * r, a = u * r, s = 0, f = function(t, e) {
                for (var i = {}, n = [], r = 0; r < t.length; r++) i[r] = t[r];
                for (r = 0; r < e.length; r++) {
                    var o = i[e[r]];
                    o && (n[r] = o);
                }
                return n;
            }(t.prizes, n.order);
            if (f.length) {
                f.forEach(function(r, f) {
                    if (r) {
                        var d = n.order[f], p = h * f + e.colSpacing / 2, g = l * f + e.rowSpacing / 2, v = t.displacement([ o, g, l ], [ p, a, h ]), y = v[0], w = v[1], b = v[2];
                        s += b;
                        var S = r.background || i.background;
                        if (Ei(S)) {
                            var x = t.getLength(Ii(r, "borderRadius") ? r.borderRadius : i.borderRadius);
                            $i(m, y, w, c, c, x), m.fillStyle = S, m.fill();
                        }
                        r.imgs && r.imgs.forEach(function(e, i) {
                            var n = ki(t.ImageCache, "prizes." + d + "." + i);
                            if (n) {
                                var r = t.computedWidthAndHeight(n, e, c, u), o = r[0], a = r[1], s = [ y + t.getOffsetX(o, c), w + t.getHeight(e.top, u) ], h = s[0], l = s[1];
                                t.drawImage(m, n, h, l, o, a);
                            }
                        }), r.fonts && r.fonts.forEach(function(e) {
                            var n = e.fontStyle || i.fontStyle, r = e.fontWeight || i.fontWeight, o = t.getLength(e.fontSize || i.fontSize), a = e.lineHeight || i.lineHeight || e.fontSize || i.fontSize, s = Object.prototype.hasOwnProperty.call(e, "wordWrap") ? e.wordWrap : i.wordWrap, h = e.lengthLimit || i.lengthLimit, l = e.lineClamp || i.lineClamp;
                            m.font = r + " " + (o >> 0) + "px " + n, m.fillStyle = e.fontColor || i.fontColor;
                            var f = [], d = String(e.text);
                            if (s) {
                                var p = t.getWidth(h, c);
                                f = _i(m, Ti(d), function() {
                                    return p;
                                }, l);
                            } else f = d.split("\n");
                            f.forEach(function(i, n) {
                                m.fillText(i, y + t.getOffsetX(m.measureText(i).width, c), w + t.getHeight(e.top, u) + (n + 1) * t.getLength(a));
                            });
                        });
                    }
                });
                for (var d = t.displacement([ o, 0, c, s ], [ 0, a, s, u ]), g = d[0], y = d[1], w = d[2], b = d[3], S = s; S < p + s; ) {
                    var x = t.displacement([ g, S ], [ S, y ]), C = x[0], z = x[1];
                    t.drawImage(m, v, g, y, w, b, C, z, w, b), S += s;
                }
            }
        });
    }, a.prototype.drawBlocks = function() {
        var t = this, e = this;
        e.config;
        var i = e.ctx;
        e._defaultConfig;
        var n = e._defaultStyle;
        return this.prizeArea = this.blocks.reduce(function(e, r, o) {
            var a = e.x, s = e.y, c = e.w, u = e.h, h = Ai(r), l = h[0], f = h[1], d = h[2], p = h[3], g = r.borderRadius ? t.getLength(r.borderRadius) : 0, v = r.background || n.background;
            return Ei(v) && ($i(i, a, s, c, u, g), i.fillStyle = v, i.fill()), r.imgs && r.imgs.forEach(function(e, n) {
                var r = ki(t.ImageCache, "blocks." + o + "." + n);
                if (r) {
                    var h = t.computedWidthAndHeight(r, e, c, u), l = h[0], f = h[1], d = [ t.getOffsetX(l, c), t.getHeight(e.top, u) ], p = d[0], g = d[1];
                    t.drawImage(i, r, a + p, s + g, l, f);
                }
            }), {
                x: a + d,
                y: s + l,
                w: c - d - p,
                h: u - l - f
            };
        }, {
            x: 0,
            y: 0,
            w: this.boxWidth,
            h: this.boxHeight
        });
    }, a.prototype.draw = function() {
        var t, e = this, i = this, n = i.config, r = i.ctx;
        i._defaultConfig, i._defaultStyle, null === (t = n.beforeDraw) || void 0 === t || t.call(this, r), 
        r.clearRect(0, 0, this.boxWidth, this.boxHeight);
        var o = this.drawBlocks(), a = o.x, s = o.y, c = o.w, u = o.h;
        if (this._offscreenCanvas) {
            var h = this, l = h.cellWidth, f = h.cellHeight, d = h.cellAndSpacing, p = h.widthAndSpacing, g = h.heightAndSpacing;
            this.slots.forEach(function(t, i) {
                var n = d * t.order.length, o = e.displacement(-(u - g) / 2, -(c - p) / 2), h = e.scroll[i] + o;
                h < 0 && (h = h % n + n), h > n && (h %= n);
                var v = e.displacement([ l * i, h, l, u ], [ h, f * i, c, f ]), m = v[0], y = v[1], w = v[2], b = v[3], S = e.displacement([ a + p * i, s, l, u ], [ a, s + g * i, c, f ]), x = S[0], C = S[1], z = S[2], O = S[3];
                e.drawImage(r, e._offscreenCanvas, m, y, w, b, x, C, z, O);
            });
        }
    }, a.prototype.carveOnGunwaleOfAMovingBoat = function() {
        var t = this, e = this, i = e._defaultConfig, n = e.prizeFlag, r = e.cellAndSpacing;
        this.endTime = Date.now(), this.slots.forEach(function(e, o) {
            var a = e.order;
            if (a.length) for (var s = e.speed || i.speed, c = e.direction || i.direction, u = a.findIndex(function(t) {
                return t === n[o];
            }), h = r * a.length, l = t.stopScroll[o] = t.scroll[o], f = 0; ++f; ) {
                var d = r * u + h * f * c - l, p = Yi(t.FPS, l, d, i.decelerationTime) - l;
                if (Math.abs(p) > s) {
                    t.endScroll[o] = d;
                    break;
                }
            }
        });
    }, a.prototype.play = function() {
        0 === this.step && (this.startTime = Date.now(), this.prizeFlag = void 0, this.step = 1, 
        this.run());
    }, a.prototype.stop = function(e) {
        var i;
        if (0 !== this.step && 3 !== this.step) {
            if ("number" == typeof e) this.prizeFlag = new Array(this.slots.length).fill(e); else {
                if (!Oi(e, "array")) return this.stop(-1), console.error("stop() 无法识别的参数类型 " + t(e));
                if (e.length !== this.slots.length) return this.stop(-1), console.error("stop([" + e + "]) 参数长度的不正确");
                this.prizeFlag = e;
            }
            (null === (i = this.prizeFlag) || void 0 === i ? void 0 : i.includes(-1)) ? (this.prizeFlag = [], 
            this.step = 0) : this.step = 2;
        }
    }, a.prototype.run = function(t) {
        var e, i, n = this;
        void 0 === t && (t = 0);
        var r = this, o = r.rAF, a = r.step, s = r.prizeFlag, c = r._defaultConfig, u = r.cellAndSpacing, h = r.slots, l = c.accelerationTime, f = c.decelerationTime;
        if (0 !== this.step || (null == s ? void 0 : s.length) !== h.length) {
            if (void 0 === s || s.length) {
                3 !== this.step || this.endScroll.length || this.carveOnGunwaleOfAMovingBoat();
                var d = Date.now() - this.startTime, p = Date.now() - this.endTime;
                h.forEach(function(e, i) {
                    var r = e.order;
                    if (r && r.length) {
                        var o = u * r.length, g = Math.abs(e.speed || c.speed), v = e.direction || c.direction, m = 0, y = n.scroll[i];
                        if (1 === a || d < l) {
                            n.FPS = d / t;
                            var w = Ui(d, 0, g, l);
                            w === g && (n.step = 2), m = (y + w * v) % o;
                        } else if (2 === a) m = (y + g * v) % o, (null == s ? void 0 : s.length) === h.length && (n.step = 3, 
                        n.stopScroll = [], n.endScroll = []); else if (3 === a && p) {
                            var b = n.stopScroll[i], S = n.endScroll[i];
                            m = Yi(p, b, S, f), p >= f && (n.step = 0);
                        }
                        n.scroll[i] = m;
                    }
                }), this.draw(), o(this.run.bind(this, t + 1));
            }
        } else {
            for (var g = s[0], v = 0; v < h.length; v++) {
                var m = h[v], y = s[v];
                if (!(null === (e = m.order) || void 0 === e ? void 0 : e.includes(y)) || g !== y) {
                    g = -1;
                    break;
                }
            }
            null === (i = this.endCallback) || void 0 === i || i.call(this, this.prizes.find(function(t, e) {
                return e === g;
            }) || void 0);
        }
    }, a.prototype.displacement = function(t, e) {
        return "horizontal" === this._defaultConfig.mode ? e : t;
    }, a.prototype.displacementWidthOrHeight = function() {
        var t = this._defaultConfig.mode, e = this.slots.length, i = this._defaultConfig, n = i.colSpacing, r = i.rowSpacing, o = this.prizeArea || this.drawBlocks();
        o.x, o.y;
        var a, s, c = o.w, u = o.h, h = 0, l = 0;
        return "horizontal" === t ? (l = this.cellHeight = (u - r * (e - 1)) / e, h = this.cellWidth = l) : (h = this.cellWidth = (c - n * (e - 1)) / e, 
        l = this.cellHeight = h), a = this.widthAndSpacing = this.cellWidth + n, s = this.heightAndSpacing = this.cellHeight + r, 
        this.cellAndSpacing = "horizontal" === t ? a : s, {
            cellWidth: h,
            cellHeight: l,
            widthAndSpacing: a,
            heightAndSpacing: s
        };
    }, a;
}(qi);