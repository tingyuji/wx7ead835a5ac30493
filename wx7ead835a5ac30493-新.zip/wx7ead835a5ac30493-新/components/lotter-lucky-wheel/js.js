Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.changeUnits = void 0, exports.getImage = function() {
    var e = this;
    return new Promise(function(r, t) {
        wx.canvasToTempFilePath({
            canvas: e.canvas,
            success: function(e) {
                return r(e);
            },
            fail: function(e) {
                return t(e);
            }
        });
    });
}, exports.rpx2px = exports.resolveImage = void 0;

var e = wx.getSystemInfoSync().windowWidth, r = exports.rpx2px = function(r) {
    return "string" == typeof r && (r = Number(r.replace(/[a-z]*/g, ""))), e / 750 * r;
};

exports.changeUnits = function(e) {
    return e = String(e), Number(e.replace(/^(\-*[0-9.]*)([a-z%]*)$/, function(e, t, n) {
        switch (n) {
          case "px":
            t *= 1;
            break;

          case "rpx":
            t = r(t);
            break;

          default:
            t *= 1;
        }
        return t;
    }));
}, exports.resolveImage = function(e, r, t) {
    var n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "src", o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "$resolve", s = t.createImage();
    s.onload = function() {
        r[o](s);
    }, s.src = r[n];
};