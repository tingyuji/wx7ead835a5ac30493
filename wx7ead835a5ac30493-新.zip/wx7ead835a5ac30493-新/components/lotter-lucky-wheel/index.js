var t = require("lucky-canvas"), e = require("js");

Component({
    properties: {
        isShow: {
            type: Boolean,
            value: !1
        },
        width: {
            type: String,
            value: "600rpx"
        },
        height: {
            type: String,
            value: "600rpx"
        },
        blocks: {
            type: Array,
            value: []
        },
        prizes: {
            type: Array,
            value: []
        },
        buttons: {
            type: Array,
            value: []
        },
        defaultConfig: {
            type: Object,
            value: {}
        },
        defaultStyle: {
            type: Object,
            value: {}
        },
        start: {
            type: null,
            value: function() {}
        },
        end: {
            type: null,
            value: function() {}
        }
    },
    data: {
        lucky: null,
        luckyImg: "",
        showCanvas: !0
    },
    observers: {
        "blocks.**": function(t, e) {
            this.lucky && (this.lucky.blocks = t);
        },
        "prizes.**": function(t, e) {
            this.lucky && (this.lucky.prizes = t);
        },
        "buttons.**": function(t, e) {
            this.lucky && (this.lucky.buttons = t);
        }
    },
    ready: function() {
        var a = this;
        wx.createSelectorQuery().in(this).select("#lucky-wheel").fields({
            node: !0,
            size: !0
        }).exec(function(n) {
            if (!n[0] || !n[0].node) return console.error("lucky-canvas 获取不到 canvas 标签");
            var i = a.canvas = n[0].node, l = a.dpr = wx.getSystemInfoSync().pixelRatio, c = a.ctx = i.getContext("2d"), s = a.data;
            i.width = n[0].width * l, i.height = n[0].height * l, c.scale(l, l), a.lucky = new t.LuckyWheel({
                flag: "MP-WX",
                ctx: c,
                dpr: l,
                width: n[0].width,
                height: n[0].height,
                setTimeout: setTimeout,
                clearTimeout: clearTimeout,
                setInterval: setInterval,
                clearInterval: clearInterval,
                unitFunc: function(t, a) {
                    return (0, e.changeUnits)(t + a);
                },
                beforeCreate: function() {
                    var t = Math.min(this.config.width, this.config.height) / 2;
                    c.translate(t, t);
                },
                beforeInit: function() {
                    c.translate(-this.Radius, -this.Radius);
                },
                afterStart: function() {
                    a.lucky.draw(), a.setData({
                        luckyImg: "",
                        showCanvas: !0
                    });
                }
            }, {
                blocks: s.blocks,
                prizes: s.prizes,
                buttons: s.buttons,
                defaultConfig: s.defaultConfig,
                defaultStyle: s.defaultStyle,
                start: function() {
                    for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                    a.triggerEvent.apply(a, [ "start" ].concat(e));
                },
                end: function() {
                    for (var t = arguments.length, n = new Array(t), i = 0; i < t; i++) n[i] = arguments[i];
                    a.triggerEvent.apply(a, [ "end" ].concat(n)), e.getImage.call(a).then(function(t) {
                        a.setData({
                            luckyImg: t.tempFilePath
                        });
                    });
                }
            }), a.setData({
                isShow: !0
            });
        });
    },
    ggg: function() {
        var t = wx.createSelectorQuery();
        t.select("#tabbox").boundingClientRect(), t.selectViewport().scrollOffset(), t.exec(function(t) {
            this.setData({
                wheelWidth: this.data.safeArea.height - t[0].top
            }), console.log(t[0].top);
        });
    },
    methods: {
        imgBindload: function(t) {
            var a = t.currentTarget.dataset, n = a.name, i = a.index, l = a.i, c = this.data[n][i].imgs[l];
            (0, e.resolveImage)(t, c, this.canvas);
        },
        luckyImgLoad: function() {
            this.setData({
                showCanvas: !1
            }), this.lucky.clearCanvas();
        },
        handleClickOfImg: function(t) {
            var e = this, a = t.changedTouches[0], n = a.clientX, i = a.clientY;
            wx.createSelectorQuery().in(this).select(".lucky-img").fields({
                rect: !0
            }).exec(function(t) {
                var a = t[0], l = a.left, c = a.top;
                e.toPlay(n - l, i - c);
            });
        },
        handleClickOfCanvas: function(t) {
            var e = t.changedTouches[0], a = e.x, n = e.y;
            this.toPlay(a, n);
        },
        toPlay: function(t, e) {
            var a = this.ctx;
            a.beginPath(), a.arc(0, 0, this.lucky.maxBtnRadius, 0, 2 * Math.PI, !1), a.isPointInPath(t * this.dpr, e * this.dpr) && this.lucky.startCallback();
        },
        init: function() {
            var t;
            (t = this.lucky).init.apply(t, arguments);
        },
        play: function() {
            var t;
            (t = this.lucky).play.apply(t, arguments);
        },
        stop: function() {
            var t;
            (t = this.lucky).stop.apply(t, arguments);
        }
    }
});