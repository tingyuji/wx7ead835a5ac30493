var t = require("../../../@babel/runtime/helpers/defineProperty");

Component({
    lifetimes: {
        attached: function() {
            this.keyboard = this.selectComponent("#keyboard");
        },
        detached: function() {}
    },
    properties: {},
    data: {
        keyboardinputvaluename: "",
        customInput: {
            value: [],
            cursorIndex: 0
        },
        addDefaultInputValue: [],
        labelIcon: !0
    },
    methods: {
        showKeyboard: function(e) {
            console.log("showKeyboard"), this.keyboard.showKeyboard(e), this.setData(t({}, "customInput.cursorIndex", this.data.customInput.value.length));
        },
        hideKeyboard: function() {
            this.keyboard.hideKeyboard(), this.setData(t({}, "customInput.cursorIndex", -1));
        },
        getStrPosition: function(e) {
            var o = e.currentTarget.dataset.strIndex;
            console.log(o), this.setData(t({}, "customInput.cursorIndex", o));
        },
        keyboardPageConfirm: function() {},
        setCursorIndex: function(t) {
            var e = t.detail.value;
            console.log(e);
        },
        setValue: function(e) {
            var o = e.detail.value, a = e.detail.cursorIndex;
            this.setData(t(t({}, "customInput.value", o), "customInput.cursorIndex", a)), console.log(this.data.customInput);
        },
        setLabelIcon: function(t) {
            this.setData({
                labelIcon: !this.data.labelIcon
            });
        }
    }
});