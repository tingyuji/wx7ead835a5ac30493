Component({
    properties: {
        someProp: {
            type: Object,
            value: {},
            observer: function(e) {}
        }
    },
    data: {
        show: !1,
        nowKeyValue: "",
        keyNumList: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 ],
        keyotherList: [ {
            icon: "./images/tuige.png",
            value: "del"
        }, {
            value: "确定"
        } ]
    },
    methods: {
        hideKeyboard: function() {
            var e = getCurrentPages();
            e[e.length - 1].setData({
                bodyPosition: "unset",
                PositionVal: "0rpx"
            }), console.log("hideKeyboard"), this.setData({
                show: !1
            }), this.triggerEvent("setCursorIndex", {
                value: -1
            });
        },
        showKeyboard: function(e) {
            var t = e.currentTarget.dataset.keyboardinputvaluename;
            console.log("showKeyboard", t), this.setData({
                show: !0,
                keyboardinputvaluename: t
            });
            var o = getCurrentPages();
            o[o.length - 1].setData({
                bodyPosition: "absolute",
                PositionVal: "10rpx"
            });
        },
        changeValue: function(e) {
            if ("zhengfu" != e) {
                var t = this.properties.someProp;
                console.log(t);
                var o = t.value, n = t.cursorIndex, s = this.newValue(o, e, n);
                "del" == e && n > 0 ? n -= 1 : this.data.keyNumList.includes(e) && (n += 1), this.triggerEvent("setValue", {
                    value: s,
                    cursorIndex: n
                });
            } else this.triggerEvent("setLabelIcon");
        },
        keyTap: function(e) {
            console.log(e);
            var t = e.currentTarget.dataset.key;
            if ("del" == t || this.data.keyNumList.includes(t)) this.changeValue(t); else switch (t) {
              case "zhengfu":
                this.changeValue(t);
                break;

              case "确定":
                this.hideKeyboard();
            }
        },
        newValue: function(e, t, o) {
            console.log(e), console.log(t), console.log(o);
            var n = e;
            if ("del" == t) e.length > 0 && (n = this.removeFromArray(e, o - 1)); else {
                console.log(e);
                var s = this.insertIntoArray(e, t, o);
                console.log(s);
            }
            return n.length > 9 ? (wx.showToast({
                title: "分值长度不得超过9位数",
                icon: "none"
            }), e) : (console.log(n), n);
        },
        insertIntoArray: function(e, t, o) {
            if (o >= 0 && o <= e.length) return e.splice(o, 0, t), e;
            throw new Error("Invalid index. Please provide an index within the range of 0 to " + (e.length - 1));
        },
        removeFromArray: function(e, t) {
            return t >= 0 && t < e.length ? (e.splice(t, 1), e) : e;
        }
    }
});