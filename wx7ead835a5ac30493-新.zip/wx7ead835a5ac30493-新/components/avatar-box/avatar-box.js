var e = getApp();

Component({
    properties: {
        isupload: {
            type: Boolean,
            value: !1
        },
        imgurl: {
            type: String,
            value: ""
        },
        size: {
            type: String,
            value: "100rpx"
        },
        text: {
            type: String,
            value: "",
            observer: function(e, t) {
                this.setData({
                    text: e.substr(0, 1)
                });
            }
        },
        styleName: {
            type: String,
            value: ""
        },
        round: {
            type: Boolean,
            value: "true"
        }
    },
    data: {
        app: e,
        fontSize: 50
    },
    lifetimes: {
        attached: function() {},
        moved: function() {},
        detached: function() {}
    },
    methods: {}
});