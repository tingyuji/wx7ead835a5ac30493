var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = new (require("../../utils/requestData").requestData)(), n = getApp();

Component({
    properties: {
        childid: {
            type: Number,
            value: null
        },
        prizes: {
            type: Object,
            value: null
        },
        type: {
            type: Number,
            value: 1
        }
    },
    data: {
        app: n
    },
    methods: {
        editPrizesBtn: function(e) {
            var t = getCurrentPages();
            t[t.length - 1].handlePopup(e), console.log(this.data.prizes);
        },
        handlePopup: function(e) {
            var t = getCurrentPages(), a = t[t.length - 1];
            a.popup.handlePopup(e);
            var n = e.currentTarget.dataset.popupname, r = "提示";
            switch (n) {
              case "editPrizes":
                r = "编辑礼物";
            }
            a.setData({
                popupname: n,
                popupTitle: r
            });
        },
        exchangePrizesBtn: function(a) {
            var n, r = this, i = this.data.prizes, s = this.data.childid;
            wx.showModal({
                title: "提示",
                content: "兑换【".concat(i.prizesname, "】需要花费").concat(i.needpoints, "积分，确定需要兑换吗？"),
                complete: (n = t(e().mark(function t(a) {
                    var n;
                    return e().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            a.cancel, a.confirm && (n = {
                                childid: s,
                                prizesid: i.id
                            }, r.exchangePrizes(n, i));

                          case 2:
                          case "end":
                            return e.stop();
                        }
                    }, t);
                })), function(e) {
                    return n.apply(this, arguments);
                })
            });
        },
        exchangePrizes: function(n, r) {
            return t(e().mark(function t() {
                var i, s, c, o, p, u, l;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, a.mainDataReq(n, "exchangePrizes");

                      case 2:
                        i = e.sent, console.log(i), wx.showToast({
                            title: i.data.msg.title,
                            icon: i.data.msg.icon
                        }), 0 === i.data.code && (s = getCurrentPages(), c = s[s.length - 1], o = new Date(), 
                        p = o.toISOString().slice(0, 19).replace("T", " "), u = {
                            id: i.data.exchangelogid,
                            childid: c.data.childid,
                            prizesname: r.prizesname,
                            usepoints: r.needpoints,
                            used: 0,
                            datetime: p
                        }, (l = c.data.exchangelog).unshift(u), c.setData({
                            exchangelog: l
                        }));

                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    }
});