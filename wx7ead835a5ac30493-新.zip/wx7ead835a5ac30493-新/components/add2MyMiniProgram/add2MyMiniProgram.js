Component({
    properties: {},
    data: {
        showAdd2MyminPro: !1
    },
    methods: {
        show: function() {
            var t = this;
            this.setData({
                showAdd2MyminPro: !0
            }), setTimeout(function() {
                t.close();
            }, 15e3);
        },
        close: function() {
            this.setData({
                showAdd2MyminPro: !1
            });
        }
    }
});