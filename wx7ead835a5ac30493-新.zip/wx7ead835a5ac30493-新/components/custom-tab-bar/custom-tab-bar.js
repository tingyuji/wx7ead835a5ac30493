var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../utils/requestData"), n = require("../../utils/login"), r = require("../../utils/common"), i = new a.requestData(), s = new n.Login(), o = new r.Common();

Component({
    properties: {
        tabbarSelectIndex: {
            type: Number,
            value: -1
        },
        parentUserinfo: {
            type: Object,
            value: null,
            observer: function(e, t) {
                this.setData({
                    parentUserinfo: e
                });
            }
        },
        currentUser: {
            type: Object,
            value: null,
            observer: function(e, t) {
                this.setData({
                    currentUser: e
                });
            }
        }
    },
    data: {
        tabBar: {
            selectedColor: "#165eb6",
            backgroundColor: "#fff",
            list: [ {
                id: 1,
                pagePath: "/pages/index/index",
                text: "首页",
                icon: "home",
                iconPath: "images/index.png",
                selectedIconPath: "images/index_fill.png"
            }, {
                id: 3,
                pagePath: "/pages/user/my/my",
                text: "我的",
                icon: "user-setting",
                iconPath: "images/people.png",
                selectedIconPath: "images/people_fill.png"
            } ]
        }
    },
    methods: {
        tabbarOnloadFromTDtabbar: function(e) {
            var t = e.detail.tabBarHeight;
            this.triggerEvent("onload", {
                tabBarHeight: t
            });
        },
        onClick: function(e) {
            var t = e.currentTarget.dataset.index, a = e.currentTarget.dataset.url, n = getCurrentPages();
            n[n.length - 1].setData({
                tabbarSelectIndex: t
            }), wx.switchTab({
                url: a
            });
        },
        switchTab: function(e) {
            var t = e.detail.value;
            console.log(t);
        },
        onChange: function(e) {
            console.log(e), console.log(e.detail.value);
            var t = e.detail.value;
            wx.switchTab({
                url: t
            });
        },
        exit: function() {
            var a, n = this.data.parentUserinfo, r = this.data.currentUser;
            wx.showModal({
                title: "提示",
                content: "退出后您将不能与【" + n.users.nickname + "】共同管理，确定要退出吗？",
                confirmText: "确定退出",
                complete: (a = t(e().mark(function t(a) {
                    var l;
                    return e().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (a.cancel, !a.confirm) {
                                e.next = 11;
                                break;
                            }
                            return e.next = 4, i.mainDataReq({
                                parentuserid: n.users.id,
                                memberuserid: r.id
                            }, "exitInvitation");

                          case 4:
                            if (l = e.sent, console.log(l), 0 != l.data.code) {
                                e.next = 10;
                                break;
                            }
                            return e.next = 9, s.userLogin(null, !0);

                          case 9:
                            wx.reLaunch({
                                url: "/pages/index/index"
                            });

                          case 10:
                            o.showmsg(l.data.msg.title, l.data.msg.icon);

                          case 11:
                          case "end":
                            return e.stop();
                        }
                    }, t);
                })), function(e) {
                    return a.apply(this, arguments);
                })
            });
        }
    },
    lifetimes: {
        created: function() {}
    }
});