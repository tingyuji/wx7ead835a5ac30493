Component({
    properties: {
        images: {
            type: Object,
            value: []
        }
    },
    data: {
        visible: !1,
        showIndex: !1,
        closeBtn: !1,
        deleteBtn: !1
    },
    methods: {
        onClick: function() {
            console.log(this.data.images), this.setData({
                showIndex: !0,
                visible: !0
            });
        },
        onChange: function(e) {
            var t = e.detail.index;
            console.log("change", t);
        },
        onDelete: function(e) {
            var t = e.detail.index;
            Toast({
                context: this,
                selector: "#t-toast",
                message: "删除第".concat(t + 1, "个")
            });
        },
        onClose: function(e) {
            var t = e.detail.trigger;
            console.log(t), this.setData({
                visible: !1
            });
        }
    }
});