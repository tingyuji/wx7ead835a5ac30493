Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0, require("../../../@babel/runtime/helpers/Arrayincludes");

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), a = require("../../../@babel/runtime/helpers/getPrototypeOf"), n = require("../../../@babel/runtime/helpers/inherits"), l = require("../../../@babel/runtime/helpers/typeof"), i = require("../common/src/index"), o = d(require("../common/config")), s = d(require("./props")), u = d(require("../dropdown-menu/props")), c = require("../common/utils");

function d(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, n) {
    return t = a(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, n || [], a(e).constructor) : t.apply(e, n));
}

var h = function(e, t, r, a) {
    var n, i = arguments.length, o = i < 3 ? t : null === a ? a = Object.getOwnPropertyDescriptor(t, r) : a;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : l(Reflect)) && "function" == typeof Reflect.decorate) o = Reflect.decorate(e, t, r, a); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (o = (i < 3 ? n(o) : i > 3 ? n(t, r, o) : n(t, r)) || o);
    return i > 3 && o && Object.defineProperty(t, r, o), o;
}, p = o.default.prefix, v = "".concat(p, "-dropdown-item"), m = function(r) {
    function a() {
        var e;
        return t(this, a), (e = f(this, a, arguments)).externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-content"), "".concat(p, "-class-column"), "".concat(p, "-class-column-item"), "".concat(p, "-class-column-item-label"), "".concat(p, "-class-footer") ], 
        e.properties = Object.assign({}, s.default), e.data = {
            prefix: p,
            classPrefix: v,
            show: !1,
            top: 0,
            maskHeight: 0,
            initValue: null,
            hasChanged: !1,
            duration: u.default.duration.value,
            zIndex: u.default.zIndex.value,
            overlay: u.default.showOverlay.value,
            labelAlias: "label",
            valueAlias: "value",
            computedLabel: "",
            firstCheckedValue: ""
        }, e.relations = {
            "../dropdown-menu/dropdown-menu": {
                type: "parent",
                linked: function(e) {
                    var t = e.properties, r = t.zIndex, a = t.duration, n = t.showOverlay;
                    this.setData({
                        zIndex: r,
                        duration: a,
                        showOverlay: n
                    });
                }
            }
        }, e.controlledProps = [ {
            key: "value",
            event: "change"
        } ], e.observers = {
            keys: function(e) {
                this.setData({
                    labelAlias: e.label || "label",
                    valueAlias: e.value || "value"
                });
            },
            value: function(e) {
                var t = this.data, r = t.options, a = t.labelAlias, n = t.valueAlias;
                if (this.data.multiple && !Array.isArray(e)) throw TypeError("应传入数组类型的 value");
                var l = r.find(function(t) {
                    return t[n] === e;
                });
                l && this.setData({
                    computedLabel: l[a]
                });
            },
            "label, computedLabel": function() {
                var e;
                null === (e = this.$parent) || void 0 === e || e.getAllItems();
            },
            show: function(e) {
                var t = this;
                e && this.getParentBottom(function() {
                    t.setData({
                        wrapperVisible: !0
                    });
                });
            }
        }, e.methods = {
            closeDropdown: function() {
                var e;
                null === (e = this.$parent) || void 0 === e || e.setData({
                    activeIdx: -1
                }), this.setData({
                    show: !1
                }), this.triggerEvent("close");
            },
            getParentBottom: function(e) {
                var t = this;
                (0, c.getRect)(this.$parent, "#".concat(p, "-bar")).then(function(r) {
                    t.setData({
                        top: r.bottom,
                        maskHeight: r.top
                    }, e);
                });
            },
            handleTreeClick: function(e) {
                var t = e.currentTarget.dataset, r = t.level, a = t.value, n = this.data.value;
                n[r] = a, this._trigger("change", {
                    value: n
                });
            },
            handleRadioChange: function(e) {
                var t = e.detail.value;
                if (this._trigger("change", {
                    value: t
                }), this.data.multiple) {
                    var r = this.data.options.find(function(e) {
                        return t.includes(e.value);
                    });
                    r && (this.data.firstCheckedValue = r.value);
                } else this.closeDropdown();
            },
            handleMaskClick: function() {
                var e;
                (null === (e = this.$parent) || void 0 === e ? void 0 : e.properties.closeOnClickOverlay) && this.closeDropdown();
            },
            handleReset: function() {
                this._trigger("change", {
                    value: []
                }), this._trigger("reset");
            },
            handleConfirm: function() {
                this._trigger("confirm", {
                    value: this.data.value
                }), this.closeDropdown(), this.setData({
                    firstCheckedValue: this.data.firstCheckedValue
                });
            },
            onLeaved: function() {
                this.setData({
                    wrapperVisible: !1
                });
            }
        }, e;
    }
    return n(a, r), e(a);
}(i.SuperComponent);

m = h([ (0, i.wxComponent)() ], m);

exports.default = m;