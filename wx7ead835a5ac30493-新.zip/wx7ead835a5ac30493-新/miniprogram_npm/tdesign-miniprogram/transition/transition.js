Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), u = require("../../../@babel/runtime/helpers/typeof"), c = require("../common/src/index"), i = l(require("../mixins/transition"));

function l(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, o) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, o || [], n(e).constructor) : t.apply(e, o));
}

var s = function(e, t, r, n) {
    var o, c = arguments.length, i = c < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : u(Reflect)) && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, r, n); else for (var l = e.length - 1; l >= 0; l--) (o = e[l]) && (i = (c < 3 ? o(i) : c > 3 ? o(t, r, i) : o(t, r)) || i);
    return c > 3 && i && Object.defineProperty(t, r, i), i;
}, a = l(require("../common/config")).default.prefix, p = "".concat(a, "-transition"), d = function(r) {
    function n() {
        var e;
        return t(this, n), (e = f(this, n, arguments)).externalClasses = [ "".concat(a, "-class") ], 
        e.behaviors = [ (0, i.default)() ], e.data = {
            classPrefix: p
        }, e;
    }
    return o(n, r), e(n);
}(c.SuperComponent);

d = s([ (0, c.wxComponent)() ], d);

exports.default = d;