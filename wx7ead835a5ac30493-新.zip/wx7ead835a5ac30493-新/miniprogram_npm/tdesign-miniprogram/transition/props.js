Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    appear: {
        type: Boolean,
        value: !1
    },
    customClass: {
        type: String,
        value: ""
    },
    destoryOnClose: {
        type: Boolean,
        value: !1
    },
    duration: {
        type: Number
    },
    name: {
        type: String,
        value: "t-transition"
    },
    visible: {
        type: Boolean,
        value: !1
    }
};

exports.default = e;