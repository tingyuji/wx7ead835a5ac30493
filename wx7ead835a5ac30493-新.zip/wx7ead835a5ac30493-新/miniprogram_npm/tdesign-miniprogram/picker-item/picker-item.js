Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/classCallCheck"), t = require("../../../@babel/runtime/helpers/createClass"), i = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), r = require("../../../@babel/runtime/helpers/inherits"), a = require("../../../@babel/runtime/helpers/typeof"), o = require("../common/src/index"), l = u(require("../common/config")), s = u(require("./props"));

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function c(e, t, r) {
    return t = n(t), i(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, r || [], n(e).constructor) : t.apply(e, r));
}

var f = function(e, t, i, n) {
    var r, o = arguments.length, l = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, i) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : a(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(e, t, i, n); else for (var s = e.length - 1; s >= 0; s--) (r = e[s]) && (l = (o < 3 ? r(l) : o > 3 ? r(t, i, l) : r(t, i)) || l);
    return o > 3 && l && Object.defineProperty(t, i, l), l;
}, d = l.default.prefix, h = "".concat(d, "-picker-item"), p = wx.getSystemInfoSync().windowWidth, v = function(e, t, i) {
    return Math.min(Math.max(e, t), i);
}, b = function(i) {
    function n() {
        var t;
        return e(this, n), (t = c(this, n, arguments)).relations = {
            "../picker/picker": {
                type: "parent",
                linked: function(e) {
                    if ("keys" in e.data) {
                        var t = e.data.keys;
                        this.setData({
                            labelAlias: (null == t ? void 0 : t.label) || "label",
                            valueAlias: (null == t ? void 0 : t.value) || "value"
                        });
                    }
                }
            }
        }, t.externalClasses = [ "".concat(d, "-class") ], t.properties = s.default, t.observers = {
            options: function() {
                this.update();
            }
        }, t.data = {
            prefix: d,
            classPrefix: h,
            offset: 0,
            duration: 0,
            value: "",
            curIndex: 0,
            columnIndex: 0,
            labelAlias: "label",
            valueAlias: "value"
        }, t.methods = {
            onTouchStart: function(e) {
                this.StartY = e.touches[0].clientY, this.StartOffset = this.data.offset, this.setData({
                    duration: 0
                });
            },
            onTouchMove: function(e) {
                var t = this.StartY, i = this.StartOffset, n = this.itemHeight, r = e.touches[0].clientY - t, a = this.calculateViewDeltaY(r);
                this.setData({
                    offset: v(i + a, -this.getCount() * n, 0),
                    duration: 240
                });
            },
            onTouchEnd: function() {
                var e = this, t = this.data, i = t.offset, n = t.labelAlias, r = t.valueAlias, a = t.columnIndex, o = this.properties.options;
                if (i !== this.StartOffset) {
                    var l = v(Math.round(-i / this.itemHeight), 0, this.getCount() - 1);
                    this.setData({
                        curIndex: l,
                        offset: -l * this.itemHeight
                    }), l !== this._selectedIndex && wx.nextTick(function() {
                        var t, i, s;
                        e._selectedIndex = l, e._selectedValue = null === (t = o[l]) || void 0 === t ? void 0 : t[r], 
                        e._selectedLabel = null === (i = o[l]) || void 0 === i ? void 0 : i[n], null === (s = e.$parent) || void 0 === s || s.triggerColumnChange({
                            index: l,
                            column: a
                        });
                    });
                }
            },
            update: function() {
                var e, t, i = this.data, n = i.options, r = i.value, a = i.labelAlias, o = i.valueAlias, l = n.findIndex(function(e) {
                    return e[o] === r;
                }), s = l > 0 ? l : 0;
                this.setData({
                    offset: -s * this.itemHeight,
                    curIndex: s
                }), this._selectedIndex = s, this._selectedValue = null === (e = n[s]) || void 0 === e ? void 0 : e[o], 
                this._selectedLabel = null === (t = n[s]) || void 0 === t ? void 0 : t[a];
            },
            resetOrigin: function() {
                this.update();
            },
            getCount: function() {
                var e, t;
                return null === (t = null === (e = this.data) || void 0 === e ? void 0 : e.options) || void 0 === t ? void 0 : t.length;
            }
        }, t;
    }
    return r(n, i), t(n, [ {
        key: "calculateViewDeltaY",
        value: function(e) {
            return Math.abs(e) > 80 ? 1.2 * e : e;
        }
    }, {
        key: "created",
        value: function() {
            var e;
            this.StartY = 0, this.StartOffset = 0, this.itemHeight = (e = 80, Math.floor(p * e / 750));
        }
    } ]);
}(o.SuperComponent);

b = f([ (0, o.wxComponent)() ], b);

exports.default = b;