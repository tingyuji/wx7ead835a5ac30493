Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    format: {
        type: null
    },
    options: {
        type: Array,
        value: []
    }
};

exports.default = e;