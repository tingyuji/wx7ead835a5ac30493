Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    align: {
        type: String,
        value: "center"
    },
    content: {
        type: String
    },
    style: {
        type: String,
        value: ""
    },
    dashed: {
        type: Boolean,
        value: !1
    },
    externalClasses: {
        type: Array
    },
    layout: {
        type: String,
        value: "horizontal"
    }
};

exports.default = e;