Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), c = require("../../../@babel/runtime/helpers/typeof"), l = require("../common/src/index"), i = s(require("../common/config")), u = s(require("./props"));

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function a(e, t, o) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, o || [], n(e).constructor) : t.apply(e, o));
}

var f = function(e, t, r, n) {
    var o, l = arguments.length, i = l < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : c(Reflect)) && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, r, n); else for (var u = e.length - 1; u >= 0; u--) (o = e[u]) && (i = (l < 3 ? o(i) : l > 3 ? o(t, r, i) : o(t, r)) || i);
    return l > 3 && i && Object.defineProperty(t, r, i), i;
}, p = i.default.prefix, d = "".concat(p, "-divider"), b = function(r) {
    function n() {
        var e;
        return t(this, n), (e = a(this, n, arguments)).externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-content") ], 
        e.options = {
            addGlobalClass: !0,
            multipleSlots: !0
        }, e.properties = u.default, e.data = {
            prefix: p,
            classPrefix: d
        }, e.observers = {
            lineColor: function() {
                this.setStyle();
            }
        }, e.methods = {
            setStyle: function() {
                var e = this.properties.lineColor, t = "".concat(e ? "border-color: ".concat(e, ";") : "");
                this.setData({
                    dividerStyle: t
                });
            }
        }, e;
    }
    return o(n, r), e(n);
}(l.SuperComponent);

b = f([ (0, l.wxComponent)() ], b);

exports.default = b;