Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    closable: {
        type: Boolean,
        value: !1
    },
    disabled: {
        type: Boolean,
        value: !1
    },
    externalClasses: {
        type: Array
    },
    icon: {
        type: null
    },
    maxWidth: {
        type: null
    },
    shape: {
        type: String,
        value: "square"
    },
    size: {
        type: String,
        value: "medium"
    },
    theme: {
        type: String,
        value: "default"
    },
    variant: {
        type: String,
        value: "dark"
    }
};

exports.default = e;