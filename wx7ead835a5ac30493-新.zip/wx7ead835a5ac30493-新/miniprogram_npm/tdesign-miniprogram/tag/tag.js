Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), a = require("../../../@babel/runtime/helpers/getPrototypeOf"), n = require("../../../@babel/runtime/helpers/inherits"), s = require("../../../@babel/runtime/helpers/typeof"), c = require("../common/src/index"), i = u(require("../common/config")), o = u(require("./props")), l = require("../common/utils");

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, n) {
    return t = a(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, n || [], a(e).constructor) : t.apply(e, n));
}

var p = function(e, t, r, a) {
    var n, c = arguments.length, i = c < 3 ? t : null === a ? a = Object.getOwnPropertyDescriptor(t, r) : a;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : s(Reflect)) && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, r, a); else for (var o = e.length - 1; o >= 0; o--) (n = e[o]) && (i = (c < 3 ? n(i) : c > 3 ? n(t, r, i) : n(t, r)) || i);
    return c > 3 && i && Object.defineProperty(t, r, i), i;
}, d = i.default.prefix, h = "".concat(d, "-tag"), b = function(r) {
    function a() {
        var e;
        return t(this, a), (e = f(this, a, arguments)).data = {
            prefix: d,
            classPrefix: h,
            className: "",
            tagStyle: ""
        }, e.properties = o.default, e.externalClasses = [ "".concat(d, "-class") ], e.options = {
            multipleSlots: !0,
            styleIsolation: "apply-shared"
        }, e.lifetimes = {
            attached: function() {
                this.setClass(), this.setTagStyle();
            }
        }, e.observers = {
            "size, shape, theme, variant, closable, disabled": function() {
                this.setClass();
            },
            maxWidth: function() {
                this.setTagStyle();
            },
            icon: function(e) {
                this.setData({
                    _icon: (0, l.calcIcon)(e)
                });
            }
        }, e.methods = {
            setClass: function() {
                var e = this.data, t = e.prefix, r = e.classPrefix, a = this.properties, n = a.size, s = a.shape, c = a.theme, i = a.variant, o = a.closable, u = a.disabled, f = [ r, "".concat(r, "--").concat(c || "default"), "".concat(r, "--").concat(i), o ? "".concat(r, "--closable ").concat(t, "-is-closable") : "", u ? "".concat(r, "--disabled ").concat(t, "-is-disabled") : "", "".concat(r, "--").concat(n), "".concat(r, "--").concat(s) ], p = (0, 
                l.classNames)(f);
                this.setData({
                    className: p
                });
            },
            setTagStyle: function() {
                var e = this.properties.maxWidth;
                if (!e) return "";
                var t = (0, l.isNumber)(e) ? "".concat(e, "px") : e;
                this.setData({
                    tagStyle: "max-width:".concat(t, ";")
                });
            },
            handleClick: function(e) {
                this.data.disabled || this.triggerEvent("click", e);
            },
            handleClose: function(e) {
                this.data.disabled || this.triggerEvent("close", e);
            }
        }, e;
    }
    return n(a, r), e(a);
}(c.SuperComponent);

b = p([ (0, c.wxComponent)() ], b);

exports.default = b;