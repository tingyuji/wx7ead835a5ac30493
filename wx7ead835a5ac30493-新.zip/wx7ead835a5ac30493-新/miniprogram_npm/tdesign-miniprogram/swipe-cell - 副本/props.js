Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    disabled: {
        type: Boolean
    },
    left: {
        type: Array
    },
    opened: {
        type: Boolean,
        optionalTypes: [ Array ],
        value: !1
    },
    right: {
        type: Array
    }
};

exports.default = e;