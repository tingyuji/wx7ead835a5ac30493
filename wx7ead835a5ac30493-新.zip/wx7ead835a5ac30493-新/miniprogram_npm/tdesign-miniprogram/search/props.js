Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    action: {
        type: String,
        value: ""
    },
    center: {
        type: Boolean,
        value: !1
    },
    disabled: {
        type: Boolean,
        value: !1
    },
    externalClasses: {
        type: Array
    },
    cursorSpacing: {
        type: Number,
        value: 0
    },
    focus: {
        type: Boolean,
        value: !1
    },
    label: {
        type: String,
        value: ""
    },
    maxcharacter: {
        type: Number
    },
    maxlength: {
        type: Number,
        value: -1
    },
    confirmType: {
        type: String,
        value: "search"
    },
    alwaysEmbed: {
        type: Boolean,
        value: !1
    },
    confirmHold: {
        type: Boolean,
        value: !1
    },
    cursor: {
        type: Number
    },
    selectionStart: {
        type: Number,
        value: -1
    },
    selectionEnd: {
        type: Number,
        value: -1
    },
    adjustPosition: {
        type: Boolean,
        value: !0
    },
    holdKeyboard: {
        type: Boolean,
        value: !1
    },
    placeholderStyle: {
        type: String,
        value: ""
    },
    placeholderClass: {
        type: String,
        value: ""
    },
    leftIcon: {
        type: String,
        value: "search"
    },
    placeholder: {
        type: String,
        value: ""
    },
    rightIcon: {
        type: String,
        value: "close-circle-filled"
    },
    shape: {
        type: String,
        value: "square"
    },
    value: {
        type: String,
        value: ""
    },
    clearable: {
        type: Boolean,
        value: !0
    },
    type: {
        type: String,
        value: "text"
    }
};

exports.default = e;