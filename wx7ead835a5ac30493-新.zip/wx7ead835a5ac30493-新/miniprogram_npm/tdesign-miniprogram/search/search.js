Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/classCallCheck"), t = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), a = require("../../../@babel/runtime/helpers/inherits"), c = require("../../../@babel/runtime/helpers/typeof"), u = require("../common/src/index"), o = s(require("../common/config")), l = s(require("./props")), i = require("../common/utils");

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, a) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, a || [], n(e).constructor) : t.apply(e, a));
}

var p = function(e, t, r, n) {
    var a, u = arguments.length, o = u < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : c(Reflect)) && "function" == typeof Reflect.decorate) o = Reflect.decorate(e, t, r, n); else for (var l = e.length - 1; l >= 0; l--) (a = e[l]) && (o = (u < 3 ? a(o) : u > 3 ? a(t, r, o) : a(t, r)) || o);
    return u > 3 && o && Object.defineProperty(t, r, o), o;
}, v = o.default.prefix, h = "".concat(v, "-search"), d = function(r) {
    function n() {
        var t;
        return e(this, n), (t = f(this, n, arguments)).externalClasses = [ "".concat(v, "-class"), "".concat(v, "-class-input-container"), "".concat(v, "-class-input"), "".concat(v, "-class-action"), "".concat(v, "-class-left"), "".concat(v, "-class-clear") ], 
        t.options = {
            multipleSlots: !0
        }, t.properties = l.default, t.observers = {}, t.data = {
            classPrefix: h,
            prefix: v
        }, t;
    }
    return a(n, r), t(n, [ {
        key: "onInput",
        value: function(e) {
            var t = e.detail.value, r = this.properties.maxcharacter;
            r && "number" == typeof r && r > 0 && (t = (0, i.getCharacterLength)("maxcharacter", t, r).characters);
            this.setData({
                value: t
            }), this.triggerEvent("change", {
                value: t
            });
        }
    }, {
        key: "onFocus",
        value: function(e) {
            var t = e.detail.value;
            this.triggerEvent("focus", {
                value: t
            });
        }
    }, {
        key: "onBlur",
        value: function(e) {
            var t = e.detail.value;
            this.triggerEvent("blur", {
                value: t
            });
        }
    }, {
        key: "handleClear",
        value: function() {
            this.setData({
                value: ""
            }), this.triggerEvent("clear", {
                value: ""
            });
        }
    }, {
        key: "onConfirm",
        value: function(e) {
            var t = e.detail.value;
            this.triggerEvent("submit", {
                value: t
            });
        }
    }, {
        key: "onActionClick",
        value: function() {
            this.triggerEvent("action-click");
        }
    } ]);
}(u.SuperComponent);

d = p([ (0, u.wxComponent)() ], d);

exports.default = d;