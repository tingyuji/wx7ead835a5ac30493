Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    disableInput: {
        type: Boolean,
        value: !1
    },
    disabled: {
        type: Boolean,
        value: !1
    },
    externalClasses: {
        type: Array
    },
    inputWidth: {
        type: Number
    },
    max: {
        type: Number,
        value: 100
    },
    min: {
        type: Number,
        value: 0
    },
    step: {
        type: Number,
        value: 1
    },
    size: {
        type: String,
        value: "medium"
    },
    theme: {
        type: String,
        value: "normal"
    },
    value: {
        type: String,
        optionalTypes: [ Number ],
        value: null
    },
    defaultValue: {
        type: String,
        optionalTypes: [ Number ],
        value: 0
    }
};

exports.default = e;