Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/classCallCheck"), t = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), u = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/typeof"), a = require("../common/src/index"), s = o(require("../common/config")), l = o(require("./props"));

function o(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function c(e, t, u) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, u || [], n(e).constructor) : t.apply(e, u));
}

var f = function(e, t, r, n) {
    var u, a = arguments.length, s = a < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : i(Reflect)) && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, n); else for (var l = e.length - 1; l >= 0; l--) (u = e[l]) && (s = (a < 3 ? u(s) : a > 3 ? u(t, r, s) : u(t, r)) || s);
    return a > 3 && s && Object.defineProperty(t, r, s), s;
}, p = s.default.prefix, h = "".concat(p, "-stepper"), d = function(r) {
    function n() {
        var t;
        return e(this, n), (t = c(this, n, arguments)).externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-input"), "".concat(p, "-class-minus"), "".concat(p, "-class-plus") ], 
        t.options = {
            addGlobalClass: !0
        }, t.properties = Object.assign({}, l.default), t.controlledProps = [ {
            key: "value",
            event: "change"
        } ], t.observers = {
            value: function(e) {
                this.preValue = Number(e), this.setData({
                    currentValue: this.format(Number(e))
                });
            }
        }, t.data = {
            currentValue: 0,
            classPrefix: h,
            prefix: p
        }, t.lifetimes = {
            attached: function() {
                var e = this.properties, t = e.value, r = e.min;
                this.setData({
                    currentValue: t ? Number(t) : r
                });
            }
        }, t.methods = {
            handleFocus: function(e) {
                var t = e.detail.value;
                this.triggerEvent("focus", {
                    value: t
                });
            },
            handleInput: function(e) {
                var t = e.detail.value;
                "" !== t && this.triggerEvent("input", {
                    value: t
                });
            },
            handleBlur: function(e) {
                var t = e.detail.value, r = this.format(t);
                this.setValue(r), this.triggerEvent("blur", {
                    value: r
                });
            }
        }, t;
    }
    return u(n, r), t(n, [ {
        key: "isDisabled",
        value: function(e) {
            var t = this.properties, r = t.min, n = t.max, u = t.disabled, i = this.data.currentValue;
            return !!u || ("minus" === e && i <= r || "plus" === e && i >= n);
        }
    }, {
        key: "getLen",
        value: function(e) {
            var t = e.toString();
            return -1 === t.indexOf(".") ? 0 : t.split(".")[1].length;
        }
    }, {
        key: "add",
        value: function(e, t) {
            var r = Math.max(this.getLen(e), this.getLen(t)), n = Math.pow(10, r);
            return Math.round(e * n + t * n) / n;
        }
    }, {
        key: "format",
        value: function(e) {
            var t = this.properties, r = t.min, n = t.max, u = t.step, i = Math.max(this.getLen(u), this.getLen(e));
            return Math.max(Math.min(n, e, Number.MAX_SAFE_INTEGER), r, Number.MIN_SAFE_INTEGER).toFixed(i);
        }
    }, {
        key: "setValue",
        value: function(e) {
            e = this.format(e), this.preValue !== e && (this.preValue = e, this._trigger("change", {
                value: Number(e)
            }));
        }
    }, {
        key: "minusValue",
        value: function() {
            if (this.isDisabled("minus")) return this.triggerEvent("overlimit", {
                type: "minus"
            }), !1;
            var e = this.data, t = e.currentValue, r = e.step;
            this.setValue(this.add(t, -r));
        }
    }, {
        key: "plusValue",
        value: function() {
            if (this.isDisabled("plus")) return this.triggerEvent("overlimit", {
                type: "plus"
            }), !1;
            var e = this.data, t = e.currentValue, r = e.step;
            this.setValue(this.add(t, r));
        }
    } ]);
}(a.SuperComponent);

d = f([ (0, a.wxComponent)() ], d);

exports.default = d;