Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../../@babel/runtime/helpers/createClass"), r = require("../../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../../@babel/runtime/helpers/possibleConstructorReturn"), i = require("../../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../../@babel/runtime/helpers/inherits"), c = require("../../../../@babel/runtime/helpers/typeof"), s = require("../../common/src/index"), u = f(require("../../common/config")), a = f(require("./props")), h = require("../../common/utils");

function f(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function l(e, t, r) {
    return t = i(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, r || [], i(e).constructor) : t.apply(e, r));
}

var p = function(e, t, r, n) {
    var i, o = arguments.length, s = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : c(Reflect)) && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, n); else for (var u = e.length - 1; u >= 0; u--) (i = e[u]) && (s = (o < 3 ? i(s) : o > 3 ? i(t, r, s) : i(t, r)) || s);
    return o > 3 && s && Object.defineProperty(t, r, s), s;
}, d = function(e, t, r, n) {
    return new (r || (r = Promise))(function(i, o) {
        function c(e) {
            try {
                u(n.next(e));
            } catch (e) {
                o(e);
            }
        }
        function s(e) {
            try {
                u(n.throw(e));
            } catch (e) {
                o(e);
            }
        }
        function u(e) {
            var t;
            e.done ? i(e.value) : (t = e.value, t instanceof r ? t : new r(function(e) {
                e(t);
            })).then(c, s);
        }
        u((n = n.apply(e, t || [])).next());
    });
}, m = wx.getSystemInfoSync(), b = u.default.prefix, v = "".concat(b, "-draggable"), g = function(n) {
    function i() {
        var t;
        return r(this, i), (t = l(this, i, arguments)).properties = a.default, t.externalClasses = [ "".concat(b, "-class") ], 
        t.data = {
            prefix: b,
            classPrefix: v
        }, t.lifetimes = {
            ready: function() {
                this.computedRect();
            }
        }, t.methods = {
            onTouchStart: function(e) {
                "none" !== this.properties.direction && (this.startX = e.touches[0].clientX + m.windowWidth - this.rect.right, 
                this.startY = e.touches[0].clientY + m.windowHeight - this.rect.bottom, this.triggerEvent("start", {
                    startX: this.startX,
                    startY: this.startY,
                    rect: this.rect,
                    e: e
                }));
            },
            onTouchMove: function(e) {
                if ("none" !== this.properties.direction) {
                    var t = this.startX - e.touches[0].clientX, r = this.startY - e.touches[0].clientY;
                    "vertical" === this.properties.direction && (t = m.windowWidth - this.rect.right), 
                    "horizontal" === this.properties.direction && (r = m.windowHeight - this.rect.bottom), 
                    this.triggerEvent("move", {
                        x: t,
                        y: r,
                        rect: this.rect,
                        e: e
                    });
                }
            },
            onTouchEnd: function(t) {
                return d(this, void 0, void 0, e().mark(function r() {
                    return e().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if ("none" !== this.properties.direction) {
                                e.next = 2;
                                break;
                            }
                            return e.abrupt("return");

                          case 2:
                            return e.next = 4, this.computedRect();

                          case 4:
                            this.triggerEvent("end", {
                                rect: this.rect,
                                e: t
                            });

                          case 5:
                          case "end":
                            return e.stop();
                        }
                    }, r, this);
                }));
            },
            computedRect: function() {
                return d(this, void 0, void 0, e().mark(function t() {
                    return e().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return this.rect = {
                                right: 0,
                                bottom: 0,
                                width: 0,
                                height: 0
                            }, e.next = 3, (0, h.getRect)(this, ".".concat(this.data.classPrefix));

                          case 3:
                            this.rect = e.sent;

                          case 4:
                          case "end":
                            return e.stop();
                        }
                    }, t, this);
                }));
            }
        }, t;
    }
    return o(i, n), t(i);
}(s.SuperComponent);

g = p([ (0, s.wxComponent)() ], g);

exports.default = g;