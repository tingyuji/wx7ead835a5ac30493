Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/typeof"), c = require("../common/src/index"), a = u(require("../common/config")), s = u(require("./props"));

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function l(e, t, o) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, o || [], n(e).constructor) : t.apply(e, o));
}

var p = function(e, t, r, n) {
    var o, c = arguments.length, a = c < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : i(Reflect)) && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, n); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (c < 3 ? o(a) : c > 3 ? o(t, r, a) : o(t, r)) || a);
    return c > 3 && a && Object.defineProperty(t, r, a), a;
}, f = wx.getSystemInfoSync(), h = a.default.prefix, b = "".concat(h, "-fab"), d = {
    size: "large",
    shape: "circle",
    theme: "primary",
    externalClass: "".concat(h, "-fab__button")
}, m = function(r) {
    function n() {
        var e;
        return t(this, n), (e = l(this, n, arguments)).properties = s.default, e.externalClasses = [ "class", "".concat(h, "-class"), "".concat(h, "-class-button") ], 
        e.data = {
            prefix: h,
            classPrefix: b,
            buttonData: d,
            moveStyle: null
        }, e.observers = {
            "buttonProps.**, icon, text, ariaLabel": function() {
                this.setData({
                    buttonData: Object.assign(Object.assign(Object.assign(Object.assign({}, d), {
                        shape: this.properties.text ? "round" : "circle",
                        icon: this.properties.icon
                    }), this.properties.buttonProps), {
                        content: this.properties.text,
                        ariaLabel: this.properties.ariaLabel
                    })
                }, this.computedSize);
            }
        }, e.methods = {
            onTplButtonTap: function(e) {
                this.triggerEvent("click", e);
            },
            onMove: function(e) {
                var t = e.detail, r = t.x, n = t.y, o = t.rect, i = f.windowWidth - o.width, c = f.windowHeight - o.height, a = Math.max(0, Math.min(r, i)), s = Math.max(0, Math.min(n, c));
                this.setData({
                    moveStyle: "right: ".concat(a, "px; bottom: ").concat(s, "px;")
                });
            },
            computedSize: function() {
                this.properties.draggable && this.selectComponent("#draggable").computedRect();
            }
        }, e;
    }
    return o(n, r), e(n);
}(c.SuperComponent);

m = p([ (0, c.wxComponent)() ], m);

exports.default = m;