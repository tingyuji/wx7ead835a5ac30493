Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    arrowIcon: {
        type: null,
        value: "caret-down-small"
    },
    closeOnClickOverlay: {
        type: Boolean,
        value: !0
    },
    duration: {
        type: null,
        value: 200
    },
    externalClasses: {
        type: Array
    },
    showOverlay: {
        type: Boolean,
        value: !0
    },
    zIndex: {
        type: Number,
        value: 11600
    }
};

exports.default = e;