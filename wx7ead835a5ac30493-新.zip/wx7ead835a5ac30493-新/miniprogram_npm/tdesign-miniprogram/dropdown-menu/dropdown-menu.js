Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/typeof"), c = require("../common/src/index"), a = u(require("../common/config")), l = u(require("./props")), s = require("../common/utils");

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, o) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, o || [], n(e).constructor) : t.apply(e, o));
}

var d = function(e, t, r, n) {
    var o, c = arguments.length, a = c < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : i(Reflect)) && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, n); else for (var l = e.length - 1; l >= 0; l--) (o = e[l]) && (a = (c < 3 ? o(a) : c > 3 ? o(t, r, a) : o(t, r)) || a);
    return c > 3 && a && Object.defineProperty(t, r, a), a;
}, p = a.default.prefix, h = "".concat(p, "-dropdown-menu"), m = function(r) {
    function n() {
        var e;
        return t(this, n), (e = f(this, n, arguments)).externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-item"), "".concat(p, "-class-label"), "".concat(p, "-class-icon") ], 
        e.properties = l.default, e.nodes = null, e.data = {
            prefix: p,
            classPrefix: h,
            menus: null,
            activeIdx: -1,
            bottom: 0,
            _arrowIcon: {
                name: l.default.arrowIcon.value
            }
        }, e.relations = {
            "../dropdown-item/dropdown-item": {
                type: "child"
            }
        }, e.lifetimes = {
            ready: function() {
                this.getAllItems();
            }
        }, e.observers = {
            arrowIcon: function(e) {
                this.setData({
                    _arrowIcon: (0, s.calcIcon)(e)
                });
            },
            activeIdx: function(e) {
                this.triggerEvent(-1 === e ? "close" : "open");
            }
        }, e.methods = {
            toggle: function(e) {
                var t = this.data, r = t.activeIdx, n = t.duration, o = this.$children[r], i = this.$children[e];
                (null == i ? void 0 : i.data.disabled) || (-1 !== r && (o.triggerEvent("close"), 
                o.setData({
                    show: !1
                }, function() {
                    setTimeout(function() {
                        o.triggerEvent("closed");
                    }, n);
                })), null == e || r === e ? this.setData({
                    activeIdx: -1
                }) : (i.triggerEvent("open"), this.setData({
                    activeIdx: e
                }), i.setData({
                    show: !0
                }, function() {
                    setTimeout(function() {
                        i.triggerEvent("opened");
                    }, n);
                })));
            },
            getAllItems: function() {
                var e = this.$children.map(function(e) {
                    var t = e.data;
                    return {
                        label: t.label || t.computedLabel,
                        disabled: t.disabled
                    };
                });
                this.setData({
                    menus: e
                });
            },
            handleToggle: function(e) {
                var t = e.currentTarget.dataset.index;
                this.toggle(t);
            }
        }, e;
    }
    return o(n, r), e(n);
}(c.SuperComponent);

m = d([ (0, c.wxComponent)() ], m);

exports.default = m;