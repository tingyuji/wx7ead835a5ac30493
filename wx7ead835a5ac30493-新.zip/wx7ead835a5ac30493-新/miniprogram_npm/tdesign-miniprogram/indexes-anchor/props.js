Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    externalClasses: {
        type: Array
    },
    index: {
        type: null
    }
};

exports.default = e;