Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/toConsumableArray"), t = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), i = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), s = require("../../../@babel/runtime/helpers/typeof"), a = require("../common/src/index"), c = p(require("../common/config")), l = p(require("./props")), u = require("../common/utils");

function p(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, r) {
    return t = i(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, r || [], i(e).constructor) : t.apply(e, r));
}

var h = function(e, t, r, n) {
    var i, o = arguments.length, a = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : s(Reflect)) && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, n); else for (var c = e.length - 1; c >= 0; c--) (i = e[c]) && (a = (o < 3 ? i(a) : o > 3 ? i(t, r, a) : i(t, r)) || a);
    return o > 3 && a && Object.defineProperty(t, r, a), a;
}, m = c.default.prefix, d = "".concat(m, "-skeleton"), g = {
    avatar: [ {
        type: "circle",
        size: "96rpx"
    } ],
    image: [ {
        type: "rect",
        size: "144rpx"
    } ],
    text: [ [ {
        width: "24%",
        height: "32rpx",
        marginRight: "32rpx"
    }, {
        width: "76%",
        height: "32rpx"
    } ], 1 ],
    paragraph: [ 1, 1, 1, {
        width: "55%"
    } ]
}, b = function(n) {
    function i() {
        var t;
        return r(this, i), (t = f(this, i, arguments)).externalClasses = [ "".concat(m, "-class"), "".concat(m, "-class-col"), "".concat(m, "-class-row") ], 
        t.properties = l.default, t.data = {
            prefix: m,
            classPrefix: d,
            parsedRowcols: []
        }, t.observers = {
            rowCol: function() {
                this.init();
            }
        }, t.lifetimes = {
            attached: function() {
                this.init();
            }
        }, t.methods = {
            init: function() {
                var t = this, r = this.properties, n = r.theme, i = r.rowCol, o = [];
                i.length ? o.push.apply(o, e(i)) : o.push.apply(o, e(g[n || "text"]));
                var s = o.map(function(e) {
                    if ((0, u.isNumber)(e)) return [ {
                        class: t.getColItemClass({
                            type: "text"
                        }),
                        style: {}
                    } ];
                    if (Array.isArray(e)) return e.map(function(e) {
                        return Object.assign(Object.assign({}, e), {
                            class: t.getColItemClass(e),
                            style: t.getColItemStyle(e)
                        });
                    });
                    var r = e;
                    return [ Object.assign(Object.assign({}, r), {
                        class: t.getColItemClass(r),
                        style: t.getColItemStyle(r)
                    }) ];
                });
                this.setData({
                    parsedRowcols: s
                });
            },
            getColItemClass: function(e) {
                return (0, u.classNames)([ "".concat(d, "__col"), "".concat(d, "--type-").concat(e.type || "text"), "".concat(d, "--animation-").concat(this.properties.animation) ]);
            },
            getColItemStyle: function(e) {
                var t = {};
                return [ "width", "height", "marginRight", "marginLeft", "margin", "size", "background", "backgroundColor", "borderRadius" ].forEach(function(r) {
                    if (r in e) {
                        var n = (0, u.isNumber)(e[r]) ? "".concat(e[r], "px") : e[r];
                        if ("size" === r) {
                            var i = [ n, n ];
                            t.width = i[0], t.height = i[1];
                        } else t[r] = n;
                    }
                }), t;
            }
        }, t;
    }
    return o(i, n), t(i);
}(a.SuperComponent);

b = h([ (0, a.wxComponent)() ], b);

exports.default = b;