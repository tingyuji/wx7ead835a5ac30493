Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    animation: {
        type: String,
        value: "none"
    },
    delay: {
        type: Number,
        value: 0
    },
    externalClasses: {
        type: Array
    },
    loading: {
        type: Boolean,
        value: !0
    },
    rowCol: {
        type: Array
    },
    theme: {
        type: String,
        value: "text"
    }
};

exports.default = e;