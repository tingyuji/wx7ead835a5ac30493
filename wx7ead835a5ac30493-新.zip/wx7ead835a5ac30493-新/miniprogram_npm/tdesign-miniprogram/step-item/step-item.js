Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), s = require("../../../@babel/runtime/helpers/inherits"), u = require("../../../@babel/runtime/helpers/typeof"), o = require("../common/src/index"), i = a(require("../common/config")), c = a(require("./props"));

function a(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function l(e, t, s) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, s || [], n(e).constructor) : t.apply(e, s));
}

var f = function(e, t, r, n) {
    var s, o = arguments.length, i = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : u(Reflect)) && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, r, n); else for (var c = e.length - 1; c >= 0; c--) (s = e[c]) && (i = (o < 3 ? s(i) : o > 3 ? s(t, r, i) : s(t, r)) || i);
    return o > 3 && i && Object.defineProperty(t, r, i), i;
}, p = i.default.prefix, d = "".concat(p, "-steps-item"), h = function(r) {
    function n() {
        var e;
        return t(this, n), (e = l(this, n, arguments)).options = {
            multipleSlots: !0
        }, e.relations = {
            "../steps/steps": {
                type: "parent"
            }
        }, e.externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-content"), "".concat(p, "-class-title"), "".concat(p, "-class-description"), "".concat(p, "-class-extra") ], 
        e.properties = c.default, e.data = {
            classPrefix: d,
            prefix: p,
            index: 0,
            isDot: !1,
            curStatus: "",
            layout: "vertical",
            isLastChild: !1,
            sequence: "positive"
        }, e.observers = {
            status: function(e) {
                var t = this.data.curStatus;
                "" !== t && e !== t && this.setData({
                    curStatus: e
                });
            }
        }, e.methods = {
            updateStatus: function(e) {
                var t = e.current, r = e.currentStatus, n = e.index, s = e.theme, u = e.layout, o = e.items, i = e.sequence, c = this.data.status;
                "default" === c && (n < Number(t) ? c = "finish" : n === Number(t) && (c = r)), 
                this.setData({
                    curStatus: c,
                    index: n,
                    isDot: "dot" === s,
                    layout: u,
                    theme: s,
                    sequence: i,
                    isLastChild: n === ("positive" === i ? o.length - 1 : 0)
                });
            },
            onTap: function() {
                this.$parent.handleClick(this.data.index);
            }
        }, e;
    }
    return s(n, r), e(n);
}(o.SuperComponent);

h = f([ (0, o.wxComponent)() ], h);

exports.default = h;