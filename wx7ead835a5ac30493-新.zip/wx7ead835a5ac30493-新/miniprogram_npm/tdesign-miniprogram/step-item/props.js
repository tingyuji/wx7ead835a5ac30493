Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    content: {
        type: String,
        value: ""
    },
    externalClasses: {
        type: Array
    },
    icon: {
        type: String
    },
    status: {
        type: String,
        value: "default"
    },
    subStepItems: {
        type: Array,
        value: []
    },
    title: {
        type: String,
        value: ""
    }
};

exports.default = e;