Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    badgeProps: {
        type: Object,
        value: null
    },
    description: {
        type: String
    },
    externalClasses: {
        type: Array
    },
    icon: {
        type: null
    },
    image: {
        type: String
    },
    imageProps: {
        type: Object
    },
    jumpType: {
        type: String,
        value: "navigate-to"
    },
    layout: {
        type: String,
        value: "vertical"
    },
    text: {
        type: String
    },
    url: {
        type: String,
        value: ""
    }
};

exports.default = e;