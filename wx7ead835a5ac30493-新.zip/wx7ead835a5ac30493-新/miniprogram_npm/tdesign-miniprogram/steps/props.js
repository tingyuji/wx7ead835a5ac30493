Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    current: {
        type: null,
        value: null
    },
    defaultCurrent: {
        type: null
    },
    currentStatus: {
        type: String,
        value: "process"
    },
    externalClasses: {
        type: Array
    },
    layout: {
        type: String,
        value: "horizontal"
    },
    readonly: {
        type: Boolean,
        value: !1
    },
    separator: {
        type: String,
        value: "line"
    },
    sequence: {
        type: String,
        value: "positive"
    },
    theme: {
        type: String,
        value: "default"
    }
};

exports.default = e;