Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), o = require("../../../@babel/runtime/helpers/typeof"), u = require("../common/src/index"), c = s(require("../common/config")), a = s(require("./props"));

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function l(e, t, i) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, i || [], n(e).constructor) : t.apply(e, i));
}

var f = function(e, t, r, n) {
    var i, u = arguments.length, c = u < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : o(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, r, n); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (c = (u < 3 ? i(c) : u > 3 ? i(t, r, c) : i(t, r)) || c);
    return u > 3 && c && Object.defineProperty(t, r, c), c;
}, d = c.default.prefix, p = "".concat(d, "-steps"), h = function(r) {
    function n() {
        var e;
        return t(this, n), (e = l(this, n, arguments)).relations = {
            "../step-item/step-item": {
                type: "child",
                linked: function(e) {
                    this.updateChildren();
                    var t = this.data.readonly;
                    e.setData({
                        readonly: t
                    });
                },
                unlinked: function() {
                    this.updateLastChid();
                }
            }
        }, e.externalClasses = [ "".concat(d, "-class") ], e.properties = a.default, e.controlledProps = [ {
            key: "current",
            event: "change"
        } ], e.data = {
            prefix: d,
            classPrefix: p
        }, e.observers = {
            current: function() {
                this.updateChildren();
            }
        }, e.methods = {
            updateChildren: function() {
                var e = this, t = this.$children;
                t.forEach(function(r, n) {
                    r.updateStatus(Object.assign({
                        index: n,
                        items: t
                    }, e.data));
                });
            },
            updateLastChid: function() {
                var e = this.$children;
                e.forEach(function(t, r) {
                    return t.setData({
                        isLastChild: r === e.length - 1
                    });
                });
            },
            handleClick: function(e) {
                if (!this.data.readonly) {
                    var t = this.data.current;
                    this._trigger("change", {
                        previous: t,
                        current: e
                    });
                }
            }
        }, e;
    }
    return i(n, r), e(n);
}(u.SuperComponent);

h = f([ (0, u.wxComponent)() ], h);

exports.default = h;