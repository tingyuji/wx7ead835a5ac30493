Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), c = require("../../../@babel/runtime/helpers/typeof"), a = require("../common/src/index"), o = u(require("../common/config")), s = u(require("./props")), l = require("../common/utils");

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, i) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, i || [], n(e).constructor) : t.apply(e, i));
}

var h = function(e, t, r, n) {
    var i, a = arguments.length, o = a < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : c(Reflect)) && "function" == typeof Reflect.decorate) o = Reflect.decorate(e, t, r, n); else for (var s = e.length - 1; s >= 0; s--) (i = e[s]) && (o = (a < 3 ? i(o) : a > 3 ? i(t, r, o) : i(t, r)) || o);
    return a > 3 && o && Object.defineProperty(t, r, o), o;
}, p = o.default.prefix, g = "".concat(p, "-input"), d = function(r) {
    function n() {
        var e;
        return t(this, n), (e = f(this, n, arguments)).options = {
            multipleSlots: !0
        }, e.externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-prefix-icon"), "".concat(p, "-class-label"), "".concat(p, "-class-input"), "".concat(p, "-class-clearable"), "".concat(p, "-class-suffix"), "".concat(p, "-class-suffix-icon"), "".concat(p, "-class-tips") ], 
        e.behaviors = [ "wx://form-field" ], e.properties = s.default, e.data = {
            prefix: p,
            classPrefix: g,
            classBasePrefix: p,
            showClearIcon: !0
        }, e.lifetimes = {
            ready: function() {
                var e = this.properties.value;
                this.updateValue(null != e ? e : "");
            }
        }, e.observers = {
            prefixIcon: function(e) {
                this.setData({
                    _prefixIcon: (0, l.calcIcon)(e)
                });
            },
            suffixIcon: function(e) {
                this.setData({
                    _suffixIcon: (0, l.calcIcon)(e)
                });
            },
            clearable: function(e) {
                this.setData({
                    _clearIcon: (0, l.calcIcon)(e, "close-circle-filled")
                });
            },
            clearTrigger: function() {
                this.updateClearIconVisible();
            }
        }, e.methods = {
            updateValue: function(e) {
                var t = this.properties, r = t.maxcharacter, n = t.maxlength;
                if (r && r > 0 && !Number.isNaN(r)) {
                    var i = (0, l.getCharacterLength)("maxcharacter", e, r), c = i.length, a = i.characters;
                    this.setData({
                        value: a,
                        count: c
                    });
                } else if (n && n > 0 && !Number.isNaN(n)) {
                    var o = (0, l.getCharacterLength)("maxlength", e, n), s = o.length, u = o.characters;
                    this.setData({
                        value: u,
                        count: s
                    });
                } else this.setData({
                    value: e,
                    count: (0, l.isDef)(e) ? String(e).length : 0
                });
            },
            updateClearIconVisible: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], t = this.properties.clearTrigger;
                this.setData({
                    showClearIcon: e || "always" === t
                });
            },
            onInput: function(e) {
                var t = e.detail, r = t.value, n = t.cursor, i = t.keyCode;
                this.updateValue(r), this.triggerEvent("change", {
                    value: this.data.value,
                    cursor: n,
                    keyCode: i
                });
            },
            onFocus: function(e) {
                this.updateClearIconVisible(!0), this.triggerEvent("focus", e.detail);
            },
            onBlur: function(e) {
                this.updateClearIconVisible(), this.triggerEvent("blur", e.detail);
            },
            onConfirm: function(e) {
                this.triggerEvent("enter", e.detail);
            },
            onSuffixClick: function() {
                this.triggerEvent("click", {
                    trigger: "suffix"
                });
            },
            onSuffixIconClick: function() {
                this.triggerEvent("click", {
                    trigger: "suffix-icon"
                });
            },
            clearInput: function(e) {
                this.triggerEvent("clear", e.detail), this.setData({
                    value: ""
                });
            },
            onKeyboardHeightChange: function(e) {
                this.triggerEvent("keyboardheightchange", e.detail);
            },
            onNickNameReview: function(e) {
                this.triggerEvent("nicknamereview", e.detail);
            }
        }, e;
    }
    return i(n, r), e(n);
}(a.SuperComponent);

d = h([ (0, a.wxComponent)() ], d);

exports.default = d;