Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    align: {
        type: String,
        value: "left"
    },
    layout: {
        type: String,
        value: "horizontal"
    },
    borderless: {
        type: Boolean,
        value: !1
    },
    clearable: {
        type: null,
        value: !1
    },
    clearTrigger: {
        type: String,
        value: "always"
    },
    disabled: {
        type: Boolean,
        value: !1
    },
    errorMessage: {
        type: String,
        value: ""
    },
    externalClasses: {
        type: Array
    },
    format: {
        type: null
    },
    label: {
        type: String
    },
    maxcharacter: {
        type: Number
    },
    maxlength: {
        type: Number,
        value: -1
    },
    placeholder: {
        type: String,
        value: void 0
    },
    prefixIcon: {
        type: null,
        value: null
    },
    readonly: {
        type: Boolean,
        value: !1
    },
    size: {
        type: String,
        value: "medium"
    },
    status: {
        type: String,
        value: "default"
    },
    suffix: {
        type: String
    },
    suffixIcon: {
        type: null,
        value: null
    },
    tips: {
        type: String
    },
    value: {
        type: String,
        optionalTypes: [ Number ],
        value: null
    },
    defaultValue: {
        type: String,
        optionalTypes: [ Number ]
    },
    type: {
        type: String,
        value: "text"
    },
    placeholderStyle: {
        type: String,
        value: ""
    },
    placeholderClass: {
        type: String,
        value: "input-placeholder"
    },
    cursorSpacing: {
        type: Number,
        value: 0
    },
    autoFocus: {
        type: Boolean,
        value: !1
    },
    focus: {
        type: Boolean,
        value: !1
    },
    confirmType: {
        type: String,
        value: "done"
    },
    alwaysEmbed: {
        type: Boolean,
        value: !1
    },
    confirmHold: {
        type: Boolean,
        value: !1
    },
    cursor: {
        type: Number
    },
    selectionStart: {
        type: Number,
        value: -1
    },
    selectionEnd: {
        type: Number,
        value: -1
    },
    adjustPosition: {
        type: Boolean,
        value: !0
    },
    holdKeyboard: {
        type: Boolean,
        value: !1
    },
    safePasswordCertPath: {
        type: String,
        value: ""
    },
    safePasswordLength: {
        type: Number
    },
    safePasswordTimeStamp: {
        type: Number
    },
    safePasswordNonce: {
        type: String,
        value: ""
    },
    safePasswordSalt: {
        type: String,
        value: ""
    },
    safePasswordCustomHash: {
        type: String,
        value: ""
    }
};

exports.default = e;