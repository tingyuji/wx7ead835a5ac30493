Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    bordered: {
        type: Boolean
    },
    externalClasses: {
        type: Array
    },
    theme: {
        type: String,
        value: "default"
    },
    title: {
        type: String,
        value: ""
    }
};

exports.default = e;