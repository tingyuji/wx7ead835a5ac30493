Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0, require("../../../@babel/runtime/helpers/Arrayincludes");

var e = require("../../../@babel/runtime/helpers/toConsumableArray"), t = require("../../../@babel/runtime/helpers/classCallCheck"), i = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), s = require("../../../@babel/runtime/helpers/typeof"), a = require("../common/src/index"), c = f(require("./props")), l = f(require("../common/config")), u = require("../common/utils");

function f(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function h(e, t, i) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, i || [], n(e).constructor) : t.apply(e, i));
}

var p = function(e, t, i, r) {
    var n, o = arguments.length, a = o < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : s(Reflect)) && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, r); else for (var c = e.length - 1; c >= 0; c--) (n = e[c]) && (a = (o < 3 ? n(a) : o > 3 ? n(t, i, a) : n(t, i)) || a);
    return o > 3 && a && Object.defineProperty(t, i, a), a;
}, d = function(e, t) {
    var i = {};
    for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (i[r] = e[r]);
    if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
        var n = 0;
        for (r = Object.getOwnPropertySymbols(e); n < r.length; n++) t.indexOf(r[n]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[n]) && (i[r[n]] = e[r[n]]);
    }
    return i;
}, m = l.default.prefix, g = "".concat(m, "-upload"), v = function(r) {
    function n() {
        var i;
        return t(this, n), (i = h(this, n, arguments)).externalClasses = [ "".concat(m, "-class") ], 
        i.options = {
            multipleSlots: !0
        }, i.data = {
            classPrefix: g,
            prefix: m,
            current: !1,
            proofs: [],
            customFiles: [],
            customLimit: 0,
            column: 4
        }, i.properties = c.default, i.controlledProps = [ {
            key: "files",
            event: "success"
        } ], i.observers = {
            "files, max": function(e, t) {
                this.handleLimit(e, t);
            },
            gridConfig: function() {
                this.updateGrid();
            }
        }, i.lifetimes = {
            ready: function() {
                this.handleLimit(this.data.customFiles, this.data.max), this.updateGrid();
            }
        }, i.methods = {
            uploadFiles: function(e) {
                var t = this;
                return new Promise(function(i) {
                    var r = t.data.requestMethod(e);
                    if (r instanceof Promise) return r;
                    i({});
                });
            },
            startUpload: function(e) {
                var t = this;
                return "function" == typeof this.data.requestMethod ? this.uploadFiles(e).then(function() {
                    e.forEach(function(e) {
                        e.percent = 100;
                    }), t.triggerSuccessEvent(e);
                }).catch(function(e) {
                    t.triggerFailEvent(e);
                }) : (this.triggerSuccessEvent(e), this.handleLimit(this.data.customFiles, this.data.max), 
                Promise.resolve());
            },
            onAddTap: function() {
                var e = this.properties, t = e.disabled, i = e.mediaType, r = e.source;
                t || ("media" === r ? this.chooseMedia(i) : this.chooseMessageFile(i));
            },
            chooseMedia: function(e) {
                var t = this, i = this.data, r = i.config, n = i.sizeLimit, o = i.customLimit;
                wx.chooseMedia(Object.assign(Object.assign({
                    count: o,
                    mediaType: e
                }, r), {
                    success: function(i) {
                        var r = [];
                        i.tempFiles.forEach(function(i) {
                            var o = i.size, s = i.fileType, a = i.tempFilePath, c = i.width, l = i.height, f = i.duration, h = i.thumbTempFilePath, p = d(i, [ "size", "fileType", "tempFilePath", "width", "height", "duration", "thumbTempFilePath" ]);
                            if ((0, u.isOverSize)(o, n)) {
                                var m = "".concat("image" === s ? "图片" : "视频", "大小超过限制");
                                return "number" != typeof n && (m = n.message.replace("{sizeLimit}", null == n ? void 0 : n.size)), 
                                void wx.showToast({
                                    icon: "none",
                                    title: m
                                });
                            }
                            var g = t.getRandFileName(a);
                            r.push(Object.assign({
                                name: g,
                                type: t.getFileType(e, a, s),
                                url: a,
                                size: o,
                                width: c,
                                height: l,
                                duration: f,
                                thumb: h,
                                percent: 0
                            }, p));
                        }), t.afterSelect(r);
                    },
                    fail: function(e) {
                        t.triggerFailEvent(e);
                    },
                    complete: function(e) {
                        t.triggerEvent("complete", e);
                    }
                }));
            },
            chooseMessageFile: function(e) {
                var t = this, i = this.properties, r = i.max, n = i.config, o = i.sizeLimit;
                wx.chooseMessageFile(Object.assign(Object.assign({
                    count: r,
                    type: Array.isArray(e) ? "all" : e
                }, n), {
                    success: function(i) {
                        var r = [];
                        i.tempFiles.forEach(function(i) {
                            var n = i.size, s = i.type, a = i.path, c = d(i, [ "size", "type", "path" ]);
                            if ((0, u.isOverSize)(n, o)) {
                                var l = "".concat("image" === s ? "图片" : "视频", "大小超过限制");
                                return "number" != typeof o && (l = o.message.replace("{sizeLimit}", null == o ? void 0 : o.size)), 
                                void wx.showToast({
                                    icon: "none",
                                    title: l
                                });
                            }
                            var f = t.getRandFileName(a);
                            r.push(Object.assign({
                                name: f,
                                type: t.getFileType(e, a, s),
                                url: a,
                                size: n,
                                percent: 0
                            }, c));
                        }), t.afterSelect(r);
                    },
                    fail: function(e) {
                        return t.triggerFailEvent(e);
                    },
                    complete: function(e) {
                        return t.triggerEvent("complete", e);
                    }
                }));
            },
            afterSelect: function(t) {
                this._trigger("select-change", {
                    files: e(this.data.customFiles),
                    currentSelectedFiles: [ t ]
                }), this._trigger("add", {
                    files: t
                }), this.startUpload(t);
            }
        }, i;
    }
    return o(n, r), i(n, [ {
        key: "onProofTap",
        value: function(e) {
            var t;
            this.onFileClick(e);
            var i = e.currentTarget.dataset.index;
            wx.previewImage({
                urls: this.data.customFiles.filter(function(e) {
                    return -1 !== e.percent;
                }).map(function(e) {
                    return e.url;
                }),
                current: null === (t = this.data.customFiles[i]) || void 0 === t ? void 0 : t.url
            });
        }
    }, {
        key: "handleLimit",
        value: function(e, t) {
            0 === t && (t = 20), this.setData({
                customFiles: e.length > t ? e.slice(0, t) : e,
                customLimit: t - e.length
            });
        }
    }, {
        key: "triggerSuccessEvent",
        value: function(t) {
            this._trigger("success", {
                files: [].concat(e(this.data.customFiles), e(t))
            });
        }
    }, {
        key: "triggerFailEvent",
        value: function(e) {
            this.triggerEvent("fail", e);
        }
    }, {
        key: "onFileClick",
        value: function(e) {
            var t = e.currentTarget.dataset.file;
            this.triggerEvent("click", {
                file: t
            });
        }
    }, {
        key: "getFileType",
        value: function(e, t, i) {
            if (i) return i;
            if (1 === e.length) return e[0];
            var r = t.split("."), n = r[r.length - 1];
            return [ "avi", "wmv", "mkv", "mp4", "mov", "rm", "3gp", "flv", "mpg", "rmvb" ].includes(n.toLocaleLowerCase()) ? "video" : "image";
        }
    }, {
        key: "getRandFileName",
        value: function(e) {
            var t = e.lastIndexOf("."), i = -1 === t ? "" : e.substr(t);
            return parseInt("".concat(Date.now()).concat(Math.floor(900 * Math.random() + 100)), 10).toString(36) + i;
        }
    }, {
        key: "onDelete",
        value: function(e) {
            var t = e.currentTarget.dataset.index;
            this.deleteHandle(t);
        }
    }, {
        key: "deleteHandle",
        value: function(e) {
            var t = this.data.customFiles[e];
            this.triggerEvent("remove", {
                index: e,
                file: t
            });
        }
    }, {
        key: "updateGrid",
        value: function() {
            var e = this.properties.gridConfig, t = void 0 === e ? {} : e;
            (0, a.isObject)(t) || (t = {});
            var i = t, r = i.column, n = void 0 === r ? 4 : r, o = i.width, s = void 0 === o ? 160 : o, c = i.height, l = void 0 === c ? 160 : c;
            this.setData({
                gridItemStyle: "width:".concat(s, "rpx;height:").concat(l, "rpx"),
                column: n
            });
        }
    } ]);
}(a.SuperComponent);

v = p([ (0, a.wxComponent)() ], v);

exports.default = v;