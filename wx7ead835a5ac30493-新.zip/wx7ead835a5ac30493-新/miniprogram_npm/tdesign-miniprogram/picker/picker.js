Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/slicedToArray"), t = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), l = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), u = require("../../../@babel/runtime/helpers/typeof"), o = require("../common/src/index"), c = s(require("../common/config")), a = s(require("./props"));

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, n) {
    return t = l(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, n || [], l(e).constructor) : t.apply(e, n));
}

var d = function(e, t, n, r) {
    var l, i = arguments.length, o = i < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, n) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : u(Reflect)) && "function" == typeof Reflect.decorate) o = Reflect.decorate(e, t, n, r); else for (var c = e.length - 1; c >= 0; c--) (l = e[c]) && (o = (i < 3 ? l(o) : i > 3 ? l(t, n, o) : l(t, n)) || o);
    return i > 3 && o && Object.defineProperty(t, n, o), o;
}, p = c.default.prefix, h = "".concat(p, "-picker"), v = function(r) {
    function l() {
        var n;
        return t(this, l), (n = f(this, l, arguments)).properties = a.default, n.externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-confirm"), "".concat(p, "-class-cancel"), "".concat(p, "-class-title") ], 
        n.options = {
            multipleSlots: !0
        }, n.relations = {
            "../picker-item/picker-item": {
                type: "child",
                linked: function() {
                    this.updateChildren();
                }
            }
        }, n.observers = {
            "value, visible": function() {
                this.updateChildren();
            },
            keys: function(e) {
                this.setData({
                    labelAlias: (null == e ? void 0 : e.label) || "label",
                    valueAlias: (null == e ? void 0 : e.value) || "value"
                });
            }
        }, n.data = {
            prefix: p,
            classPrefix: h,
            labelAlias: "label",
            valueAlias: "value",
            defaultPopUpProps: {},
            defaultPopUpzIndex: 11500
        }, n.methods = {
            updateChildren: function() {
                var e = this.properties, t = e.value, n = e.defaultValue;
                this.$children.forEach(function(e, r) {
                    var l, i;
                    e.setData({
                        value: null !== (i = null !== (l = null == t ? void 0 : t[r]) && void 0 !== l ? l : null == n ? void 0 : n[r]) && void 0 !== i ? i : "",
                        columnIndex: r
                    }), e.update();
                });
            },
            getSelectedValue: function() {
                return [ this.$children.map(function(e) {
                    return e._selectedValue;
                }), this.$children.map(function(e) {
                    return e._selectedLabel;
                }) ];
            },
            getColumnIndexes: function() {
                return this.$children.map(function(e, t) {
                    return {
                        column: t,
                        index: e._selectedIndex
                    };
                });
            },
            onConfirm: function() {
                var t = this.getSelectedValue(), n = e(t, 2), r = n[0], l = n[1], i = this.getColumnIndexes();
                this.close("confirm-btn"), this.triggerEvent("change", {
                    value: r,
                    label: l,
                    columns: i
                }), this.triggerEvent("confirm", {
                    value: r,
                    label: l,
                    columns: i
                });
            },
            triggerColumnChange: function(t) {
                var n = t.column, r = t.index, l = this.getSelectedValue(), i = e(l, 2), u = i[0], o = i[1];
                this.triggerEvent("pick", {
                    value: u,
                    label: o,
                    column: n,
                    index: r
                });
            },
            onCancel: function() {
                this.close("cancel-btn"), this.triggerEvent("cancel");
            },
            onPopupChange: function(e) {
                var t = e.detail.visible;
                this.close("overlay"), this.triggerEvent("visible-change", {
                    visible: t
                });
            },
            close: function(e) {
                this.data.autoClose && this.setData({
                    visible: !1
                }), this.triggerEvent("close", {
                    trigger: e
                });
            }
        }, n;
    }
    return i(l, r), n(l, [ {
        key: "ready",
        value: function() {
            this.$children.map(function(e, t) {
                return e.columnIndex = t;
            });
        }
    } ]);
}(o.SuperComponent);

v = d([ (0, o.wxComponent)() ], v);

exports.default = v;