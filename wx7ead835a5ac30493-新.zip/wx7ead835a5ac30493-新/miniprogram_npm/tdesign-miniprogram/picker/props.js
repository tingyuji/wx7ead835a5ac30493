Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    autoClose: {
        type: Boolean,
        value: !0
    },
    cancelBtn: {
        type: null,
        value: !0
    },
    confirmBtn: {
        type: null,
        value: !0
    },
    header: {
        type: Boolean,
        value: !0
    },
    keys: {
        type: Object
    },
    title: {
        type: String,
        value: ""
    },
    value: {
        type: Array,
        value: null
    },
    defaultValue: {
        type: Array
    },
    visible: {
        type: Boolean,
        value: !1
    },
    popupProps: {
        type: Object,
        value: {}
    }
};

exports.default = e;