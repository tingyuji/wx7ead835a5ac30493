Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    autoClose: {
        type: Boolean,
        value: !0
    },
    confirmBtn: {
        type: null,
        value: ""
    },
    style: {
        type: String,
        value: ""
    },
    firstDayOfWeek: {
        type: Number,
        value: 0
    },
    format: {
        type: null
    },
    maxDate: {
        type: Number
    },
    minDate: {
        type: Number
    },
    title: {
        type: String
    },
    type: {
        type: String,
        value: "single"
    },
    usePopup: {
        type: Boolean,
        value: !0
    },
    value: {
        type: null,
        value: null
    },
    defaultValue: {
        type: null
    },
    visible: {
        type: Boolean,
        value: !1
    }
};

exports.default = e;