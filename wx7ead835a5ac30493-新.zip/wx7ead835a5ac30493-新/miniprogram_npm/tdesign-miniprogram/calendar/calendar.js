Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), i = require("../../../@babel/runtime/helpers/getPrototypeOf"), a = require("../../../@babel/runtime/helpers/inherits"), r = require("../../../@babel/runtime/helpers/typeof"), s = require("../common/src/index"), o = u(require("../common/config")), l = u(require("./props")), c = u(require("../common/shared/calendar/index"));

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function h(e, t, a) {
    return t = i(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, a || [], i(e).constructor) : t.apply(e, a));
}

var f = function(e, t, n, i) {
    var a, s = arguments.length, o = s < 3 ? t : null === i ? i = Object.getOwnPropertyDescriptor(t, n) : i;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : r(Reflect)) && "function" == typeof Reflect.decorate) o = Reflect.decorate(e, t, n, i); else for (var l = e.length - 1; l >= 0; l--) (a = e[l]) && (o = (s < 3 ? a(o) : s > 3 ? a(t, n, o) : a(t, n)) || o);
    return s > 3 && o && Object.defineProperty(t, n, o), o;
}, p = o.default.prefix, d = "".concat(p, "-calendar"), m = function(n) {
    function i() {
        var e;
        return t(this, i), (e = h(this, i, arguments)).externalClasses = [ "".concat(p, "-class") ], 
        e.options = {
            multipleSlots: !0,
            styleIsolation: "apply-shared"
        }, e.properties = l.default, e.data = {
            prefix: p,
            classPrefix: d,
            months: [],
            scrollIntoView: "",
            innerConfirmBtn: {
                content: "确定"
            }
        }, e.controlledProps = [ {
            key: "value",
            event: "confirm"
        }, {
            key: "value",
            event: "change"
        } ], e.lifetimes = {
            created: function() {
                this.base = new c.default(this.properties);
            },
            ready: function() {
                this.initialValue(), this.setData({
                    days: this.base.getDays()
                }), this.calcMonths(), this.data.usePopup || this.scrollIntoView();
            }
        }, e.observers = {
            type: function(e) {
                this.base.type = e;
            },
            confirmBtn: function(e) {
                "string" == typeof e ? this.setData({
                    innerConfirmBtn: "slot" === e ? "slot" : {
                        content: e
                    }
                }) : "object" === r(e) && this.setData({
                    innerConfirmBtn: e
                });
            },
            "firstDayOfWeek,minDate,maxDate": function(e, t, n) {
                e && (this.base.firstDayOfWeek = e), t && (this.base.minDate = t), n && (this.base.maxDate = n), 
                this.calcMonths();
            },
            value: function(e) {
                this.base.value = e;
            },
            visible: function(e) {
                e && (this.scrollIntoView(), this.base.value = this.data.value, this.calcMonths());
            },
            format: function(e) {
                this.base.format = e, this.data.usePopup || this.calcMonths();
            }
        }, e.methods = {
            initialValue: function() {
                var e = this.data, t = e.value, n = e.type, i = e.minDate;
                if (!t) {
                    var a = new Date(), r = i || new Date(a.getFullYear(), a.getMonth(), a.getDate()).getTime(), s = "single" === n ? r : [ r ];
                    "range" === n && (s[1] = r + 864e5), this.setData({
                        value: s
                    }), this.base.value = s;
                }
            },
            scrollIntoView: function() {
                var e = this.data.value;
                if (e) {
                    var t = new Date(Array.isArray(e) ? e[0] : e);
                    t && this.setData({
                        scrollIntoView: "year_".concat(t.getFullYear(), "_month_").concat(t.getMonth())
                    });
                }
            },
            calcMonths: function() {
                var e = this.base.getMonths();
                this.setData({
                    months: e
                });
            },
            close: function(e) {
                this.data.autoClose && this.setData({
                    visible: !1
                }), this.triggerEvent("close", {
                    trigger: e
                });
            },
            onVisibleChange: function() {
                this.close("overlay");
            },
            handleClose: function() {
                this.close("close-btn");
            },
            handleSelect: function(e) {
                var t = e.currentTarget.dataset, n = t.date, i = t.year, a = t.month;
                if ("disabled" !== n.type) {
                    var r = this.base.select({
                        cellType: n.type,
                        year: i,
                        month: a,
                        date: n.day
                    }), s = this.toTime(r);
                    this.calcMonths(), null == this.data.confirmBtn && ("single" !== this.data.type && 2 !== r.length || (this.setData({
                        visible: !1
                    }), this._trigger("change", {
                        value: s
                    }))), this.triggerEvent("select", {
                        value: s
                    });
                }
            },
            onTplButtonTap: function() {
                var e = this.base.getTrimValue(), t = this.toTime(e);
                this.close("confirm-btn"), this._trigger("confirm", {
                    value: t
                });
            },
            toTime: function(e) {
                return Array.isArray(e) ? e.map(function(e) {
                    return e.getTime();
                }) : e.getTime();
            }
        }, e;
    }
    return a(i, n), e(i);
}(s.SuperComponent);

m = f([ (0, s.wxComponent)() ], m);

exports.default = m;