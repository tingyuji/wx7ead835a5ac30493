Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getObserver = void 0;

exports.getObserver = function(e, r) {
    return new Promise(function(t, o) {
        wx.createIntersectionObserver(e).relativeToViewport().observe(r, function(e) {
            t(e);
        });
    });
};