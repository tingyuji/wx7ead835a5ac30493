Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = function(e) {
    return e.options = Object.assign({
        multipleSlots: !0,
        addGlobalClass: !0
    }, e.options), Component(e);
};