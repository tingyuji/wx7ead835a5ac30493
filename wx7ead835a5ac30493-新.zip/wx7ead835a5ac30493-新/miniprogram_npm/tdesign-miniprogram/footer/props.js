Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    text: {
        type: String,
        value: ""
    },
    logo: {
        type: Object
    },
    links: {
        type: Array,
        value: []
    }
};

exports.default = e;