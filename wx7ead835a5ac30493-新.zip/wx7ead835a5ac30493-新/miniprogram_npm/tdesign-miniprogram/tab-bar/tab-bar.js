Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), a = require("../../../@babel/runtime/helpers/typeof"), o = require("../common/src/index"), c = l(require("../common/config")), u = l(require("./props"));

function l(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function s(e, t, i) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, i || [], n(e).constructor) : t.apply(e, i));
}

var f = function(e, t, r, n) {
    var i, o = arguments.length, c = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : a(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, r, n); else for (var u = e.length - 1; u >= 0; u--) (i = e[u]) && (c = (o < 3 ? i(c) : o > 3 ? i(t, r, c) : i(t, r)) || c);
    return o > 3 && c && Object.defineProperty(t, r, c), c;
}, h = c.default.prefix, p = "".concat(h, "-tab-bar"), d = function(r) {
    function n() {
        var e;
        return t(this, n), (e = s(this, n, arguments)).relations = {
            "../tab-bar-item/tab-bar-item": {
                type: "descendant"
            }
        }, e.externalClasses = [ "".concat(h, "-class") ], e.backupValue = -1, e.data = {
            prefix: h,
            classPrefix: p
        }, e.properties = u.default, e.controlledProps = [ {
            key: "value",
            event: "change"
        } ], e.observers = {
            value: function() {
                this.updateChildren();
            }
        }, e.lifetimes = {
            ready: function() {
                this.showChildren();
            },
            attached: function() {
                this.getCustomTabbarHeight();
            }
        }, e.methods = {
            showChildren: function() {
                var e = this, t = this.data.value;
                this.$children.forEach(function(r) {
                    r.properties.value === t && (r.showSpread(), r.setData({
                        crowded: e.$children > 3
                    }));
                });
            },
            updateChildren: function() {
                var e = this.data.value;
                this.$children.forEach(function(t) {
                    t.checkActive(e);
                });
            },
            updateValue: function(e) {
                this._trigger("change", {
                    value: e
                });
            },
            changeOtherSpread: function(e) {
                this.$children.forEach(function(t) {
                    t.properties.value !== e && t.closeSpread();
                });
            },
            initName: function() {
                return this.backupValue += 1;
            },
            getCustomTabbarHeight: function() {
                var e = this;
                this.createSelectorQuery().select("#tabbar").boundingClientRect(function(t) {
                    wx.setStorageSync("tabBarHeight", t.height), e._trigger("onload", {
                        tabBarHeight: t.height
                    });
                }).exec();
            }
        }, e;
    }
    return i(n, r), e(n);
}(o.SuperComponent);

d = f([ (0, o.wxComponent)() ], d);

exports.default = d;