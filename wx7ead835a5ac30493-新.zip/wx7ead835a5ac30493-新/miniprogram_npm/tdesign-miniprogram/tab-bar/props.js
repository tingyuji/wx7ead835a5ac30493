Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    bordered: {
        type: Boolean,
        value: !0
    },
    externalClasses: {
        type: Array
    },
    fixed: {
        type: Boolean,
        value: !0
    },
    safeAreaInsetBottom: {
        type: Boolean,
        value: !0
    },
    shape: {
        type: String,
        value: "normal"
    },
    split: {
        type: Boolean,
        value: !0
    },
    theme: {
        type: String,
        value: "normal"
    },
    value: {
        type: null,
        value: null
    },
    defaultValue: {
        type: null,
        value: null
    }
};

exports.default = e;