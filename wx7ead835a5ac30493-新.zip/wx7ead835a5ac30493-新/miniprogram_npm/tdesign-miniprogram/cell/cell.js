Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/classCallCheck"), t = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), c = require("../../../@babel/runtime/helpers/getPrototypeOf"), n = require("../../../@babel/runtime/helpers/inherits"), o = require("../../../@babel/runtime/helpers/typeof"), l = require("../common/src/index"), i = a(require("../common/config")), s = a(require("./props"));

function a(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function u(e, t, n) {
    return t = c(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, n || [], c(e).constructor) : t.apply(e, n));
}

var f = function(e, t, r, c) {
    var n, l = arguments.length, i = l < 3 ? t : null === c ? c = Object.getOwnPropertyDescriptor(t, r) : c;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : o(Reflect)) && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, r, c); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (i = (l < 3 ? n(i) : l > 3 ? n(t, r, i) : n(t, r)) || i);
    return l > 3 && i && Object.defineProperty(t, r, i), i;
}, p = i.default.prefix, d = "".concat(p, "-cell"), h = function(r) {
    function c() {
        var t;
        return e(this, c), (t = u(this, c, arguments)).externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-title"), "".concat(p, "-class-description"), "".concat(p, "-class-note"), "".concat(p, "-class-hover"), "".concat(p, "-class-image"), "".concat(p, "-class-left"), "".concat(p, "-class-left-icon"), "".concat(p, "-class-center"), "".concat(p, "-class-right"), "".concat(p, "-class-right-icon") ], 
        t.relations = {
            "../cell-group/cell-group": {
                type: "parent"
            }
        }, t.options = {
            multipleSlots: !0
        }, t.properties = s.default, t.data = {
            prefix: p,
            classPrefix: d,
            isLastChild: !1
        }, t;
    }
    return n(c, r), t(c, [ {
        key: "onClick",
        value: function(e) {
            this.triggerEvent("click", e.detail), this.jumpLink();
        }
    }, {
        key: "jumpLink",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "url", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "jumpType", r = this.data[e], c = this.data[t];
            r && wx[c]({
                url: r
            });
        }
    } ]);
}(l.SuperComponent);

h = f([ (0, l.wxComponent)() ], h);

exports.default = h;