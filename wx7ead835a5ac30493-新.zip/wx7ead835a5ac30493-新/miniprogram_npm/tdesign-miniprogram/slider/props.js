Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    disabled: {
        type: Boolean,
        value: !1
    },
    externalClasses: {
        type: Array
    },
    label: {
        type: null,
        value: !1
    },
    marks: {
        type: null,
        value: {}
    },
    max: {
        type: Number,
        value: 100
    },
    min: {
        type: Number,
        value: 0
    },
    range: {
        type: Boolean,
        value: !1
    },
    showExtremeValue: {
        type: Boolean,
        value: !1
    },
    step: {
        type: Number,
        value: 1
    },
    theme: {
        type: String,
        value: "default"
    },
    value: {
        type: null,
        value: null
    },
    defaultValue: {
        type: null,
        value: 0
    }
};

exports.default = e;