Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/toConsumableArray"), t = require("../../../@babel/runtime/helpers/slicedToArray"), r = require("../../../@babel/runtime/helpers/regeneratorRuntime"), i = require("../../../@babel/runtime/helpers/classCallCheck"), a = require("../../../@babel/runtime/helpers/createClass"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), u = require("../../../@babel/runtime/helpers/getPrototypeOf"), s = require("../../../@babel/runtime/helpers/inherits"), l = require("../../../@babel/runtime/helpers/typeof"), o = require("../common/src/index"), c = b(require("../common/config")), h = require("./tool"), f = b(require("./props")), p = require("../common/utils"), m = b(require("../common/bus"));

function b(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function g(e, t, r) {
    return t = u(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, r || [], u(e).constructor) : t.apply(e, r));
}

var v = function(e, t, r, i) {
    var a, n = arguments.length, u = n < 3 ? t : null === i ? i = Object.getOwnPropertyDescriptor(t, r) : i;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : l(Reflect)) && "function" == typeof Reflect.decorate) u = Reflect.decorate(e, t, r, i); else for (var s = e.length - 1; s >= 0; s--) (a = e[s]) && (u = (n < 3 ? a(u) : n > 3 ? a(t, r, u) : a(t, r)) || u);
    return n > 3 && u && Object.defineProperty(t, r, u), u;
}, d = function(e, t, r, i) {
    return new (r || (r = Promise))(function(a, n) {
        function u(e) {
            try {
                l(i.next(e));
            } catch (e) {
                n(e);
            }
        }
        function s(e) {
            try {
                l(i.throw(e));
            } catch (e) {
                n(e);
            }
        }
        function l(e) {
            var t;
            e.done ? a(e.value) : (t = e.value, t instanceof r ? t : new r(function(e) {
                e(t);
            })).then(u, s);
        }
        l((i = i.apply(e, t || [])).next());
    });
}, y = c.default.prefix, x = "".concat(y, "-slider"), R = function(n) {
    function u() {
        var e;
        return i(this, u), (e = g(this, u, arguments)).externalClasses = [ "".concat(y, "-class"), "".concat(y, "-class-bar"), "".concat(y, "-class-bar-active"), "".concat(y, "-class-bar-disabled"), "".concat(y, "-class-cursor") ], 
        e.properties = f.default, e.controlledProps = [ {
            key: "value",
            event: "change"
        } ], e.data = {
            sliderStyles: "",
            classPrefix: x,
            initialLeft: null,
            initialRight: null,
            activeLeft: 0,
            activeRight: 0,
            maxRange: 0,
            lineLeft: 0,
            lineRight: 0,
            dotTopValue: [ 0, 0 ],
            _value: 0,
            blockSize: 20,
            isScale: !1,
            scaleArray: [],
            scaleTextArray: [],
            prefix: y,
            isVisibleToScreenReader: !1
        }, e.observers = {
            value: function(e) {
                this.handlePropsChange(e);
            },
            _value: function(e) {
                var t = this;
                this.bus.on("initial", function() {
                    return t.renderLine(e);
                }), this.toggleA11yTips();
            },
            marks: function(e) {
                var t = this;
                this.bus.on("initial", function() {
                    return t.handleMark(e);
                });
            }
        }, e.lifetimes = {
            created: function() {
                this.bus = new m.default();
            },
            attached: function() {
                this.properties.value || this.handlePropsChange(0), this.init();
            }
        }, e;
    }
    return s(u, n), a(u, [ {
        key: "toggleA11yTips",
        value: function() {
            var e = this;
            this.setData({
                isVisibleToScreenReader: !0
            }), setTimeout(function() {
                e.setData({
                    isVisibleToScreenReader: !1
                });
            }, 2e3);
        }
    }, {
        key: "renderLine",
        value: function(e) {
            var t = this.properties, r = t.min, i = t.max, a = t.range, n = this.data.maxRange;
            if (a) {
                var u = n * (e[0] - Number(r)) / (Number(i) - Number(r)), s = n * (Number(i) - e[1]) / (Number(i) - Number(r));
                this.setLineStyle(u, s);
            } else this.setSingleBarWidth(e);
        }
    }, {
        key: "triggerValue",
        value: function(e) {
            this.preval !== e && (this.preval = e, this._trigger("change", {
                value: (0, h.trimValue)(e, this.properties)
            }));
        }
    }, {
        key: "handlePropsChange",
        value: function(e) {
            var t = this, r = (0, h.trimValue)(e, this.properties), i = function() {
                t.setData({
                    _value: r
                });
            };
            0 !== this.data.maxRange ? i() : this.init().then(i);
        }
    }, {
        key: "handleMark",
        value: function(e) {
            var t = this, r = function(e) {
                var r = t.properties, i = r.max, a = r.theme, n = t.data, u = n.blockSize, s = n.maxRange, l = "capsule" === a ? u / 2 : 0;
                return e.map(function(e) {
                    return {
                        val: e,
                        left: Math.round(e / Number(i) * s) + l
                    };
                });
            };
            if ((null == e ? void 0 : e.length) && Array.isArray(e) && this.setData({
                isScale: !0,
                scaleArray: r(e),
                scaleTextArray: []
            }), "[object Object]" === Object.prototype.toString.call(e)) {
                var i = Object.keys(e).map(function(e) {
                    return Number(e);
                }), a = i.map(function(t) {
                    return e[t];
                });
                this.setData({
                    isScale: i.length > 0,
                    scaleArray: r(i),
                    scaleTextArray: a
                });
            }
        }
    }, {
        key: "setSingleBarWidth",
        value: function(e) {
            var t = this.properties, r = t.max, i = t.min, a = t.theme, n = this.data, u = n.maxRange, s = n.blockSize, l = "capsule" === a ? Number(s) / 2 : 0, o = (Number(e) - Number(i)) / (Number(r) - Number(i)) * u + l;
            this.setData({
                lineBarWidth: "".concat(o, "px")
            });
        }
    }, {
        key: "init",
        value: function() {
            return d(this, void 0, void 0, r().mark(function e() {
                var t, i, a, n, u, s, l;
                return r().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, (0, p.getRect)(this, "#sliderLine");

                      case 2:
                        if (t = e.sent, i = this.data.blockSize, a = this.properties.theme, n = Number(i) / 2, 
                        u = t.right - t.left, s = t.left, l = t.right, 0 !== s || 0 !== l) {
                            e.next = 11;
                            break;
                        }
                        return e.abrupt("return");

                      case 11:
                        "capsule" === a && (u = u - Number(i) - 6, s -= n, l -= n), this.setData({
                            maxRange: u,
                            initialLeft: s,
                            initialRight: l
                        }), this.bus.emit("initial");

                      case 14:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
        }
    }, {
        key: "stepValue",
        value: function(e) {
            var t = this.properties, r = t.step, i = t.min, a = t.max, n = String(r).indexOf(".") > -1 ? String(r).length - String(r).indexOf(".") - 1 : 0;
            return (0, h.trimSingleValue)(Number((Math.round(e / Number(r)) * Number(r)).toFixed(n)), Number(i), Number(a));
        }
    }, {
        key: "onSingleLineTap",
        value: function(e) {
            if (!this.properties.disabled) {
                var t = this.getSingleChangeValue(e);
                this.triggerValue(t);
            }
        }
    }, {
        key: "getSingleChangeValue",
        value: function(e) {
            var r = this.properties, i = r.min, a = r.max, n = this.data, u = n.initialLeft, s = n.maxRange, l = t(e.changedTouches, 1)[0].pageX - u, o = 0;
            return o = l <= 0 ? Number(i) : l >= s ? Number(a) : l / s * (Number(a) - Number(i)) + Number(i), 
            this.stepValue(o);
        }
    }, {
        key: "convertPosToValue",
        value: function(e, t) {
            var r = this.data.maxRange, i = this.properties, a = i.max, n = i.min;
            return 0 === t ? e / r * (Number(a) - Number(n)) + Number(n) : Number(a) - e / r * (Number(a) - Number(n));
        }
    }, {
        key: "onLineTap",
        value: function(e) {
            var r = this, i = this.properties, a = i.disabled, n = i.theme, u = this.data, s = u.initialLeft, l = u.initialRight, o = u.maxRange, c = u.blockSize;
            if (!a) {
                var h = t(e.changedTouches, 1)[0].pageX, f = "capsule" === n ? Number(c) / 2 : 0, m = h - s;
                m < 0 || m > o + Number(c) || Promise.all([ (0, p.getRect)(this, "#leftDot"), (0, 
                p.getRect)(this, "#rightDot") ]).then(function(e) {
                    var i = t(e, 2), a = i[0], n = i[1];
                    if (Math.abs(h - a.left - f) < Math.abs(n.left - h + f)) {
                        var u = h - s, o = r.convertPosToValue(u, 0);
                        r.triggerValue([ r.stepValue(o), r.data._value[1] ]);
                    } else {
                        var c = -(h - l), p = r.convertPosToValue(c, 1);
                        r.triggerValue([ r.data._value[0], r.stepValue(p) ]);
                    }
                });
            }
        }
    }, {
        key: "onTouchStart",
        value: function(e) {
            this.triggerEvent("dragstart", {
                e: e
            });
        }
    }, {
        key: "onTouchMoveLeft",
        value: function(r) {
            var i = this.properties.disabled, a = this.data, n = a.initialLeft, u = a._value;
            if (!i) {
                var s = t(r.changedTouches, 1)[0].pageX - n, l = e(u), o = this.convertPosToValue(s, 0);
                l[0] = this.stepValue(o), this.triggerValue(l);
            }
        }
    }, {
        key: "onTouchMoveRight",
        value: function(r) {
            var i = this.properties.disabled, a = this.data, n = a.initialRight, u = a._value;
            if (!i) {
                var s = -(t(r.changedTouches, 1)[0].pageX - n), l = e(u), o = this.convertPosToValue(s, 1);
                l[1] = this.stepValue(o), this.triggerValue(l);
            }
        }
    }, {
        key: "setLineStyle",
        value: function(e, r) {
            var i = this.properties.theme, a = this.data, n = a.blockSize, u = a.maxRange, s = "capsule" === i ? Number(n) / 2 : 0, l = t(this.data._value, 2), o = l[0], c = l[1], h = function(e) {
                return parseInt(e, 10);
            };
            this.setData({
                dotTopValue: [ o, c ]
            }), e + r <= u ? this.setData({
                lineLeft: h(e + s),
                lineRight: h(r + s)
            }) : this.setData({
                lineLeft: h(u + s - r),
                lineRight: h(u - e + 1.5 * s)
            });
        }
    }, {
        key: "onTouchEnd",
        value: function(e) {
            this.triggerEvent("dragend", {
                e: e
            });
        }
    } ]);
}(o.SuperComponent);

R = v([ (0, o.wxComponent)() ], R);

exports.default = R;