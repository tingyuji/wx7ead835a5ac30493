Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    cascading: {
        type: String,
        value: "left-up"
    },
    collapseAvatar: {
        type: String
    },
    externalClasses: {
        type: Array
    },
    max: {
        type: Number
    },
    size: {
        type: String,
        value: "medium"
    }
};

exports.default = e;