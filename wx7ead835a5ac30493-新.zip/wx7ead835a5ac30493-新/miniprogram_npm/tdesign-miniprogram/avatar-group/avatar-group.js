Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), r = require("../../../@babel/runtime/helpers/getPrototypeOf"), a = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/typeof"), c = require("../common/src/index"), s = l(require("../common/config")), o = l(require("./props"));

function l(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function u(e, t, a) {
    return t = r(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, a || [], r(e).constructor) : t.apply(e, a));
}

var f = function(e, t, n, r) {
    var a, c = arguments.length, s = c < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, n) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : i(Reflect)) && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, n, r); else for (var o = e.length - 1; o >= 0; o--) (a = e[o]) && (s = (c < 3 ? a(s) : c > 3 ? a(t, n, s) : a(t, n)) || s);
    return c > 3 && s && Object.defineProperty(t, n, s), s;
}, h = s.default.prefix, d = "".concat(h, "-avatar-group"), p = function(n) {
    function r() {
        var e;
        return t(this, r), (e = u(this, r, arguments)).externalClasses = [ "".concat(h, "-class"), "".concat(h, "-class-content"), "".concat(h, "-class-image") ], 
        e.properties = o.default, e.data = {
            prefix: h,
            classPrefix: d,
            hasChild: !0,
            length: 0,
            className: ""
        }, e.options = {
            multipleSlots: !0
        }, e.relations = {
            "../avatar/avatar": {
                type: "descendant"
            }
        }, e.lifetimes = {
            attached: function() {
                this.setClass();
            },
            ready: function() {
                this.setData({
                    length: this.$children.length
                }), this.handleMax(), this.handleChildCascading();
            }
        }, e.observers = {
            "cascading, size": function() {
                this.setClass();
            }
        }, e.methods = {
            setClass: function() {
                var e = this.properties, t = e.cascading, n = e.size, r = t.split("-")[0], a = [ d, "".concat(h, "-class"), "".concat(d, "-offset-").concat(r, "-").concat(n.indexOf("px") > -1 ? "medium" : n) ];
                this.setData({
                    className: a.join(" ")
                });
            },
            handleMax: function() {
                var e = this.data.max, t = this.$children.length;
                !e || e > t || this.$children.splice(e, t - e).forEach(function(e) {
                    e.hide();
                });
            },
            handleChildCascading: function() {
                if ("right-up" !== this.properties.cascading) {
                    this.$children.forEach(function(e, t) {
                        e.updateCascading(100 - 10 * t);
                    });
                }
            }
        }, e;
    }
    return a(r, n), e(r);
}(c.SuperComponent);

p = f([ (0, c.wxComponent)() ], p);

exports.default = p;