Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/typeof"), a = require("../common/src/index"), s = l(require("../common/config")), c = l(require("./props")), u = require("../common/utils");

function l(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, o) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, o || [], n(e).constructor) : t.apply(e, o));
}

var p = function(e, t, r, n) {
    var o, a = arguments.length, s = a < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : i(Reflect)) && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, n); else for (var c = e.length - 1; c >= 0; c--) (o = e[c]) && (s = (a < 3 ? o(s) : a > 3 ? o(t, r, s) : o(t, r)) || s);
    return a > 3 && s && Object.defineProperty(t, r, s), s;
}, d = s.default.prefix, h = "".concat(d, "-avatar"), b = function(r) {
    function n() {
        var e;
        return t(this, n), (e = f(this, n, arguments)).options = {
            multipleSlots: !0,
            styleIsolation: "apply-shared"
        }, e.externalClasses = [ "".concat(d, "-class"), "".concat(d, "-class-image"), "".concat(d, "-class-icon"), "".concat(d, "-class-alt"), "".concat(d, "-class-content") ], 
        e.properties = c.default, e.data = {
            prefix: d,
            classPrefix: h,
            isShow: !0,
            zIndex: 0,
            borderedWithGroup: !1
        }, e.relations = {
            "../avatar-group/avatar-group": {
                type: "ancestor",
                linked: function(e) {
                    var t;
                    this.parent = e, this.setData({
                        size: null !== (t = this.data.size) && void 0 !== t ? t : e.data.size,
                        borderedWithGroup: !0
                    });
                }
            }
        }, e.observers = {
            icon: function(e) {
                var t = (0, u.setIcon)("icon", e, "");
                this.setData(Object.assign({}, t));
            }
        }, e.methods = {
            hide: function() {
                this.setData({
                    isShow: !1
                });
            },
            updateCascading: function(e) {
                this.setData({
                    zIndex: e
                });
            },
            onLoadError: function(e) {
                this.properties.hideOnLoadFailed && this.setData({
                    isShow: !1
                }), this.triggerEvent("error", e.detail);
            }
        }, e;
    }
    return o(n, r), e(n);
}(a.SuperComponent);

b = p([ (0, a.wxComponent)() ], b);

exports.default = b;