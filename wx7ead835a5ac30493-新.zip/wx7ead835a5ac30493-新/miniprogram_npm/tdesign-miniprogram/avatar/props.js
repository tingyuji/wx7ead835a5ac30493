Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    alt: {
        type: String,
        value: ""
    },
    badgeProps: {
        type: Object
    },
    bordered: {
        type: Boolean,
        value: !1
    },
    externalClasses: {
        type: Array
    },
    hideOnLoadFailed: {
        type: Boolean,
        value: !1
    },
    icon: {
        type: null
    },
    image: {
        type: String,
        value: ""
    },
    imageProps: {
        type: Object
    },
    shape: {
        type: String,
        value: "circle"
    },
    size: {
        type: String,
        value: "medium"
    }
};

exports.default = e;