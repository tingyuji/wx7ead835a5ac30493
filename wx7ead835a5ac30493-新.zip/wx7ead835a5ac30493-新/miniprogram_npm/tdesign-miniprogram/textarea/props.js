Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    adjustPosition: {
        type: Boolean,
        value: !0
    },
    autofocus: {
        type: Boolean,
        value: !1
    },
    autosize: {
        type: null,
        value: !1
    },
    confirmHold: {
        type: Boolean,
        value: !1
    },
    confirmType: {
        type: String,
        value: "return"
    },
    cursorSpacing: {
        type: Number,
        value: 0
    },
    disabled: {
        type: Boolean,
        value: !1
    },
    externalClasses: {
        type: Array
    },
    focus: {
        type: Boolean,
        value: !1
    },
    label: {
        type: String
    },
    fixed: {
        type: Boolean,
        value: !1
    },
    maxcharacter: {
        type: Number
    },
    maxlength: {
        type: Number,
        value: -1
    },
    placeholder: {
        type: String,
        value: void 0
    },
    placeholderStyle: {
        type: String,
        value: ""
    },
    value: {
        type: String,
        value: null
    },
    defaultValue: {
        type: String,
        value: ""
    },
    bordered: {
        type: Boolean,
        value: !1
    },
    indicator: {
        type: Boolean,
        value: !1
    },
    cursor: {
        type: Number,
        value: -1
    },
    showConfirmBar: {
        type: Boolean,
        value: !0
    },
    selectionStart: {
        type: Number,
        value: -1
    },
    selectionEnd: {
        type: Number,
        value: -1
    },
    disableDefaultPadding: {
        type: Boolean,
        value: !1
    },
    holdKeyboard: {
        type: Boolean,
        value: !1
    }
};

exports.default = e;