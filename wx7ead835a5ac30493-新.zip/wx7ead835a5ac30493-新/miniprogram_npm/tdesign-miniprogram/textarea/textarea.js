Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), a = require("../../../@babel/runtime/helpers/inherits"), u = require("../../../@babel/runtime/helpers/typeof"), i = require("../common/src/index"), c = s(require("../common/config")), o = s(require("./props")), l = require("../common/utils");

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, a) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, a || [], n(e).constructor) : t.apply(e, a));
}

var h = function(e, t, r, n) {
    var a, i = arguments.length, c = i < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : u(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, r, n); else for (var o = e.length - 1; o >= 0; o--) (a = e[o]) && (c = (i < 3 ? a(c) : i > 3 ? a(t, r, c) : a(t, r)) || c);
    return i > 3 && c && Object.defineProperty(t, r, c), c;
}, p = c.default.prefix, g = "".concat(p, "-textarea"), d = function(r) {
    function n() {
        var e;
        return t(this, n), (e = f(this, n, arguments)).options = {
            multipleSlots: !0
        }, e.behaviors = [ "wx://form-field" ], e.externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-textarea"), "".concat(p, "-class-label"), "".concat(p, "-class-indicator") ], 
        e.properties = o.default, e.data = {
            prefix: p,
            classPrefix: g,
            count: 0
        }, e.observers = {
            value: function(e) {
                this.updateCount(e);
            }
        }, e.lifetimes = {
            ready: function() {
                var e = this.properties.value;
                this.updateValue(null == e ? "" : e);
            }
        }, e.methods = {
            updateCount: function(e) {
                var t = this.properties, r = t.maxcharacter, n = t.maxlength, a = this.calculateValue(e, r, n).count;
                this.setData({
                    count: a
                });
            },
            updateValue: function(e) {
                var t = this.properties, r = t.maxcharacter, n = t.maxlength, a = this.calculateValue(e, r, n), u = a.value, i = a.count;
                this.setData({
                    value: u,
                    count: i
                });
            },
            calculateValue: function(e, t, r) {
                if (t > 0 && !Number.isNaN(t)) {
                    var n = (0, l.getCharacterLength)("maxcharacter", e, t), a = n.length;
                    return {
                        value: n.characters,
                        count: a
                    };
                }
                if (r > 0 && !Number.isNaN(r)) {
                    var u = (0, l.getCharacterLength)("maxlength", e, r), i = u.length;
                    return {
                        value: u.characters,
                        count: i
                    };
                }
                return {
                    value: e,
                    count: e ? String(e).length : 0
                };
            },
            onInput: function(e) {
                var t = e.detail.value;
                this.updateValue(t), this.triggerEvent("change", {
                    value: this.data.value
                });
            },
            onFocus: function(e) {
                this.triggerEvent("focus", Object.assign({}, e.detail));
            },
            onBlur: function(e) {
                this.triggerEvent("blur", Object.assign({}, e.detail));
            },
            onConfirm: function(e) {
                this.triggerEvent("enter", Object.assign({}, e.detail));
            },
            onLineChange: function(e) {
                this.triggerEvent("line-change", Object.assign({}, e.detail));
            },
            onKeyboardHeightChange: function(e) {
                this.triggerEvent("keyboardheightchange", e.detail);
            }
        }, e;
    }
    return a(n, r), e(n);
}(i.SuperComponent);

d = h([ (0, i.wxComponent)() ], d);

exports.default = d;