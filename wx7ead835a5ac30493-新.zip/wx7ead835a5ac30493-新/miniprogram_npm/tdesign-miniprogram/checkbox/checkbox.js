Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), a = require("../../../@babel/runtime/helpers/getPrototypeOf"), c = require("../../../@babel/runtime/helpers/inherits"), n = require("../../../@babel/runtime/helpers/typeof"), s = require("../common/src/index"), l = i(require("../common/config")), o = i(require("./props"));

function i(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function u(e, t, c) {
    return t = a(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, c || [], a(e).constructor) : t.apply(e, c));
}

var d = function(e, t, r, a) {
    var c, s = arguments.length, l = s < 3 ? t : null === a ? a = Object.getOwnPropertyDescriptor(t, r) : a;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : n(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(e, t, r, a); else for (var o = e.length - 1; o >= 0; o--) (c = e[o]) && (l = (s < 3 ? c(l) : s > 3 ? c(t, r, l) : c(t, r)) || l);
    return s > 3 && l && Object.defineProperty(t, r, l), l;
}, f = l.default.prefix, h = "".concat(f, "-checkbox"), p = function(r) {
    function a() {
        var e;
        return t(this, a), (e = u(this, a, arguments)).externalClasses = [ "".concat(f, "-class"), "".concat(f, "-class-label"), "".concat(f, "-class-icon"), "".concat(f, "-class-content"), "".concat(f, "-class-border") ], 
        e.behaviors = [ "wx://form-field" ], e.relations = {
            "../checkbox-group/checkbox-group": {
                type: "ancestor",
                linked: function(e) {
                    var t = e.data, r = t.value, a = t.disabled, c = t.borderless, n = new Set(r), s = n.has(this.data.value), l = {
                        disabled: null == this.data.disabled ? a : this.data.disabled
                    };
                    c && (l.borderless = !0), l.checked = this.data.checked || s, this.data.checked && e.updateValue(this.data), 
                    this.data.checkAll && (l.checked = n.size > 0), this.setData(l);
                }
            }
        }, e.options = {
            multipleSlots: !0
        }, e.properties = Object.assign(Object.assign({}, o.default), {
            theme: {
                type: String,
                value: "default"
            }
        }), e.data = {
            prefix: f,
            classPrefix: h
        }, e.controlledProps = [ {
            key: "checked",
            event: "change"
        } ], e.methods = {
            handleTap: function(e) {
                var t = this.data, r = t.disabled, a = t.readonly;
                if (!r && !a) {
                    var c = e.currentTarget.dataset.target, n = this.data.contentDisabled;
                    if ("text" !== c || !n) {
                        var s = this.data, l = s.value, o = s.label, i = !this.data.checked, u = this.$parent;
                        u ? u.updateValue(Object.assign(Object.assign({}, this.data), {
                            checked: i
                        })) : this._trigger("change", {
                            context: {
                                value: l,
                                label: o
                            },
                            checked: i
                        });
                    }
                }
            }
        }, e;
    }
    return c(a, r), e(a);
}(s.SuperComponent);

p = d([ (0, s.wxComponent)() ], p);

exports.default = p;