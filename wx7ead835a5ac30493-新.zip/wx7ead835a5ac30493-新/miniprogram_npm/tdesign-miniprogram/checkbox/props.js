Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    block: {
        type: Boolean,
        value: !0
    },
    borderless: {
        type: Boolean,
        value: !1
    },
    checkAll: {
        type: Boolean,
        value: !1
    },
    checked: {
        type: Boolean,
        value: null
    },
    defaultChecked: {
        type: Boolean,
        value: !1
    },
    content: {
        type: String
    },
    contentDisabled: {
        type: Boolean
    },
    disabled: {
        type: null,
        value: void 0
    },
    externalClasses: {
        type: Array
    },
    icon: {
        type: null,
        value: "circle"
    },
    indeterminate: {
        type: Boolean,
        value: !1
    },
    label: {
        type: String
    },
    maxContentRow: {
        type: Number,
        value: 5
    },
    maxLabelRow: {
        type: Number,
        value: 3
    },
    name: {
        type: String,
        value: ""
    },
    placement: {
        type: String,
        value: "left"
    },
    readonly: {
        type: Boolean,
        value: !1
    },
    value: {
        type: null
    }
};

exports.default = e;