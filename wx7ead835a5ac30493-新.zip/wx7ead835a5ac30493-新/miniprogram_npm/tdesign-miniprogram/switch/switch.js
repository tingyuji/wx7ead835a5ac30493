Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/slicedToArray"), t = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), o = require("../../../@babel/runtime/helpers/getPrototypeOf"), l = require("../../../@babel/runtime/helpers/inherits"), c = require("../../../@babel/runtime/helpers/typeof"), u = require("../common/src/index"), a = s(require("../common/config")), i = s(require("./props"));

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, r) {
    return t = o(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, r || [], o(e).constructor) : t.apply(e, r));
}

var p = function(e, t, r, n) {
    var o, l = arguments.length, u = l < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : c(Reflect)) && "function" == typeof Reflect.decorate) u = Reflect.decorate(e, t, r, n); else for (var a = e.length - 1; a >= 0; a--) (o = e[a]) && (u = (l < 3 ? o(u) : l > 3 ? o(t, r, u) : o(t, r)) || u);
    return l > 3 && u && Object.defineProperty(t, r, u), u;
}, d = a.default.prefix, h = "".concat(d, "-switch"), b = function(n) {
    function o() {
        var t;
        return r(this, o), (t = f(this, o, arguments)).externalClasses = [ "t-class", "t-class-label", "t-class-body", "t-class-dot" ], 
        t.behaviors = [ "wx://form-field" ], t.properties = i.default, t.data = {
            prefix: d,
            classPrefix: h,
            checked: !1
        }, t.controlledProps = [ {
            key: "value",
            event: "change"
        } ], t.observers = {
            value: function(t) {
                var r = e(this.data.customValue, 1)[0];
                this.setData({
                    checked: t === r
                });
            }
        }, t.methods = {
            handleSwitch: function() {
                var t = this.data, r = t.loading, n = t.disabled, o = t.value, l = t.customValue, c = e(l, 2), u = c[0], a = c[1];
                r || n || this._trigger("change", {
                    value: o === u ? a : u
                });
            }
        }, t;
    }
    return l(o, n), t(o);
}(u.SuperComponent);

b = p([ (0, u.wxComponent)() ], b);

exports.default = b;