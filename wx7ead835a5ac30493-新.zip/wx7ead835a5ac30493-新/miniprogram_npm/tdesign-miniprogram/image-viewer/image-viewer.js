Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/defineProperty"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/createClass"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), i = require("../../../@babel/runtime/helpers/getPrototypeOf"), s = require("../../../@babel/runtime/helpers/inherits"), o = require("../../../@babel/runtime/helpers/typeof"), a = require("../common/utils"), c = require("../common/src/index"), l = d(require("../common/config")), u = d(require("./props"));

function d(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function h(e, t, r) {
    return t = i(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, r || [], i(e).constructor) : t.apply(e, r));
}

var f = function(e, t, r, n) {
    var i, s = arguments.length, a = s < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : o(Reflect)) && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, n); else for (var c = e.length - 1; c >= 0; c--) (i = e[c]) && (a = (s < 3 ? i(a) : s > 3 ? i(t, r, a) : i(t, r)) || a);
    return s > 3 && a && Object.defineProperty(t, r, a), a;
}, p = l.default.prefix, g = "".concat(p, "-image-viewer"), w = function(n) {
    function i() {
        var r;
        return t(this, i), (r = h(this, i, arguments)).externalClasses = [ "".concat(p, "-class") ], 
        r.properties = Object.assign({}, u.default), r.data = {
            prefix: p,
            classPrefix: g,
            currentSwiperIndex: 0,
            windowHeight: 0,
            windowWidth: 0,
            swiperStyle: {},
            imagesStyle: {},
            maskTop: 0
        }, r.options = {
            multipleSlots: !0
        }, r.controlledProps = [ {
            key: "visible",
            event: "close"
        } ], r.observers = {
            visible: function(e) {
                this.setData({
                    currentSwiperIndex: e ? this.properties.initialIndex : 0
                });
            },
            closeBtn: function(e) {
                this.setData({
                    _closeBtn: (0, a.calcIcon)(e, "close")
                });
            },
            deleteBtn: function(e) {
                this.setData({
                    _deleteBtn: (0, a.calcIcon)(e, "delete")
                });
            }
        }, r.methods = {
            calcMaskTop: function() {
                if (this.data.usingCustomNavbar) {
                    var e = (null === wx || void 0 === wx ? void 0 : wx.getMenuButtonBoundingClientRect()) || null, t = wx.getSystemInfoSync().statusBarHeight;
                    e && t && this.setData({
                        maskTop: e.top - t + e.bottom
                    });
                }
            },
            saveScreenSize: function() {
                var e = wx.getSystemInfoSync(), t = e.windowHeight, r = e.windowWidth;
                this.setData({
                    windowHeight: t,
                    windowWidth: r
                });
            },
            calcImageDisplayStyle: function(e, t) {
                var r = this.data, n = r.windowWidth, i = r.windowHeight, s = e / t;
                return e < n && t < i ? {
                    styleObj: {
                        width: "".concat(2 * e, "rpx"),
                        height: "".concat(2 * t, "rpx"),
                        left: "50%",
                        transform: "translate(-50%, -50%)"
                    }
                } : s >= 1 ? {
                    styleObj: {
                        width: "100vw",
                        height: "".concat(n / s * 2, "rpx")
                    }
                } : {
                    styleObj: {
                        width: "".concat(s * i * 2, "rpx"),
                        height: "100vh",
                        left: "50%",
                        transform: "translate(-50%, -50%)"
                    }
                };
            },
            onImageLoadSuccess: function(t) {
                var r = t.detail, n = r.width, i = r.height, s = t.currentTarget.dataset.index, o = this.calcImageDisplayStyle(n, i), c = o.mode, l = o.styleObj, u = this.data.imagesStyle, d = this.data.swiperStyle;
                this.setData({
                    swiperStyle: Object.assign(Object.assign({}, d), e({}, s, {
                        style: "height: ".concat(l.height)
                    })),
                    imagesStyle: Object.assign(Object.assign({}, u), e({}, s, {
                        mode: c,
                        style: (0, a.styles)(Object.assign({}, l))
                    }))
                });
            },
            onSwiperChange: function(e) {
                var t = e.detail.current;
                this.setData({
                    currentSwiperIndex: t
                }), this._trigger("change", {
                    index: t
                });
            },
            onClose: function(e) {
                var t = e.currentTarget.dataset.source;
                this._trigger("close", {
                    visible: !1,
                    trigger: t || "button",
                    index: this.data.currentSwiperIndex
                });
            },
            onDelete: function() {
                this._trigger("delete", {
                    index: this.data.currentSwiperIndex
                });
            }
        }, r;
    }
    return s(i, n), r(i, [ {
        key: "ready",
        value: function() {
            this.saveScreenSize(), this.calcMaskTop();
        }
    } ]);
}(c.SuperComponent);

w = f([ (0, c.wxComponent)() ], w);

exports.default = w;