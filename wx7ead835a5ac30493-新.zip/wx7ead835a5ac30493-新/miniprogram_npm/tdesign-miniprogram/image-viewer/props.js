Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    backgroundColor: {
        type: String,
        value: "rgba(0, 0, 0, 1)"
    },
    closeBtn: {
        type: null,
        value: !1
    },
    deleteBtn: {
        type: null,
        value: !1
    },
    images: {
        type: Array,
        value: []
    },
    initialIndex: {
        type: Number,
        value: 0
    },
    showIndex: {
        type: Boolean,
        value: !1
    },
    usingCustomNavbar: {
        type: Boolean,
        value: !1
    },
    visible: {
        type: Boolean,
        value: null
    },
    defaultVisible: {
        type: Boolean,
        value: !1
    }
};

exports.default = e;