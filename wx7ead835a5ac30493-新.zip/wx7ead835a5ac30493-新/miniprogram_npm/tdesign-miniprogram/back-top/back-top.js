Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), o = require("../../../@babel/runtime/helpers/getPrototypeOf"), n = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/typeof"), c = require("../common/src/index"), s = a(require("../common/config")), l = a(require("./props")), u = require("../common/utils");

function a(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, n) {
    return t = o(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, n || [], o(e).constructor) : t.apply(e, n));
}

var p = function(e, t, r, o) {
    var n, c = arguments.length, s = c < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : i(Reflect)) && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, o); else for (var l = e.length - 1; l >= 0; l--) (n = e[l]) && (s = (c < 3 ? n(s) : c > 3 ? n(t, r, s) : n(t, r)) || s);
    return c > 3 && s && Object.defineProperty(t, r, s), s;
}, d = s.default.prefix, h = "".concat(d, "-back-top"), b = function(r) {
    function o() {
        var e;
        return t(this, o), (e = f(this, o, arguments)).externalClasses = [ "".concat(d, "-class"), "".concat(d, "-class-icon"), "".concat(d, "-class-text") ], 
        e.options = {
            multipleSlots: !0
        }, e.properties = l.default, e.relations = {
            "../pull-down-refresh/pull-down-refresh": {
                type: "ancestor"
            }
        }, e.data = {
            prefix: d,
            classPrefix: h,
            _icon: null,
            hidden: !0
        }, e.observers = {
            icon: function() {
                this.setIcon();
            },
            scrollTop: function(e) {
                var t = this.properties.visibilityHeight;
                this.setData({
                    hidden: e < t
                });
            }
        }, e.lifetimes = {
            ready: function() {
                var e = this.properties.icon;
                this.setIcon(e);
            }
        }, e.methods = {
            setIcon: function(e) {
                this.setData({
                    _icon: (0, u.calcIcon)(e, "backtop")
                });
            },
            toTop: function() {
                var e;
                this.triggerEvent("to-top"), this.$parent ? (null === (e = this.$parent) || void 0 === e || e.setScrollTop(0), 
                this.setData({
                    hidden: !0
                })) : wx.pageScrollTo({
                    scrollTop: 0,
                    duration: 300
                });
            }
        }, e;
    }
    return n(o, r), e(o);
}(c.SuperComponent);

b = p([ (0, c.wxComponent)() ], b);

exports.default = b;