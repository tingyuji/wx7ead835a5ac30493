Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    badgeProps: {
        type: Object,
        value: null
    },
    destroyOnHide: {
        type: Boolean,
        value: !0
    },
    disabled: {
        type: Boolean,
        value: !1
    },
    icon: {
        type: null
    },
    label: {
        type: String,
        value: ""
    },
    panel: {
        type: String
    },
    value: {
        type: null
    }
};

exports.default = e;