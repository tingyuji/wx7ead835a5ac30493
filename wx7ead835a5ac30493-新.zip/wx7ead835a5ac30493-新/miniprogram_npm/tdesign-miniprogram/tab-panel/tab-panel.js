Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/classCallCheck"), t = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/typeof"), u = require("../common/src/index"), a = l(require("./props"));

function l(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function c(e, t, o) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, o || [], n(e).constructor) : t.apply(e, o));
}

var s = function(e, t, r, n) {
    var o, u = arguments.length, a = u < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : i(Reflect)) && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, n); else for (var l = e.length - 1; l >= 0; l--) (o = e[l]) && (a = (u < 3 ? o(a) : u > 3 ? o(t, r, a) : o(t, r)) || a);
    return u > 3 && a && Object.defineProperty(t, r, a), a;
}, f = l(require("../common/config")).default.prefix, p = "".concat(f, "-tab-panel"), d = function(r) {
    function n() {
        var t;
        return e(this, n), (t = c(this, n, arguments)).externalClasses = [ "".concat(f, "-class") ], 
        t.relations = {
            "../tabs/tabs": {
                type: "ancestor"
            }
        }, t.options = {
            multipleSlots: !0
        }, t.properties = a.default, t.data = {
            prefix: f,
            classPrefix: p,
            active: !1,
            hide: !0,
            id: ""
        }, t.observers = {
            "label, badgeProps, disabled, icon, panel, value": function() {
                this.update();
            }
        }, t;
    }
    return o(n, r), t(n, [ {
        key: "setId",
        value: function(e) {
            this.setData({
                id: e
            });
        }
    }, {
        key: "getComputedName",
        value: function() {
            return null != this.properties.value ? "".concat(this.properties.value) : "".concat(this.index);
        }
    }, {
        key: "update",
        value: function() {
            var e;
            null === (e = this.$parent) || void 0 === e || e.updateTabs();
        }
    }, {
        key: "render",
        value: function(e, t) {
            this.setData({
                active: e,
                hide: !t.data.animation && !e
            });
        }
    } ]);
}(u.SuperComponent);

d = s([ (0, u.wxComponent)() ], d);

exports.default = d;