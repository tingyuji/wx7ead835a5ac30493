Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    animation: {
        type: Boolean,
        value: !0
    },
    delta: {
        type: Number,
        value: 1
    },
    externalClasses: {
        type: Array
    },
    fixed: {
        type: Boolean,
        value: !0
    },
    leftArrow: {
        type: Boolean,
        value: !1
    },
    title: {
        type: String
    },
    titleMaxLength: {
        type: Number
    },
    visible: {
        type: Boolean,
        value: !0
    }
};

exports.default = e;