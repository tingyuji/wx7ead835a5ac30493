Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/classCallCheck"), t = require("../../../@babel/runtime/helpers/createClass"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), r = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), c = require("../../../@babel/runtime/helpers/typeof"), o = require("../common/src/index"), a = l(require("../common/config")), s = l(require("./props"));

function l(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function u(e, t, i) {
    return t = r(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, i || [], r(e).constructor) : t.apply(e, i));
}

var f = function(e, t, n, r) {
    var i, o = arguments.length, a = o < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, n) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : c(Reflect)) && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, n, r); else for (var s = e.length - 1; s >= 0; s--) (i = e[s]) && (a = (o < 3 ? i(a) : o > 3 ? i(t, n, a) : i(t, n)) || a);
    return o > 3 && a && Object.defineProperty(t, n, a), a;
}, p = a.default.prefix, h = "".concat(p, "-navbar"), d = function(n) {
    function r() {
        var t;
        return e(this, r), (t = u(this, r, arguments)).externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-title"), "".concat(p, "-class-left"), "".concat(p, "-class-center"), "".concat(p, "-class-left-icon"), "".concat(p, "-class-home-icon"), "".concat(p, "-class-capsule"), "".concat(p, "-class-nav-btn") ], 
        t.timer = null, t.options = {
            addGlobalClass: !0,
            multipleSlots: !0
        }, t.properties = s.default, t.observers = {
            visible: function(e) {
                var t = this, n = this.properties.animation, r = "".concat(h).concat(e ? "--visible" : "--hide");
                this.setData({
                    visibleClass: "".concat(r).concat(n ? "-animation" : "")
                }), this.timer && clearTimeout(this.timer), n && (this.timer = setTimeout(function() {
                    t.setData({
                        visibleClass: r
                    });
                }, 300));
            },
            "title,titleMaxLength": function() {
                var e = this.properties.title, t = this.properties.titleMaxLength || Number.MAX_SAFE_INTEGER, n = e.slice(0, t);
                t < e.length && (n += "..."), this.setData({
                    showTitle: n
                });
            }
        }, t.data = {
            prefix: p,
            classPrefix: h,
            boxStyle: "",
            showTitle: ""
        }, t.methods = {
            goBack: function() {
                var e = this.data.delta, t = this;
                this.triggerEvent("go-back"), e > 0 && wx.navigateBack({
                    delta: e,
                    fail: function(e) {
                        t.triggerEvent("fail", e);
                    },
                    complete: function(e) {
                        t.triggerEvent("complete", e);
                    },
                    success: function(e) {
                        t.triggerEvent("success", e);
                    }
                });
            }
        }, t;
    }
    return i(r, n), t(r, [ {
        key: "attached",
        value: function() {
            var e = this, t = null;
            wx.getMenuButtonBoundingClientRect && (t = wx.getMenuButtonBoundingClientRect()), 
            t && wx.getSystemInfo({
                success: function(n) {
                    var r = [], i = wx.getSystemInfoSync().statusBarHeight;
                    r.push("--td-navbar-padding-top:".concat(i, "px")), t && (null == n ? void 0 : n.windowWidth) && r.push("--td-navbar-right:".concat(n.windowWidth - t.left, "px")), 
                    r.push("--td-navbar-capsule-height: ".concat(t.height, "px")), r.push("--td-navbar-capsule-width: ".concat(t.width, "px")), 
                    r.push("--td-navbar-height: ".concat(2 * (t.top - i) + t.height, "px")), e.setData({
                        boxStyle: "".concat(r.join("; "))
                    });
                },
                fail: function(e) {
                    console.error("navbar 获取系统信息失败", e);
                }
            });
        }
    } ]);
}(o.SuperComponent);

d = f([ (0, o.wxComponent)() ], d);

exports.default = d;