Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), u = require("../../../@babel/runtime/helpers/typeof"), i = require("../common/src/index"), c = s(require("../common/config")), l = s(require("./props"));

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, o) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, o || [], n(e).constructor) : t.apply(e, o));
}

var a = function(e, t, r, n) {
    var o, i = arguments.length, c = i < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : u(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, r, n); else for (var l = e.length - 1; l >= 0; l--) (o = e[l]) && (c = (i < 3 ? o(c) : i > 3 ? o(t, r, c) : o(t, r)) || c);
    return i > 3 && c && Object.defineProperty(t, r, c), c;
}, p = c.default.prefix, d = function(r) {
    function n() {
        var e;
        return t(this, n), (e = f(this, n, arguments)).externalClasses = [], e.properties = l.default, 
        e.data = {
            prefix: p
        }, e.relations = {
            "../col/col": {
                type: "child",
                linked: function(e) {
                    var t = this.data.gutter;
                    t && e.setData({
                        gutter: t
                    });
                }
            }
        }, e.observers = {
            gutter: function() {
                this.setGutter();
            }
        }, e.methods = {
            setGutter: function() {
                var e = this.data.gutter;
                this.$children.forEach(function(t) {
                    t.setData({
                        gutter: e
                    });
                });
            }
        }, e;
    }
    return o(n, r), e(n);
}(i.SuperComponent);

d = a([ (0, i.wxComponent)() ], d);

exports.default = d;