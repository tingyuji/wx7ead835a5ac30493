Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), i = require("../../../@babel/runtime/helpers/getPrototypeOf"), n = require("../../../@babel/runtime/helpers/inherits"), a = require("../../../@babel/runtime/helpers/typeof"), o = require("../common/src/index"), s = c(require("../common/config")), l = c(require("./props")), h = require("../common/utils");

function c(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function u(e, t, n) {
    return t = i(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, n || [], i(e).constructor) : t.apply(e, n));
}

var f = function(e, t, r, i) {
    var n, o = arguments.length, s = o < 3 ? t : null === i ? i = Object.getOwnPropertyDescriptor(t, r) : i;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : a(Reflect)) && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, i); else for (var l = e.length - 1; l >= 0; l--) (n = e[l]) && (s = (o < 3 ? n(s) : o > 3 ? n(t, r, s) : n(t, r)) || s);
    return o > 3 && s && Object.defineProperty(t, r, s), s;
}, g = s.default.prefix, p = "".concat(g, "-pull-down-refresh"), d = function(r) {
    function i() {
        var e;
        return t(this, i), (e = u(this, i, arguments)).pixelRatio = 1, e.startPoint = null, 
        e.isPulling = !1, e.loadingBarHeight = 100, e.maxRefreshAnimateTimeFlag = 0, e.closingAnimateTimeFlag = 0, 
        e.externalClasses = [ "".concat(g, "-class"), "".concat(g, "-class-loading"), "".concat(g, "-class-text"), "".concat(g, "-class-indicator") ], 
        e.options = {
            multipleSlots: !0
        }, e.relations = {
            "../back-top/back-top": {
                type: "descendant"
            }
        }, e.properties = l.default, e.data = {
            prefix: g,
            classPrefix: p,
            barHeight: 0,
            refreshStatus: -1,
            loosing: !1,
            enableToRefresh: !0,
            scrollTop: 0
        }, e.lifetimes = {
            attached: function() {
                var e = wx.getSystemInfoSync().screenWidth, t = this.properties, r = t.loadingBarHeight, i = t.loadingTexts;
                this.setData({
                    loadingTexts: Array.isArray(i) && i.length >= 4 ? i : [ "下拉刷新", "松手刷新", "正在刷新", "刷新完成" ]
                }), this.pixelRatio = 750 / e, Object.defineProperty(this, "maxBarHeight", {
                    get: function() {
                        return (0, h.unitConvert)(this.data.maxBarHeight);
                    }
                }), Object.defineProperty(this, "loadingBarHeight", {
                    get: function() {
                        return (0, h.unitConvert)(this.data.loadingBarHeight);
                    }
                }), r && this.setData({
                    computedLoadingBarHeight: (0, h.unitConvert)(r)
                });
            },
            detached: function() {
                clearTimeout(this.maxRefreshAnimateTimeFlag), clearTimeout(this.closingAnimateTimeFlag);
            }
        }, e.observers = {
            value: function(e) {
                e ? this.doRefresh() : (clearTimeout(this.maxRefreshAnimateTimeFlag), this.data.refreshStatus > 0 && this.setData({
                    refreshStatus: 3
                }), this.setData({
                    barHeight: 0
                }));
            }
        }, e.methods = {
            onScrollToBottom: function() {
                this.triggerEvent("scrolltolower");
            },
            onScrollToTop: function() {
                this.setData({
                    enableToRefresh: !0
                });
            },
            onScroll: function(e) {
                var t = e.detail.scrollTop;
                this.setData({
                    enableToRefresh: 0 === t
                }), this.triggerEvent("scroll", {
                    scrollTop: t
                });
            },
            onTouchStart: function(e) {
                if (!this.isPulling && this.data.enableToRefresh) {
                    var t = e.touches;
                    if (1 === t.length) {
                        var r = t[0], i = r.pageX, n = r.pageY;
                        this.setData({
                            loosing: !1
                        }), this.startPoint = {
                            pageX: i,
                            pageY: n
                        }, this.isPulling = !0;
                    }
                }
            },
            onTouchMove: function(e) {
                if (this.startPoint) {
                    var t = e.touches;
                    if (1 === t.length) {
                        var r = t[0].pageY - this.startPoint.pageY;
                        r > 0 && this.setRefreshBarHeight(r);
                    }
                }
            },
            onTouchEnd: function(e) {
                if (this.startPoint) {
                    var t = e.changedTouches;
                    if (1 === t.length) {
                        var r = t[0].pageY - this.startPoint.pageY;
                        this.startPoint = null, this.isPulling = !1, this.setData({
                            loosing: !0
                        }), r > this.loadingBarHeight ? (this._trigger("change", {
                            value: !0
                        }), this.triggerEvent("refresh")) : this.setData({
                            barHeight: 0
                        });
                    }
                }
            },
            doRefresh: function() {
                var e = this;
                this.setData({
                    barHeight: this.loadingBarHeight,
                    refreshStatus: 2,
                    loosing: !0
                }), this.maxRefreshAnimateTimeFlag = setTimeout(function() {
                    e.maxRefreshAnimateTimeFlag = null, 2 === e.data.refreshStatus && (e.triggerEvent("timeout"), 
                    e._trigger("change", {
                        value: !1
                    }));
                }, this.properties.refreshTimeout);
            },
            setRefreshBarHeight: function(e) {
                var t = this, r = Math.min(e, this.maxBarHeight), i = {
                    barHeight: r
                };
                return r >= this.loadingBarHeight ? i.refreshStatus = 1 : i.refreshStatus = 0, new Promise(function(e) {
                    t.setData(i, function() {
                        return e(r);
                    });
                });
            },
            setScrollTop: function(e) {
                this.setData({
                    scrollTop: e
                });
            },
            scrollToTop: function() {
                this.setScrollTop(0);
            }
        }, e;
    }
    return n(i, r), e(i);
}(o.SuperComponent);

d = f([ (0, o.wxComponent)() ], d);

exports.default = d;