Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    enableBackToTop: {
        type: Boolean,
        value: !0
    },
    enablePassive: {
        type: Boolean,
        value: !1
    },
    externalClasses: {
        type: Array
    },
    loadingBarHeight: {
        type: null,
        value: 50
    },
    loadingProps: {
        type: Object
    },
    loadingTexts: {
        type: Array,
        value: []
    },
    lowerThreshold: {
        type: null,
        value: 50
    },
    maxBarHeight: {
        type: null,
        value: 80
    },
    refreshTimeout: {
        type: Number,
        value: 3e3
    },
    scrollIntoView: {
        type: String,
        value: ""
    },
    showScrollbar: {
        type: Boolean,
        value: !0
    },
    upperThreshold: {
        type: null,
        value: 50
    },
    value: {
        type: Boolean,
        value: null
    },
    defaultValue: {
        type: Boolean,
        value: !1
    }
};

exports.default = e;