Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/toConsumableArray"), t = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/createClass"), a = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), o = require("../../../@babel/runtime/helpers/getPrototypeOf"), r = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/typeof"), u = h(require("dayjs")), l = h(require("dayjs/plugin/localeData")), s = h(require("../common/config")), c = require("../common/src/index"), d = h(require("./props")), f = h(require("./locale/dayjs"));

function h(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function g(e, t, n) {
    return t = o(t), a(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, n || [], o(e).constructor) : t.apply(e, n));
}

var m, v, p = function(e, t, n, a) {
    var o, r = arguments.length, u = r < 3 ? t : null === a ? a = Object.getOwnPropertyDescriptor(t, n) : a;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : i(Reflect)) && "function" == typeof Reflect.decorate) u = Reflect.decorate(e, t, n, a); else for (var l = e.length - 1; l >= 0; l--) (o = e[l]) && (u = (r < 3 ? o(u) : r > 3 ? o(t, n, u) : o(t, n)) || u);
    return r > 3 && u && Object.defineProperty(t, n, u), u;
};

u.default.extend(l.default), u.default.locale("zh-cn");

var y, M = (null === (m = f.default[u.default.locale()]) || void 0 === m ? void 0 : m.key) || (null === (v = f.default.default) || void 0 === v ? void 0 : v.key), D = s.default.prefix, O = "".concat(D, "-date-time-picker");

!function(e) {
    e.YEAR = "year", e.MONTH = "month", e.DATE = "date", e.HOUR = "hour", e.MINUTE = "minute", 
    e.SECOND = "second";
}(y || (y = {}));

var b = [ "year", "month", "date" ], C = [ "hour", "minute", "second" ], E = [].concat(b, C), x = (0, 
u.default)("2000-01-01 00:00:00"), R = (0, u.default)("2030-12-31 23:59:59"), k = function(a) {
    function o() {
        var e;
        return t(this, o), (e = g(this, o, arguments)).properties = d.default, e.externalClasses = [ "".concat(D, "-class"), "".concat(D, "-class-confirm"), "".concat(D, "-class-cancel"), "".concat(D, "-class-title") ], 
        e.options = {
            multipleSlots: !0
        }, e.observers = {
            "start, end, value": function() {
                this.updateColumns();
            },
            customLocale: function(e) {
                e && f.default[e].key && this.setData({
                    locale: f.default[e].i18n,
                    dayjsLocale: f.default[e].key
                });
            },
            mode: function(e) {
                var t = this.getFullModeArray(e);
                this.setData({
                    fullModes: t
                }), this.updateColumns();
            }
        }, e.date = null, e.data = {
            prefix: D,
            classPrefix: O,
            columns: [],
            columnsValue: [],
            fullModes: [],
            locale: f.default[M].i18n,
            dayjsLocale: f.default[M].key
        }, e.controlledProps = [ {
            key: "value",
            event: "change"
        } ], e.methods = {
            updateColumns: function() {
                this.date = this.getParseDate();
                var e = this.getValueCols(), t = e.columns, n = e.columnsValue;
                this.setData({
                    columns: t,
                    columnsValue: n
                });
            },
            getParseDate: function() {
                var e = this.properties, t = e.value, n = e.defaultValue, a = this.getMinDate(), o = t || n;
                if (this.isTimeMode()) {
                    var r = (0, u.default)(a).format("YYYY-MM-DD");
                    o = (0, u.default)("".concat(r, " ").concat(o));
                }
                var i = (0, u.default)(o || a);
                return i.isValid() ? i : a;
            },
            getMinDate: function() {
                var e = this.properties.start;
                return e ? (0, u.default)(e) : x;
            },
            getMaxDate: function() {
                var e = this.properties.end;
                return e ? (0, u.default)(e) : R;
            },
            getDateRect: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "default", t = {
                    min: "getMinDate",
                    max: "getMaxDate",
                    default: "getDate"
                }, n = this[t[e]](), a = [ "year", "month", "date", "hour", "minute", "second" ];
                return a.map(function(e) {
                    var t;
                    return null === (t = n[e]) || void 0 === t ? void 0 : t.call(n);
                });
            },
            getDate: function() {
                return this.clipDate((null == this ? void 0 : this.date) || x);
            },
            clipDate: function(e) {
                var t = this.getMinDate(), n = this.getMaxDate();
                return (0, u.default)(Math.min(Math.max(t.valueOf(), e.valueOf()), n.valueOf()));
            },
            setYear: function(e, t) {
                var n = e.date(), a = e.year(t).daysInMonth();
                return e.date(Math.min(n.valueOf(), a.valueOf())).year(t);
            },
            setMonth: function(e, t) {
                var n = e.date(), a = e.month(t).daysInMonth();
                return e.date(Math.min(n.valueOf(), a.valueOf())).month(t);
            },
            getColumnOptions: function() {
                var e = this, t = this.data.fullModes, n = [];
                return null == t || t.forEach(function(t) {
                    var a = e.getOptionByType(t);
                    n.push(a);
                }), n;
            },
            getOptionByType: function(e) {
                for (var t, n = this.data, a = n.locale, o = n.steps, r = [], i = this.getOptionEdge("min", e), l = this.getOptionEdge("max", e), s = null !== (t = null == o ? void 0 : o[e]) && void 0 !== t ? t : 1, c = (0, 
                u.default)().locale(this.data.dayjsLocale).localeData().monthsShort(), d = i; d <= l; d += s) r.push({
                    value: "".concat(d),
                    label: "month" === e ? c[d] : "".concat(d + a[e])
                });
                return r;
            },
            getYearOptions: function(e) {
                for (var t = this.data.locale, n = e.minDateYear, a = e.maxDateYear, o = [], r = n; r <= a; r += 1) o.push({
                    value: "".concat(r),
                    label: "".concat(r + t.year)
                });
                return o;
            },
            getOptionEdge: function(e, t) {
                for (var n = this.getDateRect(), a = this.getDateRect(e), o = {
                    month: [ 0, 11 ],
                    date: [ 1, this.getDate().daysInMonth() ],
                    hour: [ 0, 23 ],
                    minute: [ 0, 59 ],
                    second: [ 0, 59 ]
                }, r = [ "year", "month", "date", "hour", "minute", "second" ], i = 0, u = n.length; i < u; i += 1) {
                    if (r[i] === t) return a[i];
                    if (a[i] !== n[i]) return o[t]["min" === e ? 0 : 1];
                }
                return o[t]["min" === e ? 0 : 1];
            },
            getMonthOptions: function() {
                for (var e = [], t = this.getOptionEdge("min", "month"), n = this.getOptionEdge("max", "month"), a = u.default.monthsShort(), o = t; o <= n; o += 1) e.push({
                    value: "".concat(o),
                    label: a[o]
                });
                return e;
            },
            getDayOptions: function() {
                for (var e = this.data.locale, t = [], n = this.getOptionEdge("min", "date"), a = this.getOptionEdge("max", "date"), o = n; o <= a; o += 1) t.push({
                    value: "".concat(o),
                    label: "".concat(o + e.day)
                });
                return t;
            },
            getHourOptions: function() {
                for (var e = this.data.locale, t = [], n = this.getOptionEdge("min", "hour"), a = this.getOptionEdge("max", "hour"), o = n; o <= a; o += 1) t.push({
                    value: "".concat(o),
                    label: "".concat(o + e.hour)
                });
                return t;
            },
            getMinuteOptions: function() {
                for (var e = this.data.locale, t = [], n = this.getOptionEdge("min", "minute"), a = this.getOptionEdge("max", "minute"), o = n; o <= a; o += 1) t.push({
                    value: "".concat(o),
                    label: "".concat(o + e.minute)
                });
                return t;
            },
            getValueCols: function() {
                return {
                    columns: this.getColumnOptions(),
                    columnsValue: this.getColumnsValue()
                };
            },
            getColumnsValue: function() {
                var e = this.data.fullModes, t = this.getDate(), n = [];
                return null == e || e.forEach(function(e) {
                    n.push("".concat(t[e]()));
                }), n;
            },
            getNewDate: function(e, t) {
                var n = this.getDate();
                switch (t) {
                  case y.YEAR:
                    n = this.setYear(n, e);
                    break;

                  case y.MONTH:
                    n = this.setMonth(n, e);
                    break;

                  case y.DATE:
                    n = n.date(e);
                    break;

                  case y.HOUR:
                    n = n.hour(e);
                    break;

                  case y.MINUTE:
                    n = n.minute(e);
                    break;

                  case y.SECOND:
                    n = n.second(e);
                }
                return this.clipDate(n);
            },
            onColumnChange: function(e) {
                var t = null == e ? void 0 : e.detail, n = t.value, a = t.column, o = this.data, r = o.fullModes, i = o.format, u = null == n ? void 0 : n[a], l = null == r ? void 0 : r[a], s = this.getNewDate(parseInt(u, 10), l);
                this.date = s;
                var c = this.getValueCols(), d = c.columns, f = c.columnsValue;
                this.setData({
                    columns: d,
                    columnsValue: f
                });
                var h = this.getDate(), g = i ? h.format(i) : h.valueOf();
                this.triggerEvent("pick", {
                    value: g
                });
            },
            onConfirm: function() {
                var e = this.properties.format, t = this.getDate(), n = e ? t.format(e) : t.valueOf();
                this._trigger("change", {
                    value: n
                }), this.triggerEvent("confirm", {
                    value: n
                }), this.resetColumns();
            },
            onCancel: function() {
                this.resetColumns(), this.triggerEvent("cancel");
            },
            onVisibleChange: function(e) {
                e.detail.visible || this.resetColumns();
            },
            onClose: function(e) {
                var t = e.detail.trigger;
                this.triggerEvent("close", {
                    trigger: t
                });
            },
            resetColumns: function() {
                var e = this.getParseDate();
                this.date = e;
                var t = this.getValueCols(), n = t.columns, a = t.columnsValue;
                this.setData({
                    columns: n,
                    columnsValue: a
                });
            }
        }, e;
    }
    return r(o, a), n(o, [ {
        key: "getFullModeArray",
        value: function(t) {
            if ("string" == typeof t || t instanceof String) return this.getFullModeByModeString(t, E);
            if (Array.isArray(t)) {
                if (1 === (null == t ? void 0 : t.length)) return this.getFullModeByModeString(t[0], E);
                if (2 === (null == t ? void 0 : t.length)) {
                    var n = this.getFullModeByModeString(t[0], b), a = this.getFullModeByModeString(t[1], C);
                    return [].concat(e(n), e(a));
                }
            }
        }
    }, {
        key: "getFullModeByModeString",
        value: function(e, t) {
            if (!e) return [];
            var n = null == t ? void 0 : t.findIndex(function(t) {
                return e === t;
            });
            return null == t ? void 0 : t.slice(0, n + 1);
        }
    }, {
        key: "isTimeMode",
        value: function() {
            return this.data.fullModes[0] === y.HOUR;
        }
    } ]);
}(c.SuperComponent);

k = p([ (0, c.wxComponent)() ], k);

exports.default = k;