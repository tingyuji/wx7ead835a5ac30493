Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    year: "年",
    month: "月",
    date: "日",
    hour: "時",
    minute: "分",
    second: "秒",
    am: "上午",
    pm: "下午",
    confirm: "確定",
    cancel: "取消"
};