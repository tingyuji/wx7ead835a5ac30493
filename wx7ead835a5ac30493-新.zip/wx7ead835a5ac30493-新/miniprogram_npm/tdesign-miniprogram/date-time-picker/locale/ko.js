Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    year: "년",
    month: "월",
    date: "일",
    hour: "시",
    minute: "분",
    second: "초",
    am: "오전",
    pm: "오후",
    confirm: "확인",
    cancel: "취소"
};