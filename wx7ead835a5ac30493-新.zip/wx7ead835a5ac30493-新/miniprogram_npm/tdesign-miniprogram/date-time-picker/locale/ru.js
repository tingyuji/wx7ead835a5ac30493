Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    year: "",
    month: "",
    date: "",
    hour: "",
    minute: "",
    second: "",
    am: "до полудня",
    pm: "после полудня",
    confirm: "подтвердить",
    cancel: "отменить"
};