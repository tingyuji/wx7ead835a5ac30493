Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    cancelBtn: {
        type: String,
        value: ""
    },
    confirmBtn: {
        type: String,
        value: ""
    },
    end: {
        type: null
    },
    externalClasses: {
        type: Array
    },
    format: {
        type: String,
        value: "YYYY-MM-DD HH:mm:ss"
    },
    header: {
        type: Boolean,
        value: !0
    },
    mode: {
        type: null,
        value: "date"
    },
    showWeek: {
        type: Boolean,
        value: !1
    },
    start: {
        type: null
    },
    steps: {
        type: Object
    },
    title: {
        type: String,
        value: ""
    },
    value: {
        type: null,
        value: null
    },
    defaultValue: {
        type: null
    },
    visible: {
        type: Boolean,
        value: !1
    },
    popupProps: {
        type: Object,
        value: {}
    },
    customLocale: {
        type: String,
        value: "zh"
    }
};

exports.default = e;