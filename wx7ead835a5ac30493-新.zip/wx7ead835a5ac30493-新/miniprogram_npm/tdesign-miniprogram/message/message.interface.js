var e;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.MessageType = void 0, function(e) {
    e.info = "info", e.success = "success", e.warning = "warning", e.error = "error";
}(e || (exports.MessageType = e = {}));