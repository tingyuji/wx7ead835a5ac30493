Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../../@babel/runtime/helpers/slicedToArray"), e = require("../../../@babel/runtime/helpers/classCallCheck"), i = require("../../../@babel/runtime/helpers/createClass"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), a = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), s = require("../../../@babel/runtime/helpers/typeof"), r = require("../common/src/index"), c = h(require("../common/config")), l = h(require("./props")), u = require("../common/utils");

function h(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function f(t, e, i) {
    return e = a(e), n(t, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (t) {
            return !1;
        }
    }() ? Reflect.construct(e, i || [], a(t).constructor) : e.apply(t, i));
}

var p = function(t, e, i, n) {
    var a, o = arguments.length, r = o < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, i) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : s(Reflect)) && "function" == typeof Reflect.decorate) r = Reflect.decorate(t, e, i, n); else for (var c = t.length - 1; c >= 0; c--) (a = t[c]) && (r = (o < 3 ? a(r) : o > 3 ? a(e, i, r) : a(e, i)) || r);
    return o > 3 && r && Object.defineProperty(e, i, r), r;
}, m = c.default.prefix, d = "".concat(m, "-message"), x = {
    info: "info-circle-filled",
    success: "check-circle-filled",
    warning: "info-circle-filled",
    error: "error-circle-filled"
}, v = function(n) {
    function a() {
        var t;
        return e(this, a), (t = f(this, a, arguments)).externalClasses = [ "".concat(m, "-class"), "".concat(m, "-class-content"), "".concat(m, "-class-icon"), "".concat(m, "-class-link"), "".concat(m, "-class-close-btn") ], 
        t.options = {
            styleIsolation: "apply-shared",
            multipleSlots: !0
        }, t.properties = Object.assign({}, l.default), t.data = {
            prefix: m,
            classPrefix: d,
            loop: -1,
            animation: [],
            showAnimation: [],
            wrapTop: -999
        }, t.observers = {
            marquee: function(t) {
                "{}" !== JSON.stringify(t) && "true" !== JSON.stringify(t) || this.setData({
                    marquee: {
                        speed: 50,
                        loop: -1,
                        delay: 0
                    }
                });
            },
            "icon, theme": function(t, e) {
                this.setData({
                    _icon: (0, u.calcIcon)(t, x[e])
                });
            },
            link: function(t) {
                var e = (0, u.isObject)(t) ? Object.assign({}, t) : {
                    content: t
                };
                this.setData({
                    _link: e
                });
            },
            closeBtn: function(t) {
                this.setData({
                    _closeBtn: (0, u.calcIcon)(t, "close")
                });
            }
        }, t.closeTimeoutContext = 0, t.nextAnimationContext = 0, t.resetAnimation = wx.createAnimation({
            duration: 0,
            timingFunction: "linear"
        }), t;
    }
    return o(a, n), i(a, [ {
        key: "ready",
        value: function() {
            this.memoInitialData();
        }
    }, {
        key: "memoInitialData",
        value: function() {
            this.initialData = Object.assign(Object.assign({}, this.properties), this.data);
        }
    }, {
        key: "resetData",
        value: function(t) {
            this.setData(Object.assign({}, this.initialData), t);
        }
    }, {
        key: "detached",
        value: function() {
            this.clearMessageAnimation();
        }
    }, {
        key: "checkAnimation",
        value: function() {
            var e = this, i = this.properties.marquee;
            if (i && 0 !== i.loop) {
                var n = i.speed;
                if (this.data.loop > 0) this.data.loop -= 1; else if (0 === this.data.loop) return void this.setData({
                    animation: this.resetAnimation.translateX(0).step().export()
                });
                this.nextAnimationContext && this.clearMessageAnimation();
                var a = "#".concat(d, "__text-wrap"), o = "#".concat(d, "__text");
                Promise.all([ (0, u.getRect)(this, o), (0, u.getRect)(this, a) ]).then(function(i) {
                    var a = t(i, 2), o = a[0], s = a[1];
                    e.setData({
                        animation: e.resetAnimation.translateX(s.width).step().export()
                    }, function() {
                        var t = (o.width + s.width) / n * 1e3, i = wx.createAnimation({
                            duration: t
                        }).translateX(-o.width).step().export();
                        setTimeout(function() {
                            e.nextAnimationContext = setTimeout(e.checkAnimation.bind(e), t), e.setData({
                                animation: i
                            });
                        }, 20);
                    });
                });
            }
        }
    }, {
        key: "clearMessageAnimation",
        value: function() {
            clearTimeout(this.nextAnimationContext), this.nextAnimationContext = 0;
        }
    }, {
        key: "show",
        value: function() {
            var t = this, e = this.properties, i = e.duration, n = e.marquee, a = e.offset;
            this.setData({
                visible: !0,
                loop: n.loop || this.data.loop
            }), this.reset(), this.checkAnimation(), i && i > 0 && (this.closeTimeoutContext = setTimeout(function() {
                t.hide(), t.triggerEvent("duration-end", {
                    self: t
                });
            }, i));
            var o = "#".concat(d);
            (0, u.getRect)(this, o).then(function(e) {
                t.setData({
                    wrapTop: -e.height
                }, function() {
                    t.setData({
                        showAnimation: wx.createAnimation({
                            duration: 500,
                            timingFunction: "ease"
                        }).translateY(e.height + (0, u.unitConvert)(a[0])).step().export()
                    });
                });
            });
        }
    }, {
        key: "hide",
        value: function() {
            var t = this;
            this.reset(), this.setData({
                showAnimation: wx.createAnimation({
                    duration: 500,
                    timingFunction: "ease"
                }).translateY(this.data.wrapTop).step().export()
            }), setTimeout(function() {
                t.setData({
                    visible: !1,
                    animation: []
                });
            }, 500);
        }
    }, {
        key: "reset",
        value: function() {
            this.nextAnimationContext && this.clearMessageAnimation(), clearTimeout(this.closeTimeoutContext), 
            this.closeTimeoutContext = 0;
        }
    }, {
        key: "handleClose",
        value: function() {
            this.hide(), this.triggerEvent("close-btn-click");
        }
    }, {
        key: "handleLinkClick",
        value: function() {
            this.triggerEvent("link-click");
        }
    } ]);
}(r.SuperComponent);

v = p([ (0, r.wxComponent)() ], v);

exports.default = v;