Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    action: {
        type: String
    },
    align: {
        type: String,
        value: "left"
    },
    closeBtn: {
        type: null,
        value: !1
    },
    content: {
        type: String
    },
    duration: {
        type: Number,
        value: 3e3
    },
    externalClasses: {
        type: Array
    },
    icon: {
        type: null,
        value: !0
    },
    marquee: {
        type: null,
        value: !1
    },
    offset: {
        type: Array
    },
    theme: {
        type: String,
        value: "info"
    },
    visible: {
        type: Boolean,
        value: !1
    },
    defaultVisible: {
        type: Boolean,
        value: !1
    },
    zIndex: {
        type: Number,
        value: 15e3
    },
    link: {
        type: null
    }
};

exports.default = e;