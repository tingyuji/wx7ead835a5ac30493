Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("./message.interface"), t = require("../common/utils"), r = function(e, t) {
    var r = {};
    for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
    if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
        var o = 0;
        for (n = Object.getOwnPropertySymbols(e); o < n.length; o++) t.indexOf(n[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[o]) && (r[n[o]] = e[n[o]]);
    }
    return r;
}, n = function(n) {
    var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : e.MessageType.info, s = n.context, c = n.selector, i = void 0 === c ? "#t-message" : c, a = r(n, [ "context", "selector" ]), u = (0, 
    t.getInstance)(s, i);
    if (u) return u.resetData(function() {
        u.setData(Object.assign({
            theme: o
        }, a), u.show.bind(u));
    }), u;
    console.error("未找到组件,请确认 selector && context 是否正确");
};

exports.default = {
    info: function(t) {
        return n(t, e.MessageType.info);
    },
    success: function(t) {
        return n(t, e.MessageType.success);
    },
    warning: function(t) {
        return n(t, e.MessageType.warning);
    },
    error: function(t) {
        return n(t, e.MessageType.error);
    },
    hide: function(e) {
        var r = Object.assign({}, e), n = r.context, o = r.selector, s = void 0 === o ? "#t-message" : o, c = (0, 
        t.getInstance)(n, s);
        c && c.hide();
    }
};