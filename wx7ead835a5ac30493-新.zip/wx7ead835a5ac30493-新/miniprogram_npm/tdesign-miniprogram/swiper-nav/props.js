Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    current: {
        type: Number,
        value: 0
    },
    direction: {
        type: String,
        value: "horizontal"
    },
    minShowNum: {
        type: Number,
        value: 2
    },
    paginationPosition: {
        type: String,
        value: "bottom"
    },
    showControls: {
        type: Boolean,
        value: !1
    },
    total: {
        type: Number,
        value: 0
    },
    type: {
        type: String,
        value: "dots"
    }
};

exports.default = e;