Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/defineProperty"), r = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), i = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), u = require("../../../@babel/runtime/helpers/typeof"), c = require("../common/src/index"), l = a(require("../common/config")), s = a(require("./props"));

function a(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, r, t) {
    return r = i(r), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(r, t || [], i(e).constructor) : r.apply(e, t));
}

var p = function(e, r, t, n) {
    var i, o = arguments.length, c = o < 3 ? r : null === n ? n = Object.getOwnPropertyDescriptor(r, t) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : u(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, r, t, n); else for (var l = e.length - 1; l >= 0; l--) (i = e[l]) && (c = (o < 3 ? i(c) : o > 3 ? i(r, t, c) : i(r, t)) || c);
    return o > 3 && c && Object.defineProperty(r, t, c), c;
}, d = l.default.prefix, h = "".concat(d, "-side-bar"), b = function(n) {
    function i() {
        var r;
        return t(this, i), (r = f(this, i, arguments)).externalClasses = [ "".concat(d, "-class") ], 
        r.children = [], r.relations = e({}, "../side-bar-item/side-bar-item", {
            type: "child",
            linked: function(e) {
                this.children.push(e);
            },
            unlinked: function(e) {
                var r = this.children.findIndex(function(r) {
                    return r === e;
                });
                this.children.splice(r, 1);
            }
        }), r.controlledProps = [ {
            key: "value",
            event: "change"
        } ], r.properties = s.default, r.observers = {
            value: function(e) {
                this.$children.forEach(function(r) {
                    r.updateActive(e);
                });
            }
        }, r.data = {
            classPrefix: h,
            prefix: d
        }, r.methods = {
            doChange: function(e) {
                var r = e.value, t = e.label;
                this._trigger("change", {
                    value: r,
                    label: t
                });
            }
        }, r;
    }
    return o(i, n), r(i);
}(c.SuperComponent);

b = p([ (0, c.wxComponent)() ], b);

exports.default = b;