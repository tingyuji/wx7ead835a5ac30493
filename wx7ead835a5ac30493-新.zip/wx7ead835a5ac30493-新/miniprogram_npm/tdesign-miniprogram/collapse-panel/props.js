Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    content: {
        type: String
    },
    disabled: {
        type: Boolean,
        value: void 0
    },
    expandIcon: {
        type: Boolean,
        value: void 0
    },
    externalClasses: {
        type: Array
    },
    header: {
        type: String
    },
    headerLeftIcon: {
        type: String
    },
    headerRightContent: {
        type: String
    },
    placement: {
        type: String,
        value: "bottom"
    },
    value: {
        type: null
    }
};

exports.default = e;