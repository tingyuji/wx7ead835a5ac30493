Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0, require("../../../@babel/runtime/helpers/Arrayincludes");

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), r = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), c = require("../../../@babel/runtime/helpers/typeof"), a = require("../common/src/index"), l = o(require("../common/config")), u = o(require("./props"));

function o(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function s(e, t, i) {
    return t = r(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, i || [], r(e).constructor) : t.apply(e, i));
}

var h = function(e, t, n, r) {
    var i, a = arguments.length, l = a < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, n) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : c(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(e, t, n, r); else for (var u = e.length - 1; u >= 0; u--) (i = e[u]) && (l = (a < 3 ? i(l) : a > 3 ? i(t, n, l) : i(t, n)) || l);
    return a > 3 && l && Object.defineProperty(t, n, l), l;
}, d = l.default.prefix, f = "".concat(d, "-checkbox-group"), p = function(n) {
    function r() {
        var e;
        return t(this, r), (e = s(this, r, arguments)).externalClasses = [ "".concat(d, "-class") ], 
        e.relations = {
            "../checkbox/checkbox": {
                type: "descendant"
            }
        }, e.data = {
            prefix: d,
            classPrefix: f,
            checkboxOptions: []
        }, e.properties = u.default, e.observers = {
            value: function() {
                this.updateChildren();
            },
            options: function() {
                this.initWithOptions();
            }
        }, e.lifetimes = {
            ready: function() {
                this.setCheckall();
            }
        }, e.controlledProps = [ {
            key: "value",
            event: "change"
        } ], e.$checkAll = null, e.methods = {
            getChildren: function() {
                var e = this.$children;
                return e.length || (e = this.selectAllComponents(".".concat(d, "-checkbox-option"))), 
                e || [];
            },
            updateChildren: function() {
                var e = this.getChildren(), t = this.data.value;
                e.length > 0 && (e.forEach(function(e) {
                    !e.data.checkAll && e.setData({
                        checked: null == t ? void 0 : t.includes(e.data.value)
                    });
                }), e.some(function(e) {
                    return e.data.checkAll;
                }) && this.setCheckall());
            },
            updateValue: function(e) {
                var t = e.value, n = e.checked, r = e.checkAll, i = e.item, c = e.indeterminate, a = this.data.value, l = this.data.max, u = new Set(this.getChildren().map(function(e) {
                    return e.data.value;
                }));
                if (a = a.filter(function(e) {
                    return u.has(e);
                }), !l || !n || a.length !== l) {
                    if (r) {
                        var o = this.getChildren();
                        a = !n && c ? o.filter(function(e) {
                            var t = e.data;
                            return !(t.disabled && !a.includes(t.value));
                        }).map(function(e) {
                            return e.data.value;
                        }) : o.filter(function(e) {
                            var t = e.data;
                            return t.disabled ? a.includes(t.value) : n && !t.checkAll;
                        }).map(function(e) {
                            return e.data.value;
                        });
                    } else if (n) a = a.concat(t); else {
                        var s = a.findIndex(function(e) {
                            return e === t;
                        });
                        a.splice(s, 1);
                    }
                    this._trigger("change", {
                        value: a,
                        context: i
                    });
                }
            },
            initWithOptions: function() {
                var e = this.data, t = e.options, n = e.value;
                if ((null == t ? void 0 : t.length) && Array.isArray(t)) {
                    var r = t.map(function(e) {
                        return [ "number", "string" ].includes(c(e)) ? {
                            label: "".concat(e),
                            value: e,
                            checked: null == n ? void 0 : n.includes(e)
                        } : Object.assign(Object.assign({}, e), {
                            checked: null == n ? void 0 : n.includes(e.value)
                        });
                    });
                    this.setData({
                        checkboxOptions: r
                    });
                }
            },
            handleInnerChildChange: function(e) {
                var t, n = e.target.dataset.item, r = e.detail.checked, i = {};
                n.checkAll && (i.indeterminate = null === (t = this.$checkAll) || void 0 === t ? void 0 : t.data.indeterminate), 
                this.updateValue(Object.assign(Object.assign(Object.assign({}, n), {
                    checked: r,
                    item: n
                }), i));
            },
            setCheckall: function() {
                var e = this, t = this.getChildren();
                if (this.$checkAll || (this.$checkAll = t.find(function(e) {
                    return e.data.checkAll;
                })), this.$checkAll) {
                    var n = this.data.value, r = new Set(n.filter(function(t) {
                        return t !== e.$checkAll.data.value;
                    })), i = t.every(function(e) {
                        return !!e.data.checkAll || r.has(e.data.value);
                    });
                    this.$checkAll.setData({
                        checked: r.size > 0,
                        indeterminate: !i
                    });
                }
            }
        }, e;
    }
    return i(r, n), e(r);
}(a.SuperComponent);

p = h([ (0, a.wxComponent)() ], p);

exports.default = p;