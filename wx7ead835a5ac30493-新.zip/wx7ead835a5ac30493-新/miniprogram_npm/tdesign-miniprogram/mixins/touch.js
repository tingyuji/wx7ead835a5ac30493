Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../../@babel/runtime/helpers/slicedToArray");

exports.default = Behavior({
    methods: {
        resetTouchStatus: function() {
            this.direction = "", this.deltaX = 0, this.deltaY = 0, this.offsetX = 0, this.offsetY = 0;
        },
        touchStart: function(e) {
            this.resetTouchStatus();
            var s = t(e.touches, 1)[0];
            this.startX = s.clientX, this.startY = s.clientY;
        },
        touchMove: function(e) {
            var s, i, h = t(e.touches, 1)[0];
            this.deltaX = h.clientX - this.startX, this.deltaY = h.clientY - this.startY, this.offsetX = Math.abs(this.deltaX), 
            this.offsetY = Math.abs(this.deltaY), this.direction = (s = this.offsetX, i = this.offsetY, 
            s > i && s > 10 ? "horizontal" : i > s && i > 10 ? "vertical" : "");
        }
    }
});