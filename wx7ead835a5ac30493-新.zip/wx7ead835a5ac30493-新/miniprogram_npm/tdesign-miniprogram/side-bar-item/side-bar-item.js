Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), a = require("../../../@babel/runtime/helpers/typeof"), o = require("../common/src/index"), u = l(require("../common/config")), c = l(require("./props"));

function l(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function s(e, t, i) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, i || [], n(e).constructor) : t.apply(e, i));
}

var f = function(e, t, r, n) {
    var i, o = arguments.length, u = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : a(Reflect)) && "function" == typeof Reflect.decorate) u = Reflect.decorate(e, t, r, n); else for (var c = e.length - 1; c >= 0; c--) (i = e[c]) && (u = (o < 3 ? i(u) : o > 3 ? i(t, r, u) : i(t, r)) || u);
    return o > 3 && u && Object.defineProperty(t, r, u), u;
}, p = u.default.prefix, d = "".concat(p, "-side-bar-item"), h = function(r) {
    function n() {
        var e;
        return t(this, n), (e = s(this, n, arguments)).externalClasses = [ "".concat(p, "-class") ], 
        e.properties = c.default, e.relations = {
            "../side-bar/side-bar": {
                type: "parent",
                linked: function(e) {
                    this.parent = e, this.updateActive(e.data.value);
                }
            }
        }, e.observers = {
            icon: function(e) {
                this.setData({
                    _icon: "string" == typeof e ? {
                        name: e
                    } : e
                });
            }
        }, e.data = {
            classPrefix: d,
            prefix: p,
            active: !1,
            isPre: !1,
            isNext: !1
        }, e.methods = {
            updateActive: function(e) {
                var t = e === this.data.value;
                this.setData({
                    active: t
                });
            },
            handleClick: function() {
                var e;
                if (!this.data.disabled) {
                    var t = this.data, r = t.value, n = t.label;
                    null === (e = this.parent) || void 0 === e || e.doChange({
                        value: r,
                        label: n
                    });
                }
            }
        }, e;
    }
    return i(n, r), e(n);
}(o.SuperComponent);

h = f([ (0, o.wxComponent)() ], h);

exports.default = h;