Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    badgeProps: {
        type: Object
    },
    disabled: {
        type: Boolean,
        value: !1
    },
    icon: {
        type: null
    },
    label: {
        type: String,
        value: ""
    },
    value: {
        type: null
    }
};

exports.default = e;