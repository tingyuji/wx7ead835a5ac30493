Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    placement: {
        type: String,
        value: "left"
    },
    borderless: {
        type: Boolean,
        value: !1
    },
    disabled: {
        type: Boolean,
        value: void 0
    },
    icon: {
        type: null,
        value: "circle"
    },
    keys: {
        type: Object
    },
    name: {
        type: String,
        value: ""
    },
    options: {
        type: Array
    },
    value: {
        type: null,
        value: null
    },
    defaultValue: {
        type: null
    }
};

exports.default = e;