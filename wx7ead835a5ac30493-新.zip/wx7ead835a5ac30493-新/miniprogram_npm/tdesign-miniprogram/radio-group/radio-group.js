Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), o = require("../../../@babel/runtime/helpers/typeof"), a = c(require("../common/config")), l = require("../common/src/index"), u = c(require("./props"));

function c(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function s(e, t, i) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, i || [], n(e).constructor) : t.apply(e, i));
}

var d = function(e, t, r, n) {
    var i, a = arguments.length, l = a < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : o(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(e, t, r, n); else for (var u = e.length - 1; u >= 0; u--) (i = e[u]) && (l = (a < 3 ? i(l) : a > 3 ? i(t, r, l) : i(t, r)) || l);
    return a > 3 && l && Object.defineProperty(t, r, l), l;
}, f = a.default.prefix, h = "".concat(f, "-radio-group"), p = function(r) {
    function n() {
        var e;
        return t(this, n), (e = s(this, n, arguments)).externalClasses = [ "".concat(f, "-class") ], 
        e.data = {
            prefix: f,
            classPrefix: h,
            radioOptions: []
        }, e.relations = {
            "../radio/radio": {
                type: "descendant",
                linked: function(e) {
                    var t = this.data, r = t.value, n = t.disabled;
                    e.setData({
                        checked: r === e.data.value
                    }), e.setDisabled(n);
                }
            }
        }, e.properties = u.default, e.controlledProps = [ {
            key: "value",
            event: "change"
        } ], e.observers = {
            value: function(e) {
                this.getChildren().forEach(function(t) {
                    t.setData({
                        checked: e === t.data.value
                    });
                });
            },
            options: function() {
                this.initWithOptions();
            }
        }, e.methods = {
            getChildren: function() {
                var e = this.$children;
                return (null == e ? void 0 : e.length) || (e = this.selectAllComponents(".".concat(f, "-radio-option"))), 
                e;
            },
            updateValue: function(e) {
                this._trigger("change", {
                    value: e
                });
            },
            handleRadioChange: function(e) {
                var t = e.detail.checked, r = e.target.dataset, n = r.value, i = r.index, o = r.allowUncheck;
                this._trigger("change", !1 === t && o ? {
                    value: null,
                    index: i
                } : {
                    value: n,
                    index: i
                });
            },
            initWithOptions: function() {
                var e = this.data, t = e.options, r = e.value, n = e.keys;
                if ((null == t ? void 0 : t.length) && Array.isArray(t)) {
                    var i = [];
                    try {
                        t.forEach(function(e) {
                            var t, a, l, u = o(e);
                            "number" === u || "string" === u ? i.push({
                                label: "".concat(e),
                                value: e,
                                checked: r === e
                            }) : "object" === u && i.push(Object.assign(Object.assign({}, e), {
                                label: e[null !== (t = null == n ? void 0 : n.label) && void 0 !== t ? t : "label"],
                                value: e[null !== (a = null == n ? void 0 : n.value) && void 0 !== a ? a : "value"],
                                checked: r === e[null !== (l = null == n ? void 0 : n.value) && void 0 !== l ? l : "value"]
                            }));
                        }), this.setData({
                            radioOptions: i
                        });
                    } catch (e) {
                        console.error("error", e);
                    }
                } else this.setData({
                    radioOptions: []
                });
            }
        }, e;
    }
    return i(n, r), e(n);
}(l.SuperComponent);

p = d([ (0, l.wxComponent)() ], p);

exports.default = p;