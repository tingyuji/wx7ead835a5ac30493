Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), o = require("../../../@babel/runtime/helpers/typeof"), l = require("../common/src/index"), u = s(require("../common/config")), c = s(require("./props"));

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function a(e, t, i) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, i || [], n(e).constructor) : t.apply(e, i));
}

var f = function(e, t, r, n) {
    var i, l = arguments.length, u = l < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : o(Reflect)) && "function" == typeof Reflect.decorate) u = Reflect.decorate(e, t, r, n); else for (var c = e.length - 1; c >= 0; c--) (i = e[c]) && (u = (l < 3 ? i(u) : l > 3 ? i(t, r, u) : i(t, r)) || u);
    return l > 3 && u && Object.defineProperty(t, r, u), u;
}, p = u.default.prefix, d = "".concat(p, "-drawer"), h = function(r) {
    function n() {
        var e;
        return t(this, n), (e = a(this, n, arguments)).externalClasses = [], e.options = {
            multipleSlots: !0
        }, e.properties = c.default, e.data = {
            classPrefix: d
        }, e.methods = {
            visibleChange: function(e) {
                var t = e.detail.visible, r = this.data.showOverlay;
                this.setData({
                    visible: t
                }), t || this.triggerEvent("close", {
                    trigger: "overlay"
                }), r && this.triggerEvent("overlay-click", {
                    visible: t
                });
            },
            itemClick: function(e) {
                var t = e.currentTarget.dataset, r = t.index, n = t.item;
                this.triggerEvent("item-click", {
                    index: r,
                    item: n
                });
            }
        }, e;
    }
    return i(n, r), e(n);
}(l.SuperComponent);

h = f([ (0, l.wxComponent)() ], h);

exports.default = h;