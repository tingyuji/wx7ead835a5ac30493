Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    closeOnOverlayClick: {
        type: Boolean,
        value: !0
    },
    destroyOnClose: {
        type: Boolean,
        value: !1
    },
    items: {
        type: Array
    },
    placement: {
        type: String,
        value: "right"
    },
    showOverlay: {
        type: Boolean,
        value: !0
    },
    title: {
        type: String
    },
    visible: {
        type: Boolean,
        value: !1
    },
    zIndex: {
        type: Number,
        value: 11500
    }
};

exports.default = e;