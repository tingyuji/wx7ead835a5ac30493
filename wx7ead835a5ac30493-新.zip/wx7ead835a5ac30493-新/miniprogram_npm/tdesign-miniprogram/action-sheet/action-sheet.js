Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/classCallCheck"), t = require("../../../@babel/runtime/helpers/createClass"), i = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), r = require("../../../@babel/runtime/helpers/getPrototypeOf"), n = require("../../../@babel/runtime/helpers/inherits"), s = require("../../../@babel/runtime/helpers/typeof"), o = require("../common/utils"), a = require("../common/src/index"), c = h(require("../common/config")), l = require("./show"), u = h(require("./props"));

function h(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, n) {
    return t = r(t), i(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, n || [], r(e).constructor) : t.apply(e, n));
}

var d = function(e, t, i, r) {
    var n, o = arguments.length, a = o < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : s(Reflect)) && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, r); else for (var c = e.length - 1; c >= 0; c--) (n = e[c]) && (a = (o < 3 ? n(a) : o > 3 ? n(t, i, a) : n(t, i)) || a);
    return o > 3 && a && Object.defineProperty(t, i, a), a;
}, p = c.default.prefix, g = "".concat(p, "-action-sheet"), b = function(i) {
    function r() {
        var t;
        return e(this, r), (t = f(this, r, arguments)).externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-content"), "".concat(p, "-class-cancel") ], 
        t.properties = Object.assign({}, u.default), t.data = {
            prefix: p,
            classPrefix: g,
            gridThemeItems: [],
            currentSwiperIndex: 0,
            defaultPopUpProps: {},
            defaultPopUpzIndex: 11500
        }, t.controlledProps = [ {
            key: "visible",
            event: "visible-change"
        } ], t.methods = {
            onSwiperChange: function(e) {
                var t = e.detail.current;
                this.setData({
                    currentSwiperIndex: t
                });
            },
            splitGridThemeActions: function() {
                this.data.theme === l.ActionSheetTheme.Grid && this.setData({
                    gridThemeItems: (0, o.chunk)(this.data.items, this.data.count)
                });
            },
            show: function(e) {
                this.setData(Object.assign(Object.assign(Object.assign({}, this.initialData), e), {
                    visible: !0
                })), this.splitGridThemeActions(), this.autoClose = !0, this._trigger("visible-change", {
                    visible: !0
                });
            },
            memoInitialData: function() {
                this.initialData = Object.assign(Object.assign({}, this.properties), this.data);
            },
            close: function() {
                this.triggerEvent("close", {
                    trigger: "command"
                }), this._trigger("visible-change", {
                    visible: !1
                });
            },
            onPopupVisibleChange: function(e) {
                e.detail.visible || (this.triggerEvent("close", {
                    trigger: "overlay"
                }), this._trigger("visible-change", {
                    visible: !1
                })), this.autoClose && (this.setData({
                    visible: !1
                }), this.autoClose = !1);
            },
            onSelect: function(e) {
                var t = this.data, i = t.currentSwiperIndex, r = t.items, n = t.gridThemeItems, s = t.count, o = t.theme, a = e.currentTarget.dataset.index, c = o === l.ActionSheetTheme.Grid, u = c ? n[i][a] : r[a], h = c ? a + i * s : a;
                u && (this.triggerEvent("selected", {
                    selected: u,
                    index: h
                }), u.disabled || (this.triggerEvent("close", {
                    trigger: "select"
                }), this._trigger("visible-change", {
                    visible: !1
                })));
            },
            onCancel: function() {
                this.triggerEvent("cancel"), this.autoClose && (this.setData({
                    visible: !1
                }), this.autoClose = !1);
            }
        }, t;
    }
    return n(r, i), t(r, [ {
        key: "ready",
        value: function() {
            this.memoInitialData(), this.splitGridThemeActions();
        }
    } ]);
}(a.SuperComponent);

b.show = l.show, b = d([ (0, a.wxComponent)() ], b);

exports.default = b;