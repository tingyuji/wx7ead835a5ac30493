Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.show = exports.close = exports.ActionSheetTheme = void 0;

var e, t = require("../common/utils"), o = function(e, t) {
    var o = {};
    for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (o[r] = e[r]);
    if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
        var n = 0;
        for (r = Object.getOwnPropertySymbols(e); n < r.length; n++) t.indexOf(r[n]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[n]) && (o[r[n]] = e[r[n]]);
    }
    return o;
};

!function(e) {
    e.List = "list", e.Grid = "grid";
}(e || (exports.ActionSheetTheme = e = {}));

exports.show = function(e) {
    var r = Object.assign({}, e), n = r.context, s = r.selector, c = void 0 === s ? "#t-action-sheet" : s, i = o(r, [ "context", "selector" ]), l = (0, 
    t.getInstance)(n, c);
    if (l) return l.show(Object.assign({}, i)), l;
    console.error("未找到组件,请确认 selector && context 是否正确");
}, exports.close = function(e) {
    var o = Object.assign({}, e), r = o.context, n = o.selector, s = void 0 === n ? "#t-action-sheet" : n, c = (0, 
    t.getInstance)(r, s);
    c && c.close();
};