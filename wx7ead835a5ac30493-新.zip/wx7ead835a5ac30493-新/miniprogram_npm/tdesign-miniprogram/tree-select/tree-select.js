Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/slicedToArray"), t = require("../../../@babel/runtime/helpers/toConsumableArray"), r = require("../../../@babel/runtime/helpers/createClass"), l = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), a = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), u = require("../../../@babel/runtime/helpers/typeof"), o = require("../common/src/index"), s = f(require("../common/config")), c = f(require("./props"));

function f(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function d(e, t, r) {
    return t = a(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, r || [], a(e).constructor) : t.apply(e, r));
}

var p = function(e, t, r, l) {
    var n, a = arguments.length, i = a < 3 ? t : null === l ? l = Object.getOwnPropertyDescriptor(t, r) : l;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : u(Reflect)) && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, r, l); else for (var o = e.length - 1; o >= 0; o--) (n = e[o]) && (i = (a < 3 ? n(i) : a > 3 ? n(t, r, i) : n(t, r)) || i);
    return a > 3 && i && Object.defineProperty(t, r, i), i;
}, v = s.default.prefix, h = "".concat(v, "-tree-select"), b = function(n) {
    function a() {
        var r;
        return l(this, a), (r = d(this, a, arguments)).externalClasses = [ "".concat(v, "-class") ], 
        r.options = {
            multipleSlots: !0
        }, r.data = {
            prefix: v,
            classPrefix: h
        }, r.properties = c.default, r.controlledProps = [ {
            key: "value",
            event: "change"
        } ], r.observers = {
            "value, options, keys, multiple": function() {
                this.buildTreeOptions();
            }
        }, r.methods = {
            buildTreeOptions: function() {
                var r = this.data, l = r.options, n = r.value, a = r.multiple, i = r.keys, u = [], o = -1, s = {
                    children: l
                };
                if (!(0 === l.length || Array.isArray(n) && 0 === n.length)) {
                    for (var c = function() {
                        o += 1;
                        var r = s.children.map(function(e) {
                            return {
                                label: e[(null == i ? void 0 : i.label) || "label"],
                                value: e[(null == i ? void 0 : i.value) || "value"],
                                children: e.children
                            };
                        }), l = null == n ? void 0 : n[o];
                        if (u.push(t(r)), null == l) {
                            var a = e(r, 1)[0];
                            s = a;
                        } else {
                            var c = r.find(function(e) {
                                return e.value === l;
                            });
                            s = null != c ? c : r[0];
                        }
                    }; s && s.children; ) c();
                    var f = Math.max(0, o);
                    if (a) {
                        var d = this.data.value || this.data.defaultValue;
                        if (null != d[f] && !Array.isArray(d[f])) throw TypeError("应传入数组类型的 value");
                    }
                    this.setData({
                        leafLevel: f,
                        treeOptions: u
                    });
                }
            },
            onRootChange: function(e) {
                var t = this.data.value, r = e.detail.value;
                t[0] = r, this._trigger("change", {
                    value: t,
                    level: 0
                });
            },
            handleTreeClick: function(e) {
                var t = e.currentTarget.dataset, r = t.level, l = t.value, n = this.data.value;
                n[r] = l, this._trigger("change", {
                    value: n,
                    level: 1
                });
            },
            handleRadioChange: function(e) {
                var t = this.data.value, r = e.detail.value, l = e.target.dataset.level;
                t[l] = r, this._trigger("change", {
                    value: t,
                    level: l
                });
            }
        }, r;
    }
    return i(a, n), r(a);
}(o.SuperComponent);

b = p([ (0, o.wxComponent)() ], b);

exports.default = b;