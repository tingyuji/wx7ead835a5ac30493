Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    height: {
        type: null,
        value: 336
    },
    keys: {
        type: Object
    },
    multiple: {
        type: Boolean,
        value: !1
    },
    options: {
        type: Array,
        value: []
    },
    value: {
        type: null,
        value: null
    },
    defaultValue: {
        type: null
    }
};

exports.default = e;