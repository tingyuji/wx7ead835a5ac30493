Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    autoStart: {
        type: Boolean,
        value: !0
    },
    content: {
        type: String,
        value: "default"
    },
    format: {
        type: String,
        value: "HH:mm:ss"
    },
    millisecond: {
        type: Boolean,
        value: !1
    },
    size: {
        type: String,
        value: "medium"
    },
    splitWithUnit: {
        type: Boolean,
        value: !1
    },
    theme: {
        type: String,
        value: "default"
    },
    time: {
        type: Number
    }
};

exports.default = e;