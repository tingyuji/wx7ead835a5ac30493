Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/classCallCheck"), t = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), o = require("../../../@babel/runtime/helpers/getPrototypeOf"), n = require("../../../@babel/runtime/helpers/inherits"), c = require("../../../@babel/runtime/helpers/typeof"), s = require("../common/src/index"), i = f(require("../common/config")), a = f(require("./props")), u = require("./utils"), l = require("../common/utils");

function f(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function p(e, t, n) {
    return t = o(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, n || [], o(e).constructor) : t.apply(e, n));
}

var h = function(e, t, r, o) {
    var n, s = arguments.length, i = s < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : c(Reflect)) && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, r, o); else for (var a = e.length - 1; a >= 0; a--) (n = e[a]) && (i = (s < 3 ? n(i) : s > 3 ? n(t, r, i) : n(t, r)) || i);
    return s > 3 && i && Object.defineProperty(t, r, i), i;
}, d = i.default.prefix, m = "".concat(d, "-progress"), b = function(r) {
    function o() {
        var t;
        return e(this, o), (t = p(this, o, arguments)).externalClasses = [ "".concat(d, "-class"), "".concat(d, "-class-bar"), "".concat(d, "-class-label") ], 
        t.options = {
            multipleSlots: !0
        }, t.properties = a.default, t.data = {
            prefix: d,
            classPrefix: m,
            colorBar: "",
            heightBar: "",
            computedStatus: "",
            computedProgress: 0,
            isIOS: !1
        }, t.observers = {
            percentage: function(e) {
                e = Math.max(0, Math.min(e, 100)), this.setData({
                    computedStatus: 100 === e ? "success" : "",
                    computedProgress: e
                });
            },
            color: function(e) {
                this.setData({
                    colorBar: (0, u.getBackgroundColor)(e),
                    colorCircle: "object" === c(e) ? "" : e
                });
            },
            strokeWidth: function(e) {
                if (!e) return "";
                this.setData({
                    heightBar: (0, l.unitConvert)(e)
                });
            },
            theme: function(e) {
                "circle" === e && this.getInnerDiameter();
            },
            trackColor: function(e) {
                this.setData({
                    bgColorBar: e
                });
            }
        }, t.methods = {
            getInnerDiameter: function() {
                var e = this, t = this.properties.strokeWidth, r = ".".concat(m, "__canvas--circle");
                t && (0, l.getRect)(this, r).then(function(r) {
                    e.setData({
                        innerDiameter: r.width - 2 * (0, l.unitConvert)(t)
                    });
                });
            }
        }, t;
    }
    return n(o, r), t(o, [ {
        key: "attached",
        value: function() {
            var e = this;
            wx.getSystemInfo({
                success: function(t) {
                    var r = !!(t.system.toLowerCase().search("ios") + 1);
                    e.setData({
                        isIOS: r
                    });
                },
                fail: function(e) {
                    console.error("progress 获取系统信息失败", e);
                }
            });
        }
    } ]);
}(s.SuperComponent);

b = h([ (0, s.wxComponent)() ], b);

exports.default = b;