Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), c = require("../../../@babel/runtime/helpers/typeof"), u = require("../common/src/index"), i = a(require("./props")), s = a(require("../common/config")), l = require("../common/utils");

function a(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, o) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, o || [], n(e).constructor) : t.apply(e, o));
}

var p = function(e, t, r, n) {
    var o, u = arguments.length, i = u < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : c(Reflect)) && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, r, n); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (i = (u < 3 ? o(i) : u > 3 ? o(t, r, i) : o(t, r)) || i);
    return u > 3 && i && Object.defineProperty(t, r, i), i;
}, d = s.default.prefix, b = "".concat(d, "-empty"), m = function(r) {
    function n() {
        var e;
        return t(this, n), (e = f(this, n, arguments)).options = {
            multipleSlots: !0
        }, e.externalClasses = [ "".concat(d, "-class"), "".concat(d, "-class-description"), "".concat(d, "-class-image") ], 
        e.properties = i.default, e.data = {
            prefix: d,
            classPrefix: b
        }, e.observers = {
            icon: function(e) {
                var t = (0, l.setIcon)("icon", e, "");
                this.setData(Object.assign({}, t));
            }
        }, e;
    }
    return o(n, r), e(n);
}(u.SuperComponent);

m = p([ (0, u.wxComponent)() ], m);

exports.default = m;