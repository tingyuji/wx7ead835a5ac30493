Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), r = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), a = require("../../../@babel/runtime/helpers/typeof"), i = s(require("../common/config")), c = require("../common/src/index"), l = s(require("./props"));

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function u(e, t, o) {
    return t = r(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, o || [], r(e).constructor) : t.apply(e, o));
}

var d = function(e, t, n, r) {
    var o, i = arguments.length, c = i < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, n) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : a(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, n, r); else for (var l = e.length - 1; l >= 0; l--) (o = e[l]) && (c = (i < 3 ? o(c) : i > 3 ? o(t, n, c) : o(t, n)) || c);
    return i > 3 && c && Object.defineProperty(t, n, c), c;
}, f = i.default.prefix, p = "".concat(f, "-radio"), h = function(n) {
    function r() {
        var e;
        return t(this, r), (e = u(this, r, arguments)).externalClasses = [ "".concat(f, "-class"), "".concat(f, "-class-label"), "".concat(f, "-class-icon"), "".concat(f, "-class-content"), "".concat(f, "-class-border") ], 
        e.behaviors = [ "wx://form-field" ], e.relations = {
            "../radio-group/radio-group": {
                type: "ancestor",
                linked: function(e) {
                    e.data.borderless && this.setData({
                        borderless: !0
                    });
                }
            }
        }, e.options = {
            multipleSlots: !0
        }, e.lifetimes = {
            attached: function() {
                this.init();
            }
        }, e.properties = Object.assign(Object.assign({}, l.default), {
            borderless: {
                type: Boolean,
                value: !1
            }
        }), e.controlledProps = [ {
            key: "checked",
            event: "change"
        } ], e.data = {
            prefix: f,
            classPrefix: p,
            customIcon: !1,
            slotIcon: !1,
            optionLinked: !1,
            iconVal: [],
            _placement: ""
        }, e.methods = {
            handleTap: function(e) {
                this.data.disabled || this.data.readonly || ("text" === e.currentTarget.dataset.target && this.data.contentDisabled || this.doChange());
            },
            doChange: function() {
                var e = this.data, t = e.value, n = e.checked, r = e.allowUncheck;
                this.$parent ? this.$parent.updateValue(n && r ? null : t) : this._trigger("change", {
                    checked: (!n || !r) && !n
                });
            },
            init: function() {
                var e, t, n, r, o, a, i = this.data.icon, c = Array.isArray((null === (e = this.$parent) || void 0 === e ? void 0 : e.icon) || i);
                this.setData({
                    customIcon: c,
                    slotIcon: "slot" === i,
                    iconVal: c ? (null === (t = this.$parent) || void 0 === t ? void 0 : t.icon) || i : [],
                    _placement: null !== (a = null !== (n = this.data.placement) && void 0 !== n ? n : null === (o = null === (r = this.$parent) || void 0 === r ? void 0 : r.data) || void 0 === o ? void 0 : o.placement) && void 0 !== a ? a : "left"
                });
            },
            setDisabled: function(e) {
                this.setData({
                    disabled: this.data.disabled || e
                });
            }
        }, e;
    }
    return o(r, n), e(r);
}(c.SuperComponent);

h = d([ (0, c.wxComponent)() ], h);

exports.default = h;