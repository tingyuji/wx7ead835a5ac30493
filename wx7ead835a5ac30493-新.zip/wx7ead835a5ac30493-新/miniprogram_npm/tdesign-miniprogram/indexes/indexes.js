Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../../@babel/runtime/helpers/createClass"), e = require("../../../@babel/runtime/helpers/classCallCheck"), i = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), r = require("../../../@babel/runtime/helpers/inherits"), o = require("../../../@babel/runtime/helpers/typeof"), c = require("../common/src/index"), s = u(require("../common/config")), h = u(require("./props")), a = require("../common/utils"), l = u(require("../mixins/page-scroll"));

function u(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function f(t, e, r) {
    return e = n(e), i(t, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (t) {
            return !1;
        }
    }() ? Reflect.construct(e, r || [], n(t).constructor) : e.apply(t, r));
}

var p = function(t, e, i, n) {
    var r, c = arguments.length, s = c < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, i) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : o(Reflect)) && "function" == typeof Reflect.decorate) s = Reflect.decorate(t, e, i, n); else for (var h = t.length - 1; h >= 0; h--) (r = t[h]) && (s = (c < 3 ? r(s) : c > 3 ? r(e, i, s) : r(e, i)) || s);
    return c > 3 && s && Object.defineProperty(e, i, s), s;
}, d = s.default.prefix, g = "".concat(d, "-indexes"), x = function(i) {
    function n() {
        var t;
        return e(this, n), (t = f(this, n, arguments)).externalClasses = [ "".concat(d, "-class"), "".concat(d, "-class-sidebar"), "".concat(d, "-class-sidebar-item") ], 
        t.properties = h.default, t.data = {
            prefix: d,
            classPrefix: g,
            _height: 0,
            _indexList: [],
            scrollTop: 0,
            activeAnchor: null,
            showTips: !1
        }, t.relations = {
            "../indexes-anchor/indexes-anchor": {
                type: "child"
            }
        }, t.behaviors = [ (0, l.default)() ], t.timer = null, t.groupTop = [], t.sidebar = null, 
        t.observers = {
            indexList: function(t) {
                this.setIndexList(t), this.setHeight(this.data._height);
            },
            height: function(t) {
                this.setHeight(t);
            }
        }, t.lifetimes = {
            ready: function() {
                0 === this.data._height && this.setHeight(), null === this.data.indexList && this.setIndexList();
            }
        }, t.methods = {
            setHeight: function(t) {
                var e = this;
                t || (t = wx.getSystemInfoSync().windowHeight);
                this.setData({
                    _height: t
                }, function() {
                    e.getAllRect();
                });
            },
            setIndexList: function(t) {
                if (t) this.setData({
                    _indexList: t
                }); else {
                    for (var e = "A".charCodeAt(0), i = [], n = e, r = e + 26; n < r; n += 1) i.push(String.fromCharCode(n));
                    this.setData({
                        _indexList: i
                    });
                }
            },
            getAllRect: function() {
                var t = this;
                this.getAnchorsRect().then(function() {
                    t.groupTop.forEach(function(e, i) {
                        var n = t.groupTop[i + 1];
                        e.totalHeight = ((null == n ? void 0 : n.top) || 1 / 0) - e.top;
                    }), t.setAnchorOnScroll(0);
                }), this.getSidebarRect();
            },
            getAnchorsRect: function() {
                var t = this;
                return Promise.all(this.$children.map(function(e) {
                    return (0, a.getRect)(e, ".".concat(g, "-anchor")).then(function(i) {
                        t.groupTop.push({
                            height: i.height,
                            top: i.top,
                            anchor: e.data.index
                        });
                    });
                }));
            },
            getSidebarRect: function() {
                var t = this;
                (0, a.getRect)(this, "#id-".concat(g, "__bar")).then(function(e) {
                    var i = e.top, n = e.height, r = t.data._indexList.length;
                    t.sidebar = {
                        top: i,
                        height: n,
                        itemHeight: (n - 2 * (r - 1)) / r
                    };
                });
            },
            toggleTips: function(t) {
                var e = this;
                t ? this.setData({
                    showTips: !0
                }) : (clearInterval(this.timer), this.timer = setTimeout(function() {
                    e.setData({
                        showTips: !1
                    });
                }, 300));
            },
            setAnchorByIndex: function(t) {
                if (null == this.preIndex || this.preIndex !== t) {
                    var e = this.data._indexList[t], i = this.groupTop.find(function(t) {
                        return t.anchor === e;
                    });
                    i && wx.pageScrollTo({
                        scrollTop: i.top,
                        duration: 0
                    }), this.preIndex = t, this.toggleTips(!0), this.triggerEvent("select", {
                        index: e
                    }), e !== this.data.activeAnchor && this.triggerEvent("change", {
                        index: e
                    });
                }
            },
            onClick: function(t) {
                var e = t.currentTarget.dataset.index;
                this.setAnchorByIndex(e);
            },
            onTouchMove: function(t) {
                this.onAnchorTouch(t);
            },
            onTouchCancel: function() {
                this.toggleTips(!1);
            },
            onTouchEnd: function(t) {
                this.toggleTips(!1), this.onAnchorTouch(t);
            },
            onAnchorTouch: (0, a.throttle)(function(t) {
                var e, i, n = this, r = (e = t.changedTouches[0].clientY, (i = e - n.sidebar.top) <= 0 ? 0 : i > n.sidebar.height ? n.data._indexList.length - 1 : Math.floor(i / n.sidebar.itemHeight));
                this.setAnchorByIndex(r);
            }, 1e3 / 30),
            setAnchorOnScroll: function(t) {
                if (this.groupTop) {
                    var e = this.data, i = e.sticky, n = e.stickyOffset;
                    t += n;
                    var r = this.groupTop.findIndex(function(e) {
                        return t >= e.top - e.height && t <= e.top + e.totalHeight - e.height;
                    });
                    if (-1 !== r) {
                        var o = this.groupTop[r];
                        if (this.data.activeAnchor !== o.anchor && this.triggerEvent("change", {
                            index: o.anchor
                        }), this.setData({
                            activeAnchor: o.anchor
                        }), i) {
                            var c = o.top - t, s = c < o.height && c > 0 && t > n;
                            this.$children.forEach(function(e, i) {
                                i === r ? e.setData({
                                    sticky: t > n,
                                    active: !0,
                                    style: "height: ".concat(o.height, "px"),
                                    anchorStyle: "transform: translate3d(0, ".concat(s ? c : 0, "px, 0); top: ").concat(n, "px")
                                }) : i + 1 === r ? e.setData({
                                    sticky: !0,
                                    active: !0,
                                    style: "height: ".concat(o.height, "px"),
                                    anchorStyle: "transform: translate3d(0, ".concat(s ? c - o.height : 0, "px, 0); top: ").concat(n, "px")
                                }) : e.setData({
                                    active: !1,
                                    sticky: !1,
                                    anchorStyle: ""
                                });
                            });
                        }
                    }
                }
            },
            onScroll: function(t) {
                var e = t.scrollTop;
                this.setAnchorOnScroll(e);
            }
        }, t;
    }
    return r(n, i), t(n);
}(c.SuperComponent);

x = p([ (0, c.wxComponent)() ], x);

exports.default = x;