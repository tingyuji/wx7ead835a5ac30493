Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    indexList: {
        type: null
    },
    list: {
        type: Array,
        value: []
    },
    sticky: {
        type: Boolean,
        value: !0
    },
    stickyOffset: {
        type: Number,
        value: 0
    }
};

exports.default = e;