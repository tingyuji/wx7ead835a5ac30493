Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/classCallCheck"), t = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), u = require("../../../@babel/runtime/helpers/typeof"), c = require("../common/src/index"), l = f(require("../common/config")), i = f(require("./props"));

function f(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function s(e, r, o) {
    return r = n(r), t(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(r, o || [], n(e).constructor) : r.apply(e, o));
}

var a = function(e, r, t, n) {
    var o, c = arguments.length, l = c < 3 ? r : null === n ? n = Object.getOwnPropertyDescriptor(r, t) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : u(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(e, r, t, n); else for (var i = e.length - 1; i >= 0; i--) (o = e[i]) && (l = (c < 3 ? o(l) : c > 3 ? o(r, t, l) : o(r, t)) || l);
    return c > 3 && l && Object.defineProperty(r, t, l), l;
}, p = l.default.prefix, d = "".concat(p, "-col"), b = function(t) {
    function n() {
        var e;
        return r(this, n), (e = s(this, n, arguments)).externalClasses = [ "".concat(p, "-class") ], 
        e.properties = i.default, e.data = {
            prefix: p,
            classPrefix: d
        }, e.relations = {
            "../row/row": {
                type: "parent"
            }
        }, e;
    }
    return o(n, t), e(n);
}(c.SuperComponent);

b = a([ (0, c.wxComponent)() ], b);

exports.default = b;