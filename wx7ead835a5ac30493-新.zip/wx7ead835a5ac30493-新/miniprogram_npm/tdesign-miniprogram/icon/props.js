Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    color: {
        type: String,
        value: ""
    },
    name: {
        type: String,
        value: "",
        required: !0
    },
    size: {
        type: String,
        value: ""
    },
    prefix: {
        type: String,
        value: void 0
    }
};

exports.default = e;