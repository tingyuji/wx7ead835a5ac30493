Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0, require("../../../@babel/runtime/helpers/Arrayincludes");

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), r = require("../../../@babel/runtime/helpers/getPrototypeOf"), c = require("../../../@babel/runtime/helpers/inherits"), o = require("../../../@babel/runtime/helpers/typeof"), i = require("../common/src/index"), s = l(require("../common/config")), u = l(require("./props")), a = require("../common/utils");

function l(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, c) {
    return t = r(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, c || [], r(e).constructor) : t.apply(e, c));
}

var p = function(e, t, n, r) {
    var c, i = arguments.length, s = i < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, n) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : o(Reflect)) && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, n, r); else for (var u = e.length - 1; u >= 0; u--) (c = e[u]) && (s = (i < 3 ? c(s) : i > 3 ? c(t, n, s) : c(t, n)) || s);
    return i > 3 && s && Object.defineProperty(t, n, s), s;
}, d = s.default.prefix, h = "".concat(d, "-link"), m = function(n) {
    function r() {
        var e;
        return t(this, r), (e = f(this, r, arguments)).externalClasses = [ "".concat(d, "-class"), "".concat(d, "-class-hover"), "".concat(d, "-class-prefix-icon"), "".concat(d, "-class-content"), "".concat(d, "-class-suffix-icon") ], 
        e.properties = u.default, e.options = {
            multipleSlots: !0
        }, e.data = {
            prefix: d,
            classPrefix: h
        }, e.observers = {
            "theme, status, size, underline, navigatorProps": function() {
                this.setClass();
            },
            prefixIcon: function(e) {
                this.setData({
                    _prefixIcon: (0, a.calcIcon)(e)
                });
            },
            suffixIcon: function(e) {
                this.setData({
                    _suffixIcon: (0, a.calcIcon)(e)
                });
            }
        }, e.lifetimes = {
            attached: function() {
                this.setClass();
            }
        }, e.methods = {
            setClass: function() {
                var e = this.properties, t = e.theme, n = e.size, r = e.underline, c = e.navigatorProps, o = e.disabled, i = [ h, "".concat(h, "--").concat(t), "".concat(h, "--").concat(n) ];
                r && i.push("".concat(h, "--underline")), (c && !c.url && ![ "navigateBack", "exit" ].includes(c.openType) || o) && i.push("".concat(h, "--disabled")), 
                this.setData({
                    className: i.join(" ")
                });
            },
            onSuccess: function(e) {
                this.triggerEvent("success", e);
            },
            onFail: function(e) {
                this.triggerEvent("fail", e);
            },
            onComplete: function(e) {
                this.triggerEvent("complete", e);
            }
        }, e;
    }
    return c(r, n), e(r);
}(i.SuperComponent);

m = p([ (0, i.wxComponent)() ], m);

exports.default = m;