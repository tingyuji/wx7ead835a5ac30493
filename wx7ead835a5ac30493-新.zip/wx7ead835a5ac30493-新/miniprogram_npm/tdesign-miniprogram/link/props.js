Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    content: {
        type: String
    },
    navigatorProps: {
        type: Object
    },
    prefixIcon: {
        type: null
    },
    size: {
        type: String,
        value: "medium"
    },
    status: {
        type: String,
        value: "normal"
    },
    disabled: {
        type: Boolean,
        value: !1
    },
    hover: {
        type: Boolean,
        value: !1
    },
    suffixIcon: {
        type: null
    },
    theme: {
        type: String,
        value: "default"
    },
    underline: {
        type: Boolean
    }
};

exports.default = e;