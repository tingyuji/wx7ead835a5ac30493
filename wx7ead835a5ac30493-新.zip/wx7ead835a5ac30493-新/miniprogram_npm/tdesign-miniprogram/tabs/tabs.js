Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../../@babel/runtime/helpers/regeneratorRuntime"), e = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), i = require("../../../@babel/runtime/helpers/getPrototypeOf"), a = require("../../../@babel/runtime/helpers/inherits"), c = require("../../../@babel/runtime/helpers/typeof"), s = require("../common/src/index"), o = f(require("./props")), u = f(require("../common/config")), h = f(require("../mixins/touch")), l = require("../common/utils");

function f(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function d(t, e, n) {
    return e = i(e), r(t, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (t) {
            return !1;
        }
    }() ? Reflect.construct(e, n || [], i(t).constructor) : e.apply(t, n));
}

var p = function(t, e, n, r) {
    var i, a = arguments.length, s = a < 3 ? e : null === r ? r = Object.getOwnPropertyDescriptor(e, n) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : c(Reflect)) && "function" == typeof Reflect.decorate) s = Reflect.decorate(t, e, n, r); else for (var o = t.length - 1; o >= 0; o--) (i = t[o]) && (s = (a < 3 ? i(s) : a > 3 ? i(e, n, s) : i(e, n)) || s);
    return a > 3 && s && Object.defineProperty(e, n, s), s;
}, b = function(t, e, n, r) {
    return new (n || (n = Promise))(function(i, a) {
        function c(t) {
            try {
                o(r.next(t));
            } catch (t) {
                a(t);
            }
        }
        function s(t) {
            try {
                o(r.throw(t));
            } catch (t) {
                a(t);
            }
        }
        function o(t) {
            var e;
            t.done ? i(t.value) : (e = t.value, e instanceof n ? e : new n(function(t) {
                t(e);
            })).then(c, s);
        }
        o((r = r.apply(t, e || [])).next());
    });
}, v = u.default.prefix, x = "".concat(v, "-tabs"), m = (0, l.uniqueFactory)("tabs"), g = function(r) {
    function i() {
        var n;
        return e(this, i), (n = d(this, i, arguments)).behaviors = [ h.default ], n.externalClasses = [ "".concat(v, "-class"), "".concat(v, "-class-item"), "".concat(v, "-class-active"), "".concat(v, "-class-track"), "".concat(v, "-class-content") ], 
        n.relations = {
            "../tab-panel/tab-panel": {
                type: "descendant",
                linked: function(t) {
                    this.children.push(t), this.initChildId(), t.index = this.children.length - 1, this.updateTabs();
                },
                unlinked: function(t) {
                    var e = this;
                    this.children = this.children.filter(function(e) {
                        return e.index !== t.index;
                    }), this.updateTabs(function() {
                        return e.setTrack();
                    }), this.initChildId();
                }
            }
        }, n.properties = o.default, n.controlledProps = [ {
            key: "value",
            event: "change"
        } ], n.observers = {
            value: function(t) {
                t !== this.getCurrentName() && this.setCurrentIndexByName(t);
            }
        }, n.data = {
            prefix: v,
            classPrefix: x,
            tabs: [],
            currentIndex: -1,
            trackStyle: "",
            offset: 0,
            scrollLeft: 0,
            tabID: "",
            placement: "top"
        }, n.lifetimes = {
            created: function() {
                this.children = this.children || [];
            },
            attached: function() {
                var t = this;
                wx.nextTick(function() {
                    t.setTrack();
                }), (0, l.getRect)(this, ".".concat(x)).then(function(e) {
                    t.containerWidth = e.width;
                }), this.setData({
                    tabID: m()
                });
            }
        }, n.methods = {
            onScroll: function(t) {
                var e = t.detail.scrollLeft;
                this.setData({
                    scrollLeft: e
                });
            },
            updateTabs: function(t) {
                var e = this.children.map(function(t) {
                    return t.data;
                });
                e.forEach(function(t) {
                    "string" == typeof t.icon && (t.icon = {
                        name: t.icon
                    });
                }), this.setData({
                    tabs: e
                }, t), this.setCurrentIndexByName(this.properties.value);
            },
            setCurrentIndexByName: function(t) {
                var e = this.children.findIndex(function(e) {
                    return e.getComputedName() === "".concat(t);
                });
                e > -1 && this.setCurrentIndex(e);
            },
            setCurrentIndex: function(t) {
                var e = this;
                t <= -1 || t >= this.children.length || (this.children.forEach(function(n, r) {
                    var i = t === r;
                    i !== n.data.active && n.render(i, e);
                }), this.data.currentIndex !== t && (this.setData({
                    currentIndex: t
                }), this.setTrack()));
            },
            getCurrentName: function() {
                if (this.children) {
                    var t = this.children[this.data.currentIndex];
                    if (t) return t.getComputedName();
                }
            },
            calcScrollOffset: function(t, e, n, r) {
                return r + e - .5 * t + n / 2;
            },
            getTrackSize: function() {
                var t = this;
                return new Promise(function(e, n) {
                    t.trackWidth ? e(t.trackWidth) : (0, l.getRect)(t, ".".concat(v, "-tabs__track")).then(function(n) {
                        n && (t.trackWidth = n.width, e(t.trackWidth));
                    }).catch(n);
                });
            },
            setTrack: function() {
                return b(this, void 0, void 0, t().mark(function e() {
                    var n, r, i, a, c, s, o, u, h;
                    return t().wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            if (this.properties.showBottomLine) {
                                t.next = 2;
                                break;
                            }
                            return t.abrupt("return");

                          case 2:
                            if (this.children) {
                                t.next = 5;
                                break;
                            }
                            return t.abrupt("return");

                          case 5:
                            if (!((n = this.data.currentIndex) <= -1)) {
                                t.next = 8;
                                break;
                            }
                            return t.abrupt("return");

                          case 8:
                            return t.prev = 8, t.next = 11, (0, l.getRect)(this, ".".concat(v, "-tabs__item"), !0);

                          case 11:
                            if (r = t.sent, i = r[n]) {
                                t.next = 15;
                                break;
                            }
                            return t.abrupt("return");

                          case 15:
                            if (a = 0, c = 0, s = 0, r.forEach(function(t) {
                                a < n && (c += t.width, a += 1), s += t.width;
                            }), this.containerWidth && (o = this.calcScrollOffset(this.containerWidth, i.left, i.width, this.data.scrollLeft), 
                            u = s - this.containerWidth, this.setData({
                                offset: Math.min(Math.max(o, 0), u)
                            })), "line" !== this.data.theme) {
                                t.next = 25;
                                break;
                            }
                            return t.next = 23, this.getTrackSize();

                          case 23:
                            h = t.sent, c += (i.width - h) / 2;

                          case 25:
                            this.setData({
                                trackStyle: "-webkit-transform: translateX(".concat(c, "px);\n            transform: translateX(").concat(c, "px);\n          ")
                            }), t.next = 31;
                            break;

                          case 28:
                            t.prev = 28, t.t0 = t.catch(8), this.triggerEvent("error", t.t0);

                          case 31:
                          case "end":
                            return t.stop();
                        }
                    }, e, this, [ [ 8, 28 ] ]);
                }));
            },
            onTabTap: function(t) {
                var e = t.currentTarget.dataset.index;
                this.changeIndex(e);
            },
            onTouchStart: function(t) {
                this.properties.swipeable && this.touchStart(t);
            },
            onTouchMove: function(t) {
                this.properties.swipeable && this.touchMove(t);
            },
            onTouchEnd: function() {
                if (this.properties.swipeable) {
                    var t = this.direction, e = this.deltaX, n = this.offsetX;
                    if ("horizontal" === t && n >= 50) {
                        var r = this.getAvailableTabIndex(e);
                        -1 !== r && this.changeIndex(r);
                    }
                }
            },
            onTouchScroll: function(t) {
                this._trigger("scroll", t.detail);
            },
            changeIndex: function(t) {
                var e = this.data.tabs[t], n = e.value, r = e.label;
                (null == e ? void 0 : e.disabled) || t === this.data.currentIndex || this._trigger("change", {
                    value: n,
                    label: r
                }), this._trigger("click", {
                    value: n,
                    label: r
                });
            },
            getAvailableTabIndex: function(t) {
                for (var e = t > 0 ? -1 : 1, n = this.data, r = n.currentIndex, i = n.tabs, a = i.length, c = e; r + e >= 0 && r + e < a; c += e) {
                    var s = r + c;
                    if (s >= 0 && s < a && i[s] && !i[s].disabled) return s;
                }
                return -1;
            }
        }, n;
    }
    return a(i, r), n(i, [ {
        key: "initChildId",
        value: function() {
            var t = this;
            this.children.forEach(function(e, n) {
                e.setId("".concat(t.data.tabID, "_panel_").concat(n));
            });
        }
    } ]);
}(s.SuperComponent);

g = p([ (0, s.wxComponent)() ], g);

exports.default = g;