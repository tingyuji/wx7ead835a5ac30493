Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/defineProperty"), t = require("../../../@babel/runtime/helpers/toConsumableArray"), n = require("../../../@babel/runtime/helpers/regeneratorRuntime"), l = require("../../../@babel/runtime/helpers/createClass"), i = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), s = require("../../../@babel/runtime/helpers/getPrototypeOf"), a = require("../../../@babel/runtime/helpers/inherits"), o = require("../../../@babel/runtime/helpers/typeof"), u = require("../common/src/index"), c = v(require("../common/config")), d = v(require("./props")), h = require("../common/utils");

function v(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, n) {
    return t = s(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, n || [], s(e).constructor) : t.apply(e, n));
}

var p = function(e, t, n, l) {
    var i, r = arguments.length, s = r < 3 ? t : null === l ? l = Object.getOwnPropertyDescriptor(t, n) : l;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : o(Reflect)) && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, n, l); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (s = (r < 3 ? i(s) : r > 3 ? i(t, n, s) : i(t, n)) || s);
    return r > 3 && s && Object.defineProperty(t, n, s), s;
}, b = function(e, t, n, l) {
    return new (n || (n = Promise))(function(i, r) {
        function s(e) {
            try {
                o(l.next(e));
            } catch (e) {
                r(e);
            }
        }
        function a(e) {
            try {
                o(l.throw(e));
            } catch (e) {
                r(e);
            }
        }
        function o(e) {
            var t;
            e.done ? i(e.value) : (t = e.value, t instanceof n ? t : new n(function(e) {
                e(t);
            })).then(s, a);
        }
        o((l = l.apply(e, t || [])).next());
    });
}, g = c.default.prefix, x = "".concat(g, "-cascader"), m = function(r) {
    function s() {
        var l;
        return i(this, s), (l = f(this, s, arguments)).externalClasses = [ "".concat(g, "-class") ], 
        l.options = {
            multipleSlots: !0
        }, l.properties = d.default, l.controlledProps = [ {
            key: "value",
            event: "change"
        } ], l.data = {
            prefix: g,
            name: x,
            stepIndex: 0,
            selectedIndexes: [],
            selectedValue: [],
            defaultOptionLabel: "选择选项",
            scrollTopList: [],
            steps: [ "选择选项" ]
        }, l.observers = {
            visible: function(e) {
                if (e) {
                    var t = this.selectComponent("#tabs");
                    null == t || t.setTrack(), this.updateScrollTop(), this.initWithValue();
                }
            },
            "selectedIndexes, options": function() {
                var e, t, n, l, i = this.data, r = i.options, s = i.selectedIndexes, a = i.keys, o = [], u = [], c = [ r ];
                if (r.length > 0) for (var d = 0, h = s.length; d < h; d += 1) {
                    var v = s[d], f = c[d][v];
                    o.push(f[null !== (e = null == a ? void 0 : a.value) && void 0 !== e ? e : "value"]), 
                    u.push(f[null !== (t = null == a ? void 0 : a.label) && void 0 !== t ? t : "label"]), 
                    f[null !== (n = null == a ? void 0 : a.children) && void 0 !== n ? n : "children"] && c.push(f[null !== (l = null == a ? void 0 : a.children) && void 0 !== l ? l : "children"]);
                }
                u.length < c.length && u.push("选择选项"), this.setData({
                    steps: u,
                    items: c,
                    selectedValue: o,
                    stepIndex: c.length - 1
                });
            },
            stepIndex: function() {
                return b(this, void 0, void 0, n().mark(function e() {
                    return n().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            this.data.visible && this.updateScrollTop();

                          case 2:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
            }
        }, l.methods = {
            initWithValue: function() {
                if (null != this.data.value && "" !== this.data.value) {
                    var e = this.getIndexesByValue(this.data.options, this.data.value);
                    e && this.setData({
                        selectedIndexes: e
                    });
                } else this.setData({
                    selectedIndexes: []
                });
            },
            getIndexesByValue: function(e, n) {
                for (var l, i, r, s = this.data.keys, a = 0, o = e.length; a < o; a += 1) {
                    var u = e[a];
                    if (u[null !== (l = null == s ? void 0 : s.value) && void 0 !== l ? l : "value"] === n) return [ a ];
                    if (u[null !== (i = null == s ? void 0 : s.children) && void 0 !== i ? i : "children"]) {
                        var c = this.getIndexesByValue(u[null !== (r = null == s ? void 0 : s.children) && void 0 !== r ? r : "children"], n);
                        if (c) return [ a ].concat(t(c));
                    }
                }
            },
            updateScrollTop: function() {
                var t = this, n = this.data, l = n.visible, i = n.items, r = n.selectedIndexes, s = n.stepIndex;
                l && (0, h.getRect)(this, ".cascader-radio-group-0").then(function(n) {
                    var l, a = n.height / (null === (l = i[0]) || void 0 === l ? void 0 : l.length);
                    t.setData(e({}, "scrollTopList[".concat(s, "]"), a * r[s]));
                });
            },
            hide: function(e) {
                this.setData({
                    visible: !1
                }), this.triggerEvent("close", {
                    trigger: e
                });
            },
            onVisibleChange: function() {
                this.hide("overlay");
            },
            onClose: function() {
                this.hide("close-btn");
            },
            onStepClick: function(e) {
                var t = e.currentTarget.dataset.index;
                this.setData({
                    stepIndex: t
                });
            },
            onTabChange: function(e) {
                var t = e.detail.value;
                this.setData({
                    stepIndex: t
                });
            },
            handleSelect: function(e) {
                var t, n, l, i = this, r = e.target.dataset.level, s = e.detail.value, a = this.data, o = a.selectedIndexes, u = a.items, c = a.keys, d = u[r].findIndex(function(e) {
                    var t;
                    return e[null !== (t = null == c ? void 0 : c.value) && void 0 !== t ? t : "value"] === s;
                }), h = u[r][d];
                h.disabled || (o[r] = d, o.length = r + 1, this.triggerEvent("pick", {
                    value: h[null !== (t = null == c ? void 0 : c.value) && void 0 !== t ? t : "value"],
                    index: d,
                    level: r
                }), (null === (l = null == h ? void 0 : h[null !== (n = null == c ? void 0 : c.children) && void 0 !== n ? n : "children"]) || void 0 === l ? void 0 : l.length) ? this.setData({
                    selectedIndexes: o
                }) : (this.setData({
                    selectedIndexes: o
                }, function() {
                    var e, t = i.data.items;
                    i._trigger("change", {
                        value: h[null !== (e = null == c ? void 0 : c.value) && void 0 !== e ? e : "value"],
                        selectedOptions: t.map(function(e, t) {
                            return e[o[t]];
                        })
                    });
                }), this.hide("finish")));
            }
        }, l;
    }
    return a(s, r), l(s);
}(u.SuperComponent);

m = p([ (0, u.wxComponent)() ], m);

exports.default = m;