Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    closeBtn: {
        type: Boolean,
        value: !0
    },
    keys: {
        type: Object
    },
    options: {
        type: Array,
        value: []
    },
    subTitles: {
        type: Array,
        value: []
    },
    theme: {
        type: String,
        value: "step"
    },
    title: {
        type: String
    },
    value: {
        type: null,
        value: null
    },
    defaultValue: {
        type: null,
        value: null
    },
    visible: {
        type: Boolean,
        value: !1
    }
};

exports.default = e;