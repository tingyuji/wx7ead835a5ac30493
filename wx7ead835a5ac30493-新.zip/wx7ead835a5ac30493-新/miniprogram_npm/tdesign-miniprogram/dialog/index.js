Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e, t = require("../../../@babel/runtime/helpers/typeof"), n = (e = require("./props")) && e.__esModule ? e : {
    default: e
}, o = require("../common/utils");

var r = function(e, t) {
    var n = {};
    for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && t.indexOf(o) < 0 && (n[o] = e[o]);
    if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
        var r = 0;
        for (o = Object.getOwnPropertySymbols(e); r < o.length; r++) t.indexOf(o[r]) < 0 && Object.prototype.propertyIsEnumerable.call(e, o[r]) && (n[o[r]] = e[o[r]]);
    }
    return n;
}, c = {
    actions: [],
    buttonLayout: n.default.buttonLayout.value,
    cancelBtn: n.default.cancelBtn.value,
    closeOnOverlayClick: n.default.closeOnOverlayClick.value,
    confirmBtn: n.default.confirmBtn.value,
    content: "",
    preventScrollThrough: n.default.preventScrollThrough.value,
    showOverlay: n.default.showOverlay.value,
    title: "",
    visible: n.default.visible.value
};

exports.default = {
    alert: function(e) {
        var t = Object.assign(Object.assign({}, c), e), n = t.context, a = t.selector, i = void 0 === a ? "#t-dialog" : a, s = r(t, [ "context", "selector" ]), l = (0, 
        o.getInstance)(n, i);
        return l ? new Promise(function(e) {
            l.setData(Object.assign(Object.assign({
                cancelBtn: ""
            }, s), {
                visible: !0
            })), l._onConfirm = e;
        }) : Promise.reject();
    },
    confirm: function(e) {
        var t = Object.assign(Object.assign({}, c), e), n = t.context, a = t.selector, i = void 0 === a ? "#t-dialog" : a, s = r(t, [ "context", "selector" ]), l = (0, 
        o.getInstance)(n, i);
        return l ? new Promise(function(e, t) {
            l.setData(Object.assign(Object.assign({}, s), {
                visible: !0
            })), l._onConfirm = e, l._onCancel = t;
        }) : Promise.reject();
    },
    close: function(e) {
        var t = Object.assign({}, e), n = t.context, r = t.selector, c = void 0 === r ? "#t-dialog" : r, a = (0, 
        o.getInstance)(n, c);
        return a ? (a.close(), Promise.resolve()) : Promise.reject();
    },
    action: function(e) {
        var n = Object.assign(Object.assign({}, c), e), a = n.context, i = n.selector, s = void 0 === i ? "#t-dialog" : i, l = n.actions, u = r(n, [ "context", "selector", "actions" ]), v = (0, 
        o.getInstance)(a, s);
        if (!v) return Promise.reject();
        var b = e.buttonLayout, f = void 0 === b ? "vertical" : b, O = "vertical" === f ? 7 : 3;
        return (!l || "object" === t(l) && (0 === l.length || l.length > O)) && console.warn("action 数量建议控制在1至".concat(O, "个")), 
        new Promise(function(e) {
            v.setData(Object.assign(Object.assign({
                actions: l
            }, u), {
                buttonLayout: f,
                visible: !0
            })), v._onAction = e;
        });
    }
};