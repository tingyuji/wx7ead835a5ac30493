Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), u = require("../../../@babel/runtime/helpers/typeof"), c = require("../common/src/index"), l = i(require("../common/config")), a = i(require("./props"));

function i(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function s(e, t, o) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, o || [], n(e).constructor) : t.apply(e, o));
}

var p = function(e, t, r, n) {
    var o, c = arguments.length, l = c < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : u(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(e, t, r, n); else for (var a = e.length - 1; a >= 0; a--) (o = e[a]) && (l = (c < 3 ? o(l) : c > 3 ? o(t, r, l) : o(t, r)) || l);
    return c > 3 && l && Object.defineProperty(t, r, l), l;
}, f = l.default.prefix, d = "".concat(f, "-collapse"), h = function(r) {
    function n() {
        var e;
        return t(this, n), (e = s(this, n, arguments)).options = {
            addGlobalClass: !0
        }, e.externalClasses = [ "".concat(f, "-class") ], e.relations = {
            "../collapse-panel/collapse-panel": {
                type: "descendant"
            }
        }, e.controlledProps = [ {
            key: "value",
            event: "change"
        } ], e.properties = a.default, e.data = {
            prefix: f,
            classPrefix: d
        }, e.observers = {
            "value, expandMutex ": function() {
                this.updateExpanded();
            }
        }, e.methods = {
            updateExpanded: function() {
                var e = this;
                this.$children.forEach(function(t) {
                    t.updateExpanded(e.properties.value);
                });
            },
            switch: function(e) {
                var t = this.properties, r = t.expandMutex, n = t.value, o = [];
                o = n.indexOf(e) > -1 ? n.filter(function(t) {
                    return t !== e;
                }) : r ? [ e ] : n.concat(e), this._trigger("change", {
                    value: o
                });
            }
        }, e;
    }
    return o(n, r), e(n);
}(c.SuperComponent);

h = p([ (0, c.wxComponent)() ], h);

exports.default = h;