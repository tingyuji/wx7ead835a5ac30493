Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    disabled: {
        type: Boolean
    },
    left: {
        type: Array
    },
    opened: {
        type: null,
        value: !1
    },
    right: {
        type: Array
    },
    style: {
        type: String,
        value: ""
    }
};

exports.default = e;