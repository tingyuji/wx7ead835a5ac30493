Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/slicedToArray"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/createClass"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), i = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), c = require("../../../@babel/runtime/helpers/typeof"), u = require("../common/src/index"), s = h(require("../common/config")), l = h(require("./props")), a = require("../common/utils"), f = require("../common/wechat");

function h(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function p(e, t, r) {
    return t = i(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, r || [], i(e).constructor) : t.apply(e, r));
}

var d = function(e, t, r, n) {
    var i, o = arguments.length, u = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : c(Reflect)) && "function" == typeof Reflect.decorate) u = Reflect.decorate(e, t, r, n); else for (var s = e.length - 1; s >= 0; s--) (i = e[s]) && (u = (o < 3 ? i(u) : o > 3 ? i(t, r, u) : i(t, r)) || u);
    return o > 3 && u && Object.defineProperty(t, r, u), u;
}, v = [], b = s.default.prefix, y = "".concat(b, "-swipe-cell"), m = ".".concat(y), g = function(n) {
    function i() {
        var e;
        return t(this, i), (e = p(this, i, arguments)).externalClasses = [ "".concat(b, "-class") ], 
        e.options = {
            multipleSlots: !0
        }, e.properties = l.default, e.data = {
            prefix: b,
            wrapperStyle: "",
            closed: !0,
            classPrefix: y
        }, e.observers = {
            "left, right": function() {
                this.setSwipeWidth();
            }
        }, e.lifetimes = {
            attached: function() {
                v.push(this);
            },
            ready: function() {
                this.setSwipeWidth();
            },
            detached: function() {
                var e = this;
                v = v.filter(function(t) {
                    return t !== e;
                });
            }
        }, e;
    }
    return o(i, n), r(i, [ {
        key: "setSwipeWidth",
        value: function() {
            var t = this;
            Promise.all([ (0, a.getRect)(this, "".concat(m, "__left")), (0, a.getRect)(this, "".concat(m, "__right")) ]).then(function(r) {
                var n = e(r, 2), i = n[0], o = n[1];
                0 !== i.width || 0 !== o.width || t._hasObserved || (t._hasObserved = !0, (0, f.getObserver)(t, ".".concat(y)).then(function() {
                    t.setSwipeWidth();
                })), t.setData({
                    leftWidth: i.width,
                    rightWidth: o.width
                });
            });
        }
    }, {
        key: "open",
        value: function() {
            this.setData({
                opened: !0
            }), this.triggerEvent("openSuccess");
        }
    }, {
        key: "close",
        value: function() {
            this.setData({
                opened: !1
            }), this.triggerEvent("closeSuccess");
        }
    }, {
        key: "closeOther",
        value: function() {
            var e = this;
            v.filter(function(t) {
                return t !== e;
            }).forEach(function(e) {
                return e.close();
            });
        }
    }, {
        key: "onTap",
        value: function() {
            this.triggerEvent("onTap");
        }
    }, {
        key: "onActionTap",
        value: function(e) {
            var t = e.currentTarget.dataset.action;
            this.triggerEvent("click", t);
        }
    } ]);
}(u.SuperComponent);

g = d([ (0, u.wxComponent)() ], g);

exports.default = g;