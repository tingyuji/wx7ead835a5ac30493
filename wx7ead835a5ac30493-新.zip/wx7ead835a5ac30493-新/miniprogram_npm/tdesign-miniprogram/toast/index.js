Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = o, exports.hideToast = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = e.context, n = e.selector, r = void 0 === n ? "#t-toast" : n, s = (0, 
    t.getInstance)(o, r);
    s && s.hide();
}, exports.showToast = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    o(t);
};

var t = require("../common/utils"), e = function(t, e) {
    var o = {};
    for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && e.indexOf(n) < 0 && (o[n] = t[n]);
    if (null != t && "function" == typeof Object.getOwnPropertySymbols) {
        var r = 0;
        for (n = Object.getOwnPropertySymbols(t); r < n.length; r++) e.indexOf(n[r]) < 0 && Object.prototype.propertyIsEnumerable.call(t, n[r]) && (o[n[r]] = t[n[r]]);
    }
    return o;
};

function o(o) {
    var n, r = o.context, s = o.selector, c = void 0 === s ? "#t-toast" : s, i = e(o, [ "context", "selector" ]), a = (0, 
    t.getInstance)(r, c);
    a && a.show(Object.assign(Object.assign({}, i), {
        duration: null !== (n = i.duration) && void 0 !== n ? n : 2e3
    }));
}