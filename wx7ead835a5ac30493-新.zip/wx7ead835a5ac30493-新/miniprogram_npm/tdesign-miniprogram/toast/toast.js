Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), i = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), r = require("../../../@babel/runtime/helpers/getPrototypeOf"), n = require("../../../@babel/runtime/helpers/inherits"), o = require("../../../@babel/runtime/helpers/typeof"), l = require("../common/src/index"), u = d(require("../common/config")), c = d(require("./props")), s = d(require("../mixins/transition")), a = require("../common/utils");

function d(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, n) {
    return t = r(t), i(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, n || [], r(e).constructor) : t.apply(e, n));
}

var h = function(e, t, i, r) {
    var n, l = arguments.length, u = l < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : o(Reflect)) && "function" == typeof Reflect.decorate) u = Reflect.decorate(e, t, i, r); else for (var c = e.length - 1; c >= 0; c--) (n = e[c]) && (u = (l < 3 ? n(u) : l > 3 ? n(t, i, u) : n(t, i)) || u);
    return l > 3 && u && Object.defineProperty(t, i, u), u;
}, p = u.default.prefix, m = "".concat(p, "-toast"), v = function(i) {
    function r() {
        var e;
        return t(this, r), (e = f(this, r, arguments)).externalClasses = [ "".concat(p, "-class") ], 
        e.options = {
            multipleSlots: !0
        }, e.behaviors = [ (0, s.default)() ], e.hideTimer = null, e.data = {
            prefix: p,
            classPrefix: m,
            typeMapIcon: ""
        }, e.properties = c.default, e.lifetimes = {
            detached: function() {
                this.destroyed();
            }
        }, e.pageLifetimes = {
            hide: function() {
                this.hide();
            }
        }, e.methods = {
            show: function(e) {
                var t = this;
                this.hideTimer && clearTimeout(this.hideTimer);
                var i = {
                    loading: "loading",
                    success: "check-circle",
                    warning: "error-circle",
                    error: "close-circle"
                }[null == e ? void 0 : e.theme], r = {
                    direction: c.default.direction.value,
                    duration: c.default.duration.value,
                    icon: c.default.icon.value,
                    message: c.default.message.value,
                    placement: c.default.placement.value,
                    preventScrollThrough: c.default.preventScrollThrough.value,
                    theme: c.default.theme.value
                }, n = Object.assign(Object.assign(Object.assign({}, r), e), {
                    visible: !0,
                    isLoading: "loading" === (null == e ? void 0 : e.theme),
                    _icon: (0, a.calcIcon)(null != i ? i : e.icon)
                }), o = n.duration;
                this.setData(n), o > 0 && (this.hideTimer = setTimeout(function() {
                    t.hide();
                }, o));
            },
            hide: function() {
                var e, t;
                this.data.visible && (this.setData({
                    visible: !1
                }), null === (t = null === (e = this.data) || void 0 === e ? void 0 : e.close) || void 0 === t || t.call(e), 
                this.triggerEvent("close"));
            },
            destroyed: function() {
                this.hideTimer && (clearTimeout(this.hideTimer), this.hideTimer = null), this.triggerEvent("destory");
            },
            loop: function() {}
        }, e;
    }
    return n(r, i), e(r);
}(l.SuperComponent);

v = h([ (0, l.wxComponent)() ], v);

exports.default = v;