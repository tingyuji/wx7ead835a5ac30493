Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    direction: {
        type: String,
        value: "row"
    },
    duration: {
        type: Number,
        value: 2e3
    },
    externalClasses: {
        type: Array
    },
    icon: {
        type: null
    },
    message: {
        type: String
    },
    overlayProps: {
        type: Object,
        value: {}
    },
    placement: {
        type: String,
        value: "middle"
    },
    preventScrollThrough: {
        type: Boolean,
        value: !1
    },
    showOverlay: {
        type: Boolean,
        value: !1
    },
    theme: {
        type: String
    }
};

exports.default = e;