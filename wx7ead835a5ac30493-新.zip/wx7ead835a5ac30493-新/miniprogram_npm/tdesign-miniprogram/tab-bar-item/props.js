Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    badgeProps: {
        type: Object
    },
    icon: {
        type: null
    },
    subTabBar: {
        type: Array
    },
    value: {
        type: null
    }
};

exports.default = e;