Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), a = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), s = require("../../../@babel/runtime/helpers/typeof"), o = require("../common/src/index"), c = p(require("../common/config")), u = p(require("./props")), l = require("../common/utils");

function p(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, r) {
    return t = a(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, r || [], a(e).constructor) : t.apply(e, r));
}

var h = function(e, t, r, n) {
    var a, i = arguments.length, o = i < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : s(Reflect)) && "function" == typeof Reflect.decorate) o = Reflect.decorate(e, t, r, n); else for (var c = e.length - 1; c >= 0; c--) (a = e[c]) && (o = (i < 3 ? a(o) : i > 3 ? a(t, r, o) : a(t, r)) || o);
    return i > 3 && o && Object.defineProperty(t, r, o), o;
}, d = function(e, t, r, n) {
    return new (r || (r = Promise))(function(a, i) {
        function s(e) {
            try {
                c(n.next(e));
            } catch (e) {
                i(e);
            }
        }
        function o(e) {
            try {
                c(n.throw(e));
            } catch (e) {
                i(e);
            }
        }
        function c(e) {
            var t;
            e.done ? a(e.value) : (t = e.value, t instanceof r ? t : new r(function(e) {
                e(t);
            })).then(s, o);
        }
        c((n = n.apply(e, t || [])).next());
    });
}, m = c.default.prefix, b = "".concat(m, "-tab-bar-item"), v = function(n) {
    function a() {
        var t;
        return r(this, a), (t = f(this, a, arguments)).externalClasses = [ "".concat(m, "-class") ], 
        t.parent = null, t.relations = {
            "../tab-bar/tab-bar": {
                type: "ancestor",
                linked: function(e) {
                    var t = e.data, r = t.theme, n = t.split, a = t.shape;
                    this.setData({
                        theme: r,
                        split: n,
                        shape: a,
                        currentName: this.properties.value ? this.properties.value : e.initName()
                    }), e.updateChildren();
                }
            }
        }, t.options = {
            multipleSlots: !0
        }, t.data = {
            prefix: m,
            classPrefix: b,
            isSpread: !1,
            isChecked: !1,
            hasChildren: !1,
            currentName: "",
            split: !0,
            iconOnly: !1,
            theme: "",
            crowded: !1,
            shape: "normal"
        }, t.properties = u.default, t.observers = {
            subTabBar: function(e) {
                this.setData({
                    hasChildren: e.length > 0
                });
            },
            icon: function(e) {
                this.setData({
                    _icon: (0, l.calcIcon)(e)
                });
            }
        }, t.lifetimes = {
            attached: function() {
                return d(this, void 0, void 0, e().mark(function t() {
                    var r;
                    return e().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.next = 2, (0, l.getRect)(this, ".".concat(b, "__text"));

                          case 2:
                            r = e.sent, this.setData({
                                iconOnly: 0 === r.height
                            });

                          case 4:
                          case "end":
                            return e.stop();
                        }
                    }, t, this);
                }));
            }
        }, t.methods = {
            showSpread: function() {
                this.setData({
                    isSpread: !0
                });
            },
            toggle: function() {
                var e = this.data, t = e.currentName, r = e.hasChildren, n = e.isSpread;
                r && this.setData({
                    isSpread: !n
                }), this.$parent.updateValue(t), this.$parent.changeOtherSpread(t);
            },
            selectChild: function(e) {
                var t = e.target.dataset.value;
                this.$parent.updateValue(t), this.setData({
                    isSpread: !1
                });
            },
            checkActive: function(e) {
                var t = this.data, r = t.currentName, n = t.subTabBar, a = (null == n ? void 0 : n.some(function(t) {
                    return t.value === e;
                })) || r === e;
                this.setData({
                    isChecked: a
                });
            },
            closeSpread: function() {
                this.setData({
                    isSpread: !1
                });
            }
        }, t;
    }
    return i(a, n), t(a);
}(o.SuperComponent);

v = h([ (0, o.wxComponent)() ], v);

exports.default = v;