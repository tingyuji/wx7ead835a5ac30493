Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/slicedToArray"), t = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), i = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), c = require("../../../@babel/runtime/helpers/typeof"), s = require("../common/src/index"), a = f(require("../common/config")), u = f(require("./props")), l = require("../common/utils");

function f(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function h(e, t, r) {
    return t = i(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, r || [], i(e).constructor) : t.apply(e, r));
}

var p = function(e, t, r, n) {
    var i, o = arguments.length, s = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : c(Reflect)) && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, n); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (s = (o < 3 ? i(s) : o > 3 ? i(t, r, s) : i(t, r)) || s);
    return o > 3 && s && Object.defineProperty(t, r, s), s;
}, d = a.default.prefix, v = "".concat(d, "-rate"), b = function(n) {
    function i() {
        var t;
        return r(this, i), (t = h(this, i, arguments)).externalClasses = [ "".concat(d, "-class"), "".concat(d, "-class-icon"), "".concat(d, "-class-text") ], 
        t.properties = u.default, t.controlledProps = [ {
            key: "value",
            event: "change"
        } ], t.data = {
            prefix: d,
            classPrefix: v,
            defaultTexts: [ "极差", "失望", "一般", "满意", "惊喜" ],
            tipsVisible: !1,
            tipsLeft: 0,
            actionType: "",
            scaleIndex: -1,
            isVisibleToScreenReader: !1
        }, t.methods = {
            onTouch: function(t, r) {
                var n = this, i = this.properties, o = i.count, c = i.allowHalf, s = i.gap, a = i.value, u = i.size, f = e(t.changedTouches, 1)[0], h = (0, 
                l.unitConvert)(s);
                (0, l.getRect)(this, ".".concat(v, "__wrapper")).then(function(e) {
                    var t = e.width, i = e.left, p = (t - (o - 1) * h) / o, d = (f.pageX - i + h) / (p + h), v = d % 1, b = d - v, T = v <= .5 && c ? b + .5 : b + 1;
                    if (T > o ? T = o : T < 0 && (T = 0), "move" === r || "tap" === r && c) {
                        var m = Math.ceil(T - 1) * ((0, l.unitConvert)(s) + (0, l.unitConvert)(u)) + .5 * (0, 
                        l.unitConvert)(u);
                        n.setData({
                            tipsVisible: !0,
                            actionType: r,
                            scaleIndex: Math.ceil(T),
                            tipsLeft: Math.max(m, 0)
                        });
                    }
                    T !== a && n._trigger("change", {
                        value: T
                    }), n.touchEnd && n.hideTips();
                });
            },
            onTap: function(e) {
                this.onTouch(e, "tap");
            },
            onTouchStart: function() {
                this.touchEnd = !1;
            },
            onTouchMove: function(e) {
                this.onTouch(e, "move"), this.showAlertText();
            },
            onTouchEnd: function() {
                this.touchEnd = !0, this.hideTips();
            },
            hideTips: function() {
                "move" === this.data.actionType && this.setData({
                    tipsVisible: !1,
                    scaleIndex: -1
                });
            },
            onSelect: function(e) {
                var t = this, r = e.currentTarget.dataset.value;
                "move" !== this.data.actionType && (this._trigger("change", {
                    value: r
                }), setTimeout(function() {
                    return t.setData({
                        tipsVisible: !1,
                        scaleIndex: -1
                    });
                }, 300));
            },
            showAlertText: function() {
                var e = this;
                !0 !== this.data.isVisibleToScreenReader && (this.setData({
                    isVisibleToScreenReader: !0
                }), setTimeout(function() {
                    e.setData({
                        isVisibleToScreenReader: !1
                    });
                }, 2e3));
            }
        }, t;
    }
    return o(i, n), t(i);
}(s.SuperComponent);

b = p([ (0, s.wxComponent)() ], b);

exports.default = b;