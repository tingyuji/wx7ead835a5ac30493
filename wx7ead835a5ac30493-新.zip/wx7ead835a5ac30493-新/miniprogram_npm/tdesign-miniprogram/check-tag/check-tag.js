Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), c = require("../../../@babel/runtime/helpers/getPrototypeOf"), n = require("../../../@babel/runtime/helpers/inherits"), o = require("../../../@babel/runtime/helpers/typeof"), s = require("../common/src/index"), i = u(require("../common/config")), a = u(require("./props")), l = require("../common/utils");

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, n) {
    return t = c(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, n || [], c(e).constructor) : t.apply(e, n));
}

var d = function(e, t, r, c) {
    var n, s = arguments.length, i = s < 3 ? t : null === c ? c = Object.getOwnPropertyDescriptor(t, r) : c;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : o(Reflect)) && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, r, c); else for (var a = e.length - 1; a >= 0; a--) (n = e[a]) && (i = (s < 3 ? n(i) : s > 3 ? n(t, r, i) : n(t, r)) || i);
    return s > 3 && i && Object.defineProperty(t, r, i), i;
}, p = i.default.prefix, h = "".concat(p, "-tag"), b = function(r) {
    function c() {
        var e;
        return t(this, c), (e = f(this, c, arguments)).data = {
            prefix: p,
            classPrefix: h,
            className: ""
        }, e.properties = a.default, e.externalClasses = [ "".concat(p, "-class") ], e.controlledProps = [ {
            key: "checked",
            event: "change"
        } ], e.options = {
            multipleSlots: !0
        }, e.lifetimes = {
            attached: function() {
                this.setClass();
            }
        }, e.observers = {
            "size, disabled, checked": function() {
                this.setClass();
            },
            icon: function(e) {
                this.setData({
                    _icon: (0, l.calcIcon)(e)
                });
            }
        }, e.methods = {
            setClass: function() {
                var e = this.data.classPrefix, t = this.properties, r = t.size, c = t.variant, n = t.disabled, o = t.checked, s = [ e, "".concat(e, "--checkable"), n ? "".concat(e, "--disabled") : "", o ? "".concat(e, "--checked") : "", "".concat(e, "--").concat(o ? "primary" : "default"), "".concat(e, "--").concat(r), "".concat(e, "--").concat(c) ], i = (0, 
                l.classNames)(s);
                this.setData({
                    className: i
                });
            },
            onClick: function() {
                if (!this.data.disabled) {
                    var e = this.data.checked;
                    this._trigger("click"), this._trigger("change", {
                        checked: !e
                    });
                }
            }
        }, e;
    }
    return n(c, r), e(c);
}(s.SuperComponent);

b = d([ (0, s.wxComponent)() ], b);

exports.default = b;