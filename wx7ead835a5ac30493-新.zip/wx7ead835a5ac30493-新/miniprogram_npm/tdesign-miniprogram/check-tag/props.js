Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    checked: {
        type: null,
        value: void 0
    },
    defaultChecked: {
        type: null,
        value: void 0
    },
    closable: {
        type: Boolean,
        value: !1
    },
    content: {
        type: null
    },
    style: {
        type: String,
        value: ""
    },
    disabled: {
        type: Boolean,
        value: !1
    },
    externalClasses: {
        type: Array
    },
    icon: {
        type: null
    },
    shape: {
        type: String,
        value: "square"
    },
    size: {
        type: String,
        value: "medium"
    },
    variant: {
        type: String,
        value: "dark"
    }
};

exports.default = e;