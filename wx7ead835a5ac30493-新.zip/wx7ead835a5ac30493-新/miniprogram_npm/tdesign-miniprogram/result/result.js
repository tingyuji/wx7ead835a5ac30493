Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), c = require("../../../@babel/runtime/helpers/inherits"), o = require("../../../@babel/runtime/helpers/typeof"), i = require("../common/src/index"), l = a(require("./props")), s = a(require("../common/config")), u = require("../common/utils");

function a(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, c) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, c || [], n(e).constructor) : t.apply(e, c));
}

var p = function(e, t, r, n) {
    var c, i = arguments.length, l = i < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : o(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(e, t, r, n); else for (var s = e.length - 1; s >= 0; s--) (c = e[s]) && (l = (i < 3 ? c(l) : i > 3 ? c(t, r, l) : c(t, r)) || l);
    return i > 3 && l && Object.defineProperty(t, r, l), l;
}, d = s.default.prefix, h = "".concat(d, "-result"), m = {
    default: "error-circle",
    success: "check-circle",
    warning: "error-circle",
    error: "close-circle"
}, b = function(r) {
    function n() {
        var e;
        return t(this, n), (e = f(this, n, arguments)).options = {
            multipleSlots: !0
        }, e.externalClasses = [ "".concat(d, "-class"), "".concat(d, "-class-image"), "".concat(d, "-class-title"), "".concat(d, "-class-description") ], 
        e.properties = l.default, e.data = {
            prefix: d,
            classPrefix: h
        }, e.lifetimes = {
            ready: function() {
                this.initIcon();
            }
        }, e.observers = {
            "icon, theme": function() {
                this.initIcon();
            }
        }, e.methods = {
            initIcon: function() {
                var e = this.properties, t = e.icon, r = e.theme;
                this.setData({
                    _icon: (0, u.calcIcon)(t, m[r])
                });
            }
        }, e;
    }
    return c(n, r), e(n);
}(i.SuperComponent);

b = p([ (0, i.wxComponent)() ], b);

exports.default = b;