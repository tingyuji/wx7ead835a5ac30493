Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    description: {
        type: String
    },
    externalClasses: {
        type: Array
    },
    icon: {
        type: null,
        value: !0
    },
    image: {
        type: String
    },
    theme: {
        type: String,
        value: "default"
    },
    title: {
        type: String,
        value: ""
    }
};

exports.default = e;