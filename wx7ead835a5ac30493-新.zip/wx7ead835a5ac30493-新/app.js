var e = require("@babel/runtime/helpers/regeneratorRuntime"), a = require("@babel/runtime/helpers/asyncToGenerator"), t = require("./utils/login"), n = require("./utils/common");

getApp(), new t.Login(), new n.Common();

App({
    onLaunch: function(t) {
        var n = this;
        return a(e().mark(function a() {
            var t, o, r, s;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    (t = wx.getStorageSync("logs") || []).unshift(Date.now()), wx.setStorageSync("logs", t), 
                    wx.setStorageSync("childsList", []), o = wx.getDeviceInfo(), r = wx.getWindowInfo(), 
                    n.globalData.StatusBar = r.statusBarHeight, s = wx.getMenuButtonBoundingClientRect(), 
                    n.globalData.headerTop = "Windows" == o.model ? 20 : 4, n.globalData.model = o.model, 
                    n.globalData.safeArea = r.safeArea, n.globalData.screenHeight = r.screenHeight, 
                    n.globalData.screenWidth = r.screenWidth, console.log(n.globalData.safeArea), s ? (n.globalData.Custom = s, 
                    n.globalData.CustomBar = s.bottom + s.top - r.statusBarHeight) : n.globalData.CustomBar = r.statusBarHeight + 50;

                  case 15:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    globalData: {
        token: null,
        zhanweifu: "/images/zhanweifu.jpg",
        apiUrl: {
            uploadFileUrl: "https://pointsmanage.372158.com/wxminapi/",
            downloadFileUrl: "https://pointsmanage.372158.com/",
            requestUrl: "https://pointsmanage.372158.com/wxminapi/"
        },
        pagePath: "/pages/index/index",
        tabbarSelected: 0,
        userInfo: null,
        defaultAvatar: {
            user: {
                0: "./images/nohead.png",
                1: "./images/nohead.png"
            },
            child: {
                0: "./images/girlhead.png",
                1: "./images/boyhead.png"
            },
            student: {
                0: "./images/girlhead.png",
                1: "./images/boyhead.png"
            }
        }
    }
});