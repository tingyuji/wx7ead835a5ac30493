var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../@babel/runtime/helpers/asyncToGenerator"), i = require("../../@babel/runtime/helpers/defineProperty"), n = require("../../utils/common"), o = new (require("../../utils/requestData").requestData)(), s = new n.Common(), d = getApp();

Page({
    data: {
        app: d,
        pageLoading: !0,
        childInfo: null,
        headimgtmp: null,
        pickerValue: "",
        mode: "date",
        dateVisible: !1,
        date: null,
        start: "2000-01-01 00:00:00",
        end: "2030-09-09 12:12:12"
    },
    toSetHeadimg: function(e) {
        s.isExampleChild(this.data.childInfo.id) ? wx.showToast({
            title: "系统示例，不能修改",
            icon: "none"
        }) : wx.navigateTo({
            url: "/pages/childset/headimg/headimg?cid=" + this.data.childInfo.id
        });
    },
    ChooseImage: function() {
        var e = this;
        console.log("ChooseImage"), wx.chooseMedia({
            count: 1,
            mediaType: [ "image" ],
            sourceType: [ "album", "camera" ],
            camera: "back",
            success: function(t) {
                console.log("res"), wx.cropImage({
                    src: t.tempFiles[0].tempFilePath,
                    cropScale: "1:1",
                    success: function(t) {
                        console.log("response"), e.setData({
                            headimgtmp: t.tempFilePath
                        }), console.log(e.data.headimgtmp);
                    }
                });
            },
            fail: function() {
                console.log("fail");
            }
        });
    },
    dateChange: function(e) {
        this.setData(i({}, "postData.birthday", e.detail.value));
    },
    radioChange: function(e) {
        var t = e.detail.value;
        this.setData(i({}, "postData.sex", t));
    },
    showChangeRuleBox: function(e) {
        var t = this;
        this.popup.handlePopup(e);
        var a = null;
        null !== this.data.childInfo.ruleid && this.data.childInfo.ruleid > 0 && (a = this.data.ruleList.find(function(e) {
            return e.id === t.data.childInfo.ruleid;
        })), this.setData({
            popuptitle: "绑定个性规则",
            checkedRule: a
        });
    },
    saveBtn: function(n) {
        var d = this;
        return a(e().mark(function a() {
            var r, l, c, u, h;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r = d.data.childInfo.id, d.data.childInfo.user_id != d.data.weChatConfig.defaultUserid) {
                        e.next = 4;
                        break;
                    }
                    return s.showmsg("当前为演示，不能修改！"), e.abrupt("return");

                  case 4:
                    return d.setData(i(i(i(i({}, "postData.childid", r), "postData.nickname", n.detail.value.nickname), "postData.birthday", n.detail.value.birthday), "postData.ruleid", d.data.checkedRule ? d.data.checkedRule.id : 0)), 
                    l = d.data.postData, c = d.data.childInfo, u = c, e.next = 10, o.mainDataReq(l, "editChildinfo");

                  case 10:
                    0 == (h = e.sent).data.code && (u = t(t({}, c), d.data.postData), d.setData({
                        childInfo: u
                    })), console.log(u), s.upDateLocalChildList(u), console.log(wx.getStorageSync("childsList")), 
                    wx.showToast({
                        title: h.data.msg.title,
                        icon: h.data.msg.icon
                    });

                  case 16:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    editChildinfo: function(t) {
        var n = this;
        return a(e().mark(function a() {
            var d, r, l;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!s.isExampleChild(n.data.childInfo.id)) {
                        e.next = 3;
                        break;
                    }
                    return wx.showToast({
                        title: "系统示例，不能修改",
                        icon: "none"
                    }), e.abrupt("return");

                  case 3:
                    if (d = t.detail.value, r = t.target.dataset.field, d != n.data.childInfo[r]) {
                        e.next = 7;
                        break;
                    }
                    return e.abrupt("return");

                  case 7:
                    return e.next = 9, o.mainDataReq({
                        field: r,
                        value: d,
                        childid: n.data.childInfo.id
                    }, "editChildinfo");

                  case 9:
                    0 == (l = e.sent).data.code && (n.setData(i({}, "childInfo.".concat(r), d)), s.upDateLocalChildList(n.data.childInfo), 
                    s.showmsg(l.data.msg.title, l.data.msg.icon));

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    showPicker: function(e) {
        var t = e.currentTarget.dataset.mode;
        console.log(t), this.setData(i({
            mode: t
        }, "".concat(t, "Visible"), !0));
    },
    hidePicker: function() {
        var e = this.data.mode;
        this.setData(i({}, "".concat(e, "Visible"), !1));
    },
    onLoad: function(e) {
        var t = e.childid, a = wx.getStorageSync("loginResData"), n = wx.getStorageSync("childsList");
        if (0 != n.length) {
            var o = n.find(function(e) {
                return e.id == t;
            });
            this.setData(i(i(i(i(i(i({
                weChatConfig: a.data.weChatConfig
            }, "postData.nickname", o.nickname), "postData.birthday", o.birthday), "postData.headimg", o.headimg), "postData.sex", o.sex), "date", new Date(o.birthday).getTime() / 1e3), "childInfo", o)), 
            this.popup = this.selectComponent("#popup"), this.listRules();
        } else wx.reLaunch({
            url: "/pages/index/index"
        });
    },
    listRules: function() {
        var t = arguments, i = this;
        return a(e().mark(function a() {
            var n, s, d;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n = t.length > 0 && void 0 !== t[0] ? t[0] : 0, e.next = 3, o.mainDataReq({
                        isPublic: n
                    }, "listRules");

                  case 3:
                    s = e.sent, null, d = s.data.list.find(function(e) {
                        return e.id === i.data.childInfo.ruleid;
                    }), i.setData({
                        pageLoading: !1,
                        ruleList: s.data.list,
                        checkedRule: d
                    });

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    onReady: function() {},
    onShow: function() {
        if (!this.data.pageLoading) {
            this.listRules();
            var e = s.findChild(this.data.childInfo.id);
            this.setData({
                childInfo: e
            });
        }
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = s.getCurrentPagePath();
        return console.log(e), {
            path: e + "?promoterid=" + this.data.userInfo.id
        };
    }
});