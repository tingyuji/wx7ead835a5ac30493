var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/defineProperty"), a = require("../../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../../utils/common"), o = require("../../../utils/requestData"), r = new n.Common(), i = new o.requestData();

Page({
    data: {
        app: getApp(),
        CustomBar: getApp().globalData.CustomBar
    },
    ChooseImage: function() {
        console.log("ChooseImage");
        var n, o = this;
        wx.chooseMedia({
            count: 1,
            mediaType: [ "image" ],
            sourceType: [ "album", "camera" ],
            camera: "back",
            success: (n = a(e().mark(function n(s) {
                return e().wrap(function(n) {
                    for (;;) switch (n.prev = n.next) {
                      case 0:
                        console.log("res"), wx.cropImage({
                            quality: 70,
                            src: s.tempFiles[0].tempFilePath,
                            cropScale: "1:1",
                            success: function() {
                                var n = a(e().mark(function a(n) {
                                    var s;
                                    return e().wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                          case 0:
                                            return e.next = 2, i.uploadHeadimg(n.tempFilePath, "childhead", o.data.childInfo.id);

                                          case 2:
                                            (s = e.sent).state ? (o.setData(t({}, "childInfo.headimg", s.filepath)), r.upDateLocalChildList(o.data.childInfo), 
                                            wx.showToast({
                                                title: "上传成功",
                                                icon: "success"
                                            })) : wx.showToast({
                                                title: "上传失败",
                                                icon: "error"
                                            });

                                          case 4:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, a);
                                }));
                                return function(e) {
                                    return n.apply(this, arguments);
                                };
                            }()
                        });

                      case 2:
                      case "end":
                        return n.stop();
                    }
                }, n);
            })), function(e) {
                return n.apply(this, arguments);
            }),
            fail: function() {
                console.log("fail");
            }
        });
    },
    onLoad: function(e) {
        var t = e.cid, a = r.findChild(t), n = wx.getStorageSync("loginResData");
        this.setData({
            app: getApp(),
            childInfo: a,
            weChatConfig: n.data.weChatConfig,
            headSize: getApp().globalData.safeArea.width
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});