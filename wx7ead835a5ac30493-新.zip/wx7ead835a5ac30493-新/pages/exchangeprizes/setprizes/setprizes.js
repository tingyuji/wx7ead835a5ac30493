var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../../@babel/runtime/helpers/objectSpread2"), n = require("../../../@babel/runtime/helpers/toConsumableArray"), o = require("../../../utils/requestData"), s = require("../../../utils/safecode"), i = new o.requestData(), r = new s.Safecode(), c = getApp();

Page({
    data: {
        app: c,
        exchangePrizeslist: null,
        showDelBtn: !1
    },
    showDelBtn: function() {
        this.setData({
            showDelBtn: !this.data.showDelBtn
        });
    },
    popupCloseCallback: function(e) {
        var t = this.selectComponent("#addexchangeprizesBox");
        "editPrizes" == t.data.dotype && t.setData({
            editprizes: null,
            prizesimg: {
                fileid: null,
                filepath: null
            }
        });
    },
    addnewPrizesBtn: function(e) {
        this.handlePopup(e);
    },
    editPrizesBtn: function(e) {
        this.handlePopup(e);
    },
    addExchangeprizesSuccess: function(e) {
        var t = e.detail.dotype, o = e.detail.newItem;
        if ("editPrizes" == t) {
            var s = this.data.editprizes, i = this.data.exchangePrizeslist.findIndex(function(e) {
                return e.id === s.id;
            });
            if (-1 !== i) {
                var r = n(this.data.exchangePrizeslist);
                r[i] = a(a({}, r[i]), o), this.setData({
                    exchangePrizeslist: r
                });
            }
            this.popup.close();
        } else if ("addnewPrizes" == t) {
            o.user_id = this.data.userInfo.id;
            var c = this.data.exchangePrizeslist;
            c.unshift(o), this.setData({
                exchangePrizeslist: c
            });
        }
        this.popup.close();
    },
    delPrizesBtn: function(a) {
        var n = this;
        return t(e().mark(function o() {
            var s, r, c;
            return e().wrap(function(o) {
                for (;;) switch (o.prev = o.next) {
                  case 0:
                    s = n, r = a.currentTarget.dataset.prizes, c = r.id, wx.showModal({
                        title: "提示",
                        confirmText: "确定删除",
                        content: "确定要删除【" + r.prizesname + "】吗？",
                        complete: function() {
                            var a = t(e().mark(function t(a) {
                                var n, o;
                                return e().wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                      case 0:
                                        if (!a.confirm) {
                                            e.next = 6;
                                            break;
                                        }
                                        return e.next = 3, i.mainDataReq({
                                            id: c
                                        }, "delExchangePrizes");

                                      case 3:
                                        n = e.sent, wx.showToast({
                                            title: n.data.msg.title,
                                            icon: n.data.msg.icon
                                        }), 0 === n.data.code && (s.popup.close(), o = s.data.exchangePrizeslist.filter(function(e) {
                                            return e.id !== c;
                                        }), s.setData({
                                            exchangePrizeslist: o
                                        }));

                                      case 6:
                                      case "end":
                                        return e.stop();
                                    }
                                }, t);
                            }));
                            return function(e) {
                                return a.apply(this, arguments);
                            };
                        }()
                    });

                  case 4:
                  case "end":
                    return o.stop();
                }
            }, o);
        }))();
    },
    handlePopup: function(e) {
        this.popup.handlePopup(e);
        var t = e.currentTarget.dataset.popupname, a = "提示", n = null;
        switch (t) {
          case "addnewPrizes":
            a = "新增礼品";
            break;

          case "editPrizes":
            n = e.currentTarget.dataset.prizes, a = "编辑礼品";
        }
        this.setData({
            popupname: t,
            popupTitle: a,
            editprizes: n
        });
    },
    calcUsableHeight: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, a = this, n = getApp().globalData.screenHeight, o = 0, s = wx.createSelectorQuery().in(this);
        e.forEach(function(i, r) {
            var c = "#".concat(i);
            s.select(c).boundingClientRect(function(s) {
                console.log(s), s && s.height && (console.log("".concat(c, " 的高度:"), s.height), 
                o += s.height), r === e.length - 1 && (console.log("所有元素的总高度:", o), n = n - getApp().globalData.CustomBar - o - t, 
                a.setData({
                    usableHeight: n
                }), console.log("剩余可用", n));
            });
        }), s.exec();
    },
    scrollViewHeight: function() {
        var e = this, t = 1;
        console.log(t);
        var a = 0, n = 0, o = 158 / (750 / wx.getSystemInfoSync().windowWidth), s = setInterval(function() {
            n += 200, "NaN" != t && t > 0 && (a = getApp().globalData.screenHeight - getApp().globalData.CustomBar - t - o, 
            "Windows" == getApp().globalData.model && console.log("isWindows"), e.setData({
                scrollViewHeight: a
            }), clearInterval(s), console.log(n)), n > 1500 && clearInterval(s), t = parseInt(wx.getStorageSync("tabBarHeight")), 
            console.log(t);
        }, 200);
    },
    updateData: function() {
        var a = this;
        return t(e().mark(function t() {
            var n, o;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a.scrollViewHeight(), e.next = 3, i.mainDataReq(null, "getExchangePrizesList");

                  case 3:
                    n = e.sent, o = wx.getStorageSync("loginResData"), a.setData({
                        weChatConfig: o.data.weChatConfig,
                        exchangePrizeslist: n.data.list
                    }), a.calcUsableHeight([ "bottominfo", "note" ], 4);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onLoad: function(a) {
        var n = this;
        return t(e().mark(function t() {
            var a, o;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n.popup = n.selectComponent("#popup"), n.safecodeBox = n.selectComponent("#safecodeBox"), 
                    e.next = 4, r.safecodeState();

                  case 4:
                    a = e.sent, o = wx.getStorageSync("loginResData"), a ? n.updateData() : (n.setData({
                        popupname: "checksafecode",
                        placement: "center",
                        popupTitle: "请输入安全码",
                        safecodeCheckCallbak: "safecodeCheckCallbak"
                    }), n.safecodeBox.show()), n.setData({
                        safecodeState: a,
                        userInfo: o.data.user
                    });

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    safecodeCheckCallbak: function(e) {
        this.setData({
            safecodeState: !0
        }), this.safecodeBox.close(), this.updateData();
    },
    checkSafecodeBoxCancel: function() {
        this.safecodeBox.close(), wx.navigateBack();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = common.getCurrentPagePath();
        return console.log(e), {
            path: e + "?promoterid=" + this.data.userInfo.id
        };
    }
});