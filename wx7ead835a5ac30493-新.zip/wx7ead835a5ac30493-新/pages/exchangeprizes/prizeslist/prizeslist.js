var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../../utils/requestData"), n = require("../../../utils/common"), i = new a.requestData(), r = new n.Common(), o = getApp();

Page({
    data: {
        app: o,
        tab_panel: 0,
        stickyProps: {
            zIndex: 2
        },
        prizeslist: [],
        exchangelog: []
    },
    clearHandle: function() {
        this.setData({
            searchResult: null
        });
    },
    changeHandle: function(e) {
        var t = e.detail.value, a = this.data.prizeslist;
        a = t ? a.filter(function(e) {
            return e.prizesname.includes(t);
        }) : null, console.log(a), this.setData({
            searchValue: t,
            searchResult: a
        });
    },
    blurHandle: function(e) {
        this.setData({
            actionText: ""
        });
    },
    actionHandle: function() {
        this.setData({
            value: "",
            actionText: ""
        });
    },
    onTabsChange: function(a) {
        var n = this;
        return t(e().mark(function t() {
            var i;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n.setData({
                        tab_panel: a.detail.value
                    }), i = [ "tabmaintitle", "loglistmain", "note" ], 1 != a.detail.value) {
                        e.next = 8;
                        break;
                    }
                    return e.next = 5, n.getExchangeLog(1);

                  case 5:
                    i = [ "tabmaintitle" ], e.next = 9;
                    break;

                  case 8:
                    n.setData({
                        pageCount: 0
                    });

                  case 9:
                    n.calcUsableHeight(i);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onTabsClick: function(e) {
        this.setData({
            tab_panel: e.detail.value
        });
    },
    onStickyScroll: function(e) {
        console.log(e.detail);
    },
    changeChildBtn: function(e) {
        this.popup.handlePopup(e);
        var t = e.currentTarget.dataset.popupname, a = e.currentTarget.dataset.popuptitle, n = e.currentTarget.dataset.placement;
        this.setData({
            popupname: t,
            popuptitle: a,
            placement: n
        }), this.selectComponent("#boxChangeChild").setData({
            childsList: wx.getStorageSync("childsList"),
            childInfo: r.findChild(this.data.childid)
        });
    },
    changeChildSuccess: function(e) {
        var t = e.detail.newChildid;
        t != this.data.childid && (this.setData({
            childid: t
        }), this.getPageinfo(), this.popup.close());
    },
    getPageinfo: function() {
        var a = this;
        return t(e().mark(function t() {
            var n, o, s, c, l;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n = a.data.childid, o = wx.getStorageSync("childsList"), s = wx.getStorageSync("loginResData"), 
                    e.next = 5, i.mainDataReq(null, "getExchangePrizesList");

                  case 5:
                    c = e.sent, l = r.findChild(n), a.setData({
                        userInfo: s.data.user,
                        childInfo: l,
                        pageLoading: !0,
                        prizeslist: c.data.list,
                        childsList: o
                    }), getApp().globalData.pageChildId = n;

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    changeChild: function(a) {
        var n = this;
        return t(e().mark(function t() {
            var i, r, o;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (i = a.detail.value, r = wx.getStorageSync("childsList"), n.popup.close(), i != n.data.childid) {
                        e.next = 6;
                        break;
                    }
                    return e.abrupt("return");

                  case 6:
                    (o = r.findIndex(function(e) {
                        return e.id === i;
                    })) < 0 && n.goHomePage(), n.setData({
                        childid: i,
                        childInfo: r[o],
                        pageLoading: !0
                    }), getApp().globalData.pageChildId = i;

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    pageBtn: function(a) {
        var n = this;
        return t(e().mark(function t() {
            var i;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return i = a.detail.page, e.next = 3, n.getExchangeLog(i);

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    getExchangeLog: function(a) {
        var n = this;
        return t(e().mark(function t() {
            var r;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, i.mainDataReq({
                        childid: n.data.childid,
                        page: a
                    }, "getExchangeLog");

                  case 2:
                    if (r = e.sent, console.log(r), null == r.data.msg) {
                        e.next = 7;
                        break;
                    }
                    return wx.showModal({
                        title: "提示",
                        content: res.data.msg
                    }), e.abrupt("return");

                  case 7:
                    return n.setData({
                        exchangelog: r.data.list,
                        page: a > 0 ? a : 1,
                        pageCount: r.data.pageCount,
                        pageLoading: !1
                    }), e.abrupt("return", r.data.pageCount);

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    goPage: function(e) {
        wx.navigateTo({
            url: e.currentTarget.dataset.url
        });
    },
    onLoad: function(a) {
        var n = this;
        return t(e().mark(function t() {
            var i;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    i = parseInt(a.childid), (wx.getStorageSync("childsList").length < 1 || "undefined" == i) && n.goHomePage(), 
                    n.setData({
                        childid: a.childid
                    }), n.getPageinfo(), n.popup = n.selectComponent("#popup"), n.calcUsableHeight([ "tabmaintitle", "note" ]);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    calcUsableHeight: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, a = 0;
        this.data.pageCount > 1 && (t += 74), t > 0 && (a = t / (750 / wx.getWindowInfo().windowWidth));
        var n = this, i = getApp().globalData.screenHeight - getApp().globalData.CustomBar, r = 0, o = 0, s = wx.createSelectorQuery().in(this);
        e.forEach(function(t, c) {
            var l = "#".concat(t);
            s.select(l).boundingClientRect(function(t) {
                t && t.height && (r += t.height), c === e.length - 1 && (i = i - r - a, n.setData({
                    usableHeight: i,
                    linemainHeight: o
                }));
            });
        }), s.exec();
    },
    scrollViewHeight: function() {
        var e = this, t = 45, a = 0, n = 0, i = 0, r = 48 + 4 / (750 / wx.getSystemInfoSync().windowWidth), o = 92 + 4 / (750 / wx.getSystemInfoSync().windowWidth), s = setInterval(function() {
            i += 200, "NaN" != t && t > 0 && (a = getApp().globalData.screenHeight - getApp().globalData.CustomBar - t - r, 
            n = getApp().globalData.screenHeight - getApp().globalData.CustomBar - t - o, getApp().globalData.model, 
            e.setData({
                scrollViewHeight: a,
                scrollViewHeight2: n
            }), clearInterval(s)), i > 1500 && clearInterval(s), t = parseInt(wx.getStorageSync("tabBarHeight"));
        }, 200);
    },
    onReady: function() {},
    onShow: function() {
        this.getPageinfo();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = r.getCurrentPagePath();
        return console.log(e), {
            path: e + "?promoterid=" + this.data.userInfo.id
        };
    },
    goHomePage: function() {
        wx.reLaunch({
            url: "/pages/index/index"
        });
    }
});