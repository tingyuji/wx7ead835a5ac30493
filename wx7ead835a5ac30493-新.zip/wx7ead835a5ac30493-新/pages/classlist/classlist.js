var e = require("../../@babel/runtime/helpers/defineProperty"), t = require("../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../@babel/runtime/helpers/asyncToGenerator"), o = getApp();

Page(e(e(e(e({
    data: {
        headerTop: o.globalData.headerTop,
        showCheckBox: !1,
        options: [ {
            id: "1",
            sex: 1
        }, {
            id: "2",
            sex: 0
        }, {
            id: "3",
            sex: 1
        }, {
            id: "4",
            sex: 0
        }, {
            id: "5",
            sex: 1
        }, {
            id: "6",
            sex: 0
        }, {
            id: "7",
            sex: 1
        }, {
            id: "8",
            sex: 0
        }, {
            id: "9",
            sex: 1
        } ],
        CustomBar: o.globalData.CustomBar,
        cursorIndex: 1,
        customInputValue: [],
        labelIcon: !0,
        product: {
            value: "all",
            options: [ {
                value: "all",
                label: "全部"
            } ]
        },
        sorter: {
            value: "default",
            options: [ {
                value: "default",
                label: "默认排序"
            }, {
                value: "price",
                label: "价格从高到低"
            } ]
        }
    },
    showCheckBox: function() {
        var e = this.data.listScrollHeight;
        this.data.showCheckBox ? e += 80 / 750 * wx.getSystemInfoSync().windowWidth : e -= 80 / 750 * wx.getSystemInfoSync().windowWidth, 
        this.setData({
            showCheckBox: !this.data.showCheckBox,
            listScrollHeight: e
        });
    },
    onChange: function(e) {
        console.log("group", e.detail.value), this.setData({
            checkValues: e.detail.value
        });
    },
    onCheckAllChange: function(e) {
        console.log("checkbox", e.detail.value), this.setData({
            checkAllValues: e.detail
        });
    },
    onTap: function(e) {
        console.log("onTap", e.detail.value);
    },
    showKeyboard: function() {
        this.keyboard.showKeyboard(), this.setData({
            cursorIndex: this.data.customInputValue.length
        });
    },
    hideKeyboard: function() {
        this.keyboard.hideKeyboard();
    },
    pageConfirm: function() {
        this.setData({
            cursorIndex: -1
        }), console.log("confirm");
    },
    changeValue: function(e) {
        var t = e.detail;
        if ("zhengfu" != t) {
            var a = this.data.customInputValue, o = this.keyboard.newValue(a, t);
            this.setData({
                customInputValue: o,
                cursorIndex: o.length
            });
        } else this.setData({
            labelIcon: !this.data.labelIcon
        });
    }
}, "onTap", function(e) {
    e.currentTarget.dataset.stuid;
    wx.navigateTo({
        url: "/pages/showstu/showstu"
    });
}), "getStrPosition", function(e) {}), "onLoad", function(e) {
    var s = this;
    return a(t().mark(function e() {
        var a, n;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, o.globalData.getUserInfoAsync();

              case 2:
                a = e.sent, n = o.globalData.screenHeight - o.globalData.safeArea.top - o.globalData.CustomBar - 340 / 750 * wx.getSystemInfoSync().windowWidth, 
                console.log(340 / 750 * wx.getSystemInfoSync().windowWidth), s.setData({
                    listScrollHeight: n,
                    userInfo: a
                }), console.log(n);

              case 7:
              case "end":
                return e.stop();
            }
        }, e);
    }))();
}), "onShow", function() {
    "function" == typeof this.getTabBar && this.getTabBar() && this.getTabBar().setData({
        selected: 1
    });
}));