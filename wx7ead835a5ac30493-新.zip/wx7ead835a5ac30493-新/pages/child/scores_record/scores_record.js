var e = require("../../../@babel/runtime/helpers/toConsumableArray"), t = require("../../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../../@babel/runtime/helpers/defineProperty"), r = require("../../../@babel/runtime/helpers/asyncToGenerator"), s = require("../../../@babel/runtime/helpers/readOnlyError"), o = require("../../../utils/common"), n = require("../../../utils/requestData"), i = getApp(), c = new n.requestData(), d = new o.Common();

Page({
    offsetTopList: [],
    data: {
        app: i,
        showSafecodeBox: !1,
        safecodeCheckSuceessCallbackName: "",
        draggable: {
            right: 0,
            bottom: 80
        },
        Scores: [],
        courses: [],
        recordFontsize: 14,
        shareid: 0,
        sideBarIndex: 0,
        scrollTop: 0,
        navbarHeight: 0,
        currentPage: 1,
        pageSize: 15,
        filteredData: [],
        currentList: [],
        nowTime: new Date(),
        loglistLineHeight: 0,
        showCheckBox: !1,
        showScoresDetail: null,
        checkBox: {
            animationData: {},
            isMoved: !1
        },
        checkedItems: [],
        checkedAll: !1,
        toolbar: {
            animationData: {},
            isMoved: !1
        }
    },
    onChecked: function(e) {
        this.setData({
            checkedItems: e.detail.value
        }), console.log(e);
    },
    checkAll: function(e) {
        var t = e.detail.value;
        t = t.filter(function(e, a) {
            return t.indexOf(e) === a;
        }), this.setData({
            checkedItems: t
        });
    },
    checkAll2: function() {
        this.data.checkBox.isMoved || this.toggleMove_openCheckBox();
        var e = this.data.currentList, t = [];
        this.data.checkedItems.length < e.length && e.forEach(function(e) {
            t.push(e.id);
        }), this.checkAll({
            detail: {
                value: t
            }
        });
    },
    popupCloseCallback: function(e) {
        "addScores" == this.data.popupname && this.selectComponent("#addScores").setData({
            examname: "",
            scoresValue: "",
            totalScoresValue: "",
            notes: ""
        });
    },
    isShare: function(e) {
        void 0 !== e.shareid && null !== e.shareid && (e.shareid, s("shareid"));
        e.shareid;
    },
    onLoad: function(e) {
        var s = this;
        return r(t().mark(function r() {
            var o, n, i, c, u, l, h;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return s.popup = s.selectComponent("#popup"), o = wx.getStorageSync("isCurrentUser"), 
                    n = wx.getStorageSync("loginResData"), i = n.data.user, c = e.childid, u = e.shareid || 0, 
                    s.getCustomNavbarHeight(), s.recordFontsize(), null == (l = d.findChild(c)) && wx.reLaunch({
                        url: "/pages/index/index"
                    }), s.setData({
                        userInfo: i,
                        childInfo: l,
                        shareid: u,
                        scoresRecordPicNumMax: n.data.weChatConfig.scoresRecordPicNumMax || 2,
                        isCurrentUser: o
                    }), t.next = 13, s.getChildCourses(c);

                  case 13:
                    return t.next = 15, s.getChildScoresRecord(u, s.data.sideBarId, c);

                  case 15:
                    s.calcUsableHeight([], 90), h = wx.createSelectorQuery(), "#toolbtn", h.select("#toolbtn").boundingClientRect(function(e) {
                        s.setData(a({}, "draggable.right", 0 - e.width * (o ? 4 : 0)));
                    }).exec();

                  case 19:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    createAnimation_toolbar: function() {
        return wx.createAnimation({
            duration: 500,
            timingFunction: "ease"
        });
    },
    toggleMove_toolbar: function() {
        var e = this.createAnimation_toolbar();
        if (this.data.toolbar.isMoved) e.translateX(0).step(); else {
            var t = parseInt(this.data.draggable.right);
            e.translateX(t).step();
        }
        this.setData(a(a({}, "toolbar.animationData", e.export()), "toolbar.isMoved", !this.data.toolbar.isMoved));
    },
    createAnimation: function() {
        return wx.createAnimation({
            duration: 500,
            timingFunction: "ease"
        });
    },
    toggleMove_openCheckBox: function() {
        var e = this.createAnimation();
        this.data.checkBox.isMoved ? e.translateX(0).step() : e.translateX(this.data.loglistLineHeight).step(), 
        this.setData(a(a(a({
            checkedItems: []
        }, "checkBox.animationData", e.export()), "checkBox.isMoved", !this.data.checkBox.isMoved), "checkBoxState", !this.data.checkBox.isMoved));
    },
    recordFontsize: function() {
        var e = 14, t = this.data.app.globalData.screenWidth;
        t < 360 ? e = 12 : t >= 360 && t <= 375 ? e = 14 : t > 375 && t <= 390 ? e = 15 : t > 390 && (e = 16), 
        this.setData({
            recordFontsize: e
        });
    },
    getChildCourses: function(e) {
        var a = this;
        return r(t().mark(function r() {
            var s, o;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, c.mainDataReq({
                        childid: e
                    }, "getChildCourses");

                  case 2:
                    0 == (s = t.sent).data.code && (o = s.data.list[a.data.sideBarIndex].id, a.setData({
                        courses: s.data.list,
                        sideBarId: o
                    }));

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    getChildScoresRecord: function(e, a, s) {
        var o = this;
        return r(t().mark(function r() {
            var n;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, c.mainDataReq({
                        shareid: e,
                        childid: s,
                        courseid: a
                    }, "getChildScoresRecord");

                  case 2:
                    0 == (n = t.sent).data.code && (o.setData({
                        Scores: n.data.list
                    }), o.filterDataByCourseId(o.data.sideBarId));

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    clearScoresBtn: function(e) {
        var t = this;
        console.log(e);
        var a = e.currentTarget.dataset.recorder, r = null;
        if (d.isExampleChild(this.data.childInfo.id) && a != this.data.userInfo.id) return r = "当前是系统示例，不能清空", 
        void d.showmsg(r);
        if (this.data.userInfo.id != this.data.childInfo.user_id) {
            var s = d.findOtherMember(this.data.userInfo.otherMembers, this.data.childInfo.user_id), o = s.notes ? "(" + s.notes + ")" : "";
            return r = "当前孩子由【" + s.users.nickname + o + "】添加，您无法执行该操作！", void d.showmsg(r);
        }
        var n = this.data.courses, i = this.data.sideBarIndex, c = this;
        this.data.checkBox.isMoved && this.toggleMove_openCheckBox(), wx.showModal({
            title: "提示",
            content: "清空后无法恢复，确定要清空【" + this.data.childInfo.nickname + " 的" + n[i].course_name + "所有成绩】记录吗？",
            complete: function(e) {
                e.confirm && (console.log("confirm"), c.data.userInfo.safecode ? (c.setData({
                    safecodeCheckSuceessCallbackName: "clearScores"
                }), c.safeCodeBox = c.selectComponent("#safecodeBox"), c.safeCodeBox.setData({
                    tips: "敏感操作，需要验证安全码才能进行"
                }), c.safeCodeBox.show()) : t.clearScores());
            }
        });
    },
    clearScores: function(e) {
        var a = this;
        return r(t().mark(function e() {
            var r, s;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = a.data.sideBarId, e.next = 3, c.mainDataReq({
                        courseId: r
                    }, "clearScoresRecord");

                  case 3:
                    0 == e.sent.data.code && (s = a.data.Scores.filter(function(e) {
                        return e.courseid !== r;
                    }), a.setData({
                        Scores: s,
                        currentList: [],
                        filteredData: []
                    }));

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    batchDelScoresBtn: function(e) {
        var t = this, a = this.data.checkedItems;
        return d.isExampleChild(this.data.childInfo.id) ? (msg = "当前是演示记录，不能删除", void d.showmsg("当前是演示记录，不能删除")) : a.length <= 0 ? (wx.showToast({
            title: "请先选择记录",
            icon: "none"
        }), void (this.data.checkBox.isMoved || this.toggleMove_openCheckBox())) : void wx.showModal({
            title: "提示",
            content: "确定要删除所选记录吗？",
            complete: function(e) {
                e.confirm && (t.data.userInfo.safecode ? (t.setData({
                    safecodeCheckSuceessCallbackName: "batchDelScoresConfirm"
                }), t.safeCodeBox = t.selectComponent("#safecodeBox"), t.safeCodeBox.show()) : t.batchDelScoresConfirm(a));
            }
        });
    },
    batchDelScoresConfirm: function() {
        var e = this;
        return r(t().mark(function a() {
            var r, s, o;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = e.data.checkedItems, s = e.data.childInfo.id, t.next = 4, c.mainDataReq({
                        childid: s,
                        delScoresidList: r
                    }, "batchDelScoresRecord");

                  case 4:
                    if (0 != (o = t.sent).data.code) {
                        t.next = 9;
                        break;
                    }
                    return t.next = 8, e.getChildScoresRecord(0, e.data.sideBarId, s);

                  case 8:
                    e.setData({
                        checkedItems: []
                    });

                  case 9:
                    d.showmsg(o.data.msg.title, o.data.msg.icon);

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    delSuccess: function(e) {
        var t = this.data.shareid || 0;
        this.getChildScoresRecord(t, this.data.sideBarId, this.data.childInfo.id);
    },
    addScores: function(e) {
        var t = this;
        e.currentTarget.dataset.popupname = "addScores", null == this.data.courses || this.data.courses.length <= 0 ? wx.showModal({
            title: "提示",
            content: "您还没添加科目，请先添加",
            cancelText: "取消",
            confirmText: "去添加",
            complete: function(a) {
                a.confirm && (e.currentTarget.dataset.popuptitle = "新增科目", e.currentTarget.dataset.popupname = "addCourse", 
                t.addCourse(e));
            }
        }) : this.handlePopup(e);
    },
    addScoresSuccess: function(t) {
        console.log(t);
        var a = t.detail.newitem, r = t.detail.dotype, s = [];
        switch (console.log(r), r) {
          case "add":
            (s = e(this.data.Scores)).unshift(a);
            break;

          case "edit":
            var o = this.data.Scores.findIndex(function(e) {
                return e.id === a.id;
            });
            (s = this.data.Scores)[o] = a;
        }
        this.setData({
            Scores: s
        }), console.log(s), this.filterDataByCourseId(a.courseid), this.popup.close();
    },
    filterDataByCourseId: function(e) {
        var t = this, a = this.data.Scores.filter(function(t) {
            return t.courseid === parseInt(e);
        }), r = a.map(function(e) {
            return e.deletable = !1, e.recorder != t.data.userInfo.id && t.data.childInfo.user_id != t.data.userInfo.id || (e.deletable = !0), 
            e;
        });
        this.setData({
            filteredData: a
        });
        var s = Math.ceil(r.length / this.data.pageSize);
        this.setData({
            pageCount: s,
            page: 1
        }), this.updateCurrentList();
    },
    updateCurrentList: function() {
        var e = (this.data.currentPage - 1) * this.data.pageSize, t = e + this.data.pageSize, a = this.data.filteredData.slice(e, t);
        this.setData({
            currentList: a
        });
    },
    getCustomNavbarHeight: function() {
        var e = this, t = wx.createSelectorQuery();
        t.select(".custom-navbar").boundingClientRect(), t.exec(function(t) {
            var a = (t[0] || {}).height, r = void 0 === a ? 0 : a;
            e.setData({
                navbarHeight: r
            });
        });
    },
    onSideBarChange: function(e) {
        var t = e.detail.value, a = this.data.courses[t].id;
        a != this.data.sideBarId && (this.setData({
            sideBarIndex: t,
            sideBarId: a,
            currentList: [],
            scrollTop: 0,
            currentPage: 1
        }), this.data.checkBox.isMoved && this.toggleMove_openCheckBox(), this.filterDataByCourseId(a));
    },
    pageBtn: function(e) {
        console.log(e);
        var t = e.detail.page;
        this.setData({
            currentPage: t
        }), this.updateCurrentList();
    },
    addCourse: function(e) {
        this.handlePopup(e);
    },
    addCourseSuccess: function(t) {
        var a = t.detail.coursename, r = t.detail.newid, s = {
            childid: this.data.childInfo.id,
            userid: this.data.childInfo.user_id,
            id: r,
            course_name: a,
            creator: this.data.userInfo.id
        };
        this.setData({
            courses: [].concat(e(this.data.courses), [ s ]),
            sideBarId: r
        }), this.setData({
            sideBarIndex: this.data.courses.length - 1
        });
    },
    showScoresDetailClick: function(e) {
        var a = this;
        return r(t().mark(function r() {
            var s;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!a.data.showDelChildBtn && !a.data.showCheckBox) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    s = e.currentTarget.dataset.scoresdetail.id, e.detail.scoresId = s, a.showScoresDetail(e);

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    showScoresDetail: function(e) {
        var a = this;
        return r(t().mark(function r() {
            var s, o, n;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!a.data.showCheckBox) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    return s = e.detail.scoresId, console.log(s), o = a.data.currentList.find(function(e) {
                        return e.id === s;
                    }), t.next = 7, c.mainDataReq({
                        id: s
                    }, "getScoresRecordPics");

                  case 7:
                    n = t.sent, o.piclist = n.data.piclist, a.setData({
                        scoresDetail: o
                    }), e.currentTarget.dataset.popuptitle = "记录详情", e.currentTarget.dataset.popupname = "showScoresDetail", 
                    a.handlePopup(e);

                  case 13:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    showEditScoresPop: function(e) {
        var a = this;
        return r(t().mark(function r() {
            var s, o, n;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return s = e.detail.scoresid, o = a.data.currentList.find(function(e) {
                        return e.id === s;
                    }), t.next = 4, c.mainDataReq({
                        id: s
                    }, "getScoresRecordPics2");

                  case 4:
                    n = t.sent, o.piclist = n.data.piclist, a.setData({
                        currentScores: o
                    }), e.currentTarget.dataset.popuptitle = "编辑记录", e.currentTarget.dataset.popupname = "showScoresEditBox", 
                    a.handlePopup(e);

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    delCourseBtn: function(e) {
        var a = this;
        return r(t().mark(function e() {
            var r, s, o;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r = a, s = a.data.sideBarId, (o = a.data.courses.find(function(e) {
                        return e.id === s;
                    })).creator == a.data.userInfo.id || a.data.userInfo.id == a.data.childInfo.user_id) {
                        e.next = 6;
                        break;
                    }
                    return wx.showModal({
                        title: "提示",
                        content: "该科目不是由本账号创建，您不能删除！"
                    }), e.abrupt("return");

                  case 6:
                    wx.showModal({
                        title: "提示",
                        content: "删除后本科目下的所有成绩将清空并不可恢复，确定要删除当前科目（" + o.course_name + "）吗？",
                        complete: function(e) {
                            e.confirm && (r.data.userInfo.safecode ? (a.setData({
                                safecodeCheckSuceessCallbackName: "delCourse"
                            }), r.safeCodeBox = r.selectComponent("#safecodeBox"), r.safeCodeBox.show()) : r.delCourse());
                        }
                    });

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    delCourse: function() {
        var e = this;
        return r(t().mark(function a() {
            var r, s, o;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, c.mainDataReq({
                        delCourseid: e.data.sideBarId,
                        childid: e.data.childInfo.id
                    }, "delCourse");

                  case 2:
                    0 == (r = t.sent).data.code && (s = e.data.courses, o = s.findIndex(function(t) {
                        return t.id === e.data.sideBarId;
                    }), s.splice(o, 1), console.log(s), e.setData({
                        courses: s,
                        sideBarIndex: s.length - 1
                    })), d.showmsg(r.data.msg.title, r.data.msg.icon);

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    delCourseSuccess: function(e) {
        var t = e.currentTarget.dataset.list;
        this.setData({
            courses: t
        }), this.setData({
            sideBarIndex: 0
        });
    },
    handlePopup: function(e) {
        var a = this;
        return r(t().mark(function r() {
            var s, o, n, i;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    a.popup.handlePopup(), a, s = e.currentTarget.dataset.popuptitle, o = e.currentTarget.dataset.popupname, 
                    n = e.currentTarget.dataset.placement, i = e.currentTarget.dataset.pop_title_left_btn, 
                    a.setData({
                        popuptitle: s,
                        popupname: o,
                        placement: n,
                        pop_title_left_btn: i
                    });

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    calcUsableHeight: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, a = 0;
        t > 0 && (a = t / (750 / wx.getWindowInfo().windowWidth));
        var r = this, s = getApp().globalData.screenHeight, o = 0, n = 0;
        if (e.length > 0) {
            var i = wx.createSelectorQuery().in(this);
            e.forEach(function(t, c) {
                var d = "#".concat(t);
                i.select(d).boundingClientRect(function(i) {
                    console.log(i), i && i.height && (console.log("".concat(d, " 的高度:"), i.height), 
                    "line_main" == t ? n = i.height : o += i.height), c === e.length - 1 && (console.log("所有元素的总高度:", o), 
                    s = s - getApp().globalData.CustomBar - o - a, r.setData({
                        usableHeight: s,
                        linemainHeight: n,
                        loglistPageheight: loglistPageheight
                    }));
                });
            }), i.exec();
        } else {
            var c = (s = s - getApp().globalData.CustomBar - a) - 120 / (750 / wx.getWindowInfo().windowWidth);
            r.setData({
                usableHeight: s,
                loglistPageheight: c,
                loglistLineHeight: c / 15
            });
        }
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function(e) {
        var a = this;
        return r(t().mark(function e() {
            var r, s, o, n;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = a.data.childInfo.id, s = a.data.sideBarId, o = a.data.shareid, (n = d.returnShareAppMessage()).path = n.path + "&shareid=" + o + "&childid=" + r + "&sideBarId=" + s, 
                    n.title = a.data.childInfo.nickname + "的成绩记录", n.success = function(e) {
                        console.log("分享成功"), wx.showToast({
                            title: "分享成功"
                        });
                    }, n.fail = function(e) {
                        console.log(e);
                    }, console.log(n), e.abrupt("return", n);

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    }
});