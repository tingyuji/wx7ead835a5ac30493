var e = require("../../../@babel/runtime/helpers/defineProperty"), t = require("../../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../../utils/common"), r = require("../../../utils/requestData"), o = getApp(), i = new n.Common(), c = new r.requestData();

Page({
    data: {
        app: o,
        draggable: {
            left: o.globalData.safeArea.right - 50,
            bottom: 100
        },
        currentList: [],
        showDelBtn: !1
    },
    addGrowthBtn: function(e) {
        this.popup.handlePopup(e), this.handlePopup(e);
    },
    addGrowthRecordSuccess: function() {
        this.getGrowthRecord(1), this.selectComponent("#addGrowthRecord").setData({
            heightValue: null,
            weightValue: null
        }), this.popup.close();
    },
    showDelGrowthBtn: function() {
        this.setData({
            showDelBtn: !this.data.showDelBtn
        });
    },
    delGrowthBtn: function(e) {
        var n = this;
        return a(t().mark(function a() {
            var r, o, s, d, l;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (r = e.currentTarget.dataset.index, o = n.data.growthRecord, (s = n.data.growthRecord[r]).deletable.able) {
                        t.next = 6;
                        break;
                    }
                    return i.showmsg(s.deletable.msg), t.abrupt("return");

                  case 6:
                    return d = s.id, t.next = 9, c.mainDataReq({
                        targetid: d
                    }, "delGrowtRecord");

                  case 9:
                    0 == (l = t.sent).data.code && (o.splice(r, 1), n.setData({
                        growthRecord: o
                    })), i.showmsg(l.data.msg.title, l.data.msg.icon);

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    changeChildBtn: function(e) {
        console.log("chengeChildBtn"), this.popup.handlePopup(e), this.handlePopup(e), this.selectComponent("#boxChangeChild").setData({
            childsList: wx.getStorageSync("childsList"),
            childInfo: i.findChild(this.data.childid)
        });
    },
    handlePopup: function(e) {
        var t = e.currentTarget.dataset.popupname, a = e.currentTarget.dataset.popuptitle, n = e.currentTarget.dataset.placement;
        this.setData({
            popupname: t,
            popuptitle: a,
            placement: n
        });
    },
    changeChildSuccess: function(e) {
        var n = this;
        return a(t().mark(function a() {
            var r, o, c;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return n.popup.close(), wx.showLoading({
                        title: "Loading"
                    }), r = e.detail.newChildid, o = i.findChild(r), n.setData({
                        childid: r,
                        childInfo: o,
                        pageLoading: !0,
                        page: 1
                    }), getApp().globalData.pageChildId = r, n.getGrowthRecord(1), c = [ "Log-title" ], 
                    t.next = 10, n.getGrowthRecord(1);

                  case 10:
                    that.calcUsableHeight(c), wx.hideLoading();

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    onLoad: function(n) {
        var r = this;
        return a(t().mark(function a() {
            var o, i, c, s, d, l;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r.popup = r.selectComponent("#popup"), o = wx.getStorageSync("childsList"), 
                    i = parseInt(n.childid), c = o.findIndex(function(e) {
                        return e.id === i;
                    }), s = wx.getStorageSync("loginResData"), d = s.data.user, (l = o[c]) || wx.reLaunch({
                        url: "/pages/index/index"
                    }), r.setData(e({
                        childInfo: l,
                        weChatConfig: s.data.weChatConfig,
                        userInfo: d,
                        childid: i
                    }, "draggable.bottom", wx.getStorageSync("tabBarHeight"))), t.next = 11, r.getGrowthRecord(1);

                  case 11:
                    r.calcUsableHeight([ "Log-title" ]);

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    pageBtn: function(e) {
        var n = this;
        return a(t().mark(function a() {
            var r;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = e.detail.page, t.next = 3, n.getGrowthRecord(r);

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    getGrowthRecord: function(e) {
        var n = this;
        return a(t().mark(function a() {
            var r, o, s, d;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = n.data.childid, t.next = 3, c.mainDataReq({
                        childid: r,
                        page: e
                    }, "getGrowthRecord", !0);

                  case 3:
                    if (null == (o = t.sent).data.msg) {
                        t.next = 7;
                        break;
                    }
                    return wx.showModal({
                        title: "提示",
                        content: o.data.msg
                    }), t.abrupt("return");

                  case 7:
                    return s = i.isExampleChild(n.data.childInfo.id), d = new Date(), o.data.list.length > 0 && o.data.list.forEach(function(e) {
                        e.deletable = n.deletable(s, e, d, n.data.childInfo);
                    }), n.setData({
                        growthRecord: o.data.list,
                        page: e > 0 ? e : 1,
                        pageCount: o.data.pageCount,
                        pageLoading: !1
                    }), t.abrupt("return", o.data.pageCount);

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    deletable: function(e, t, a, n) {
        var r = t.recorderUser, o = this.data.userInfo, i = {
            able: !1,
            msg: "权限不足"
        }, c = new Date(t.addtime.replace(" ", "T")), s = parseInt((a - c) / 1e3);
        return e && r.id != o.id ? i.msg = "当前是演示记录，不能删除" : s > 86400 ? i.msg = "当前记录已超过24小时，不能删除" : n.user_id == o.id || r.id == o.id ? i.able = !0 : i.msg = "该条记录由【" + r.nickname + "】添加，您不能删除！", 
        i;
    },
    showLogDetail: function(e) {
        var t = e.currentTarget.dataset.logid, a = this.data.growthRecord.find(function(e) {
            return e.id === t;
        });
        console.log(a);
    },
    getNextPageBtn: function(e) {
        var t = e.currentTarget.dataset.page;
        this.getGrowthRecord(t);
    },
    calcUsableHeight: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, a = 0;
        this.data.pageCount > 1 && (t += 76), t > 0 && (a = t / (750 / wx.getWindowInfo().windowWidth));
        var n = this, r = getApp().globalData.screenHeight - getApp().globalData.CustomBar;
        console.log("usableHeight", r);
        var o = 0, i = 0, c = wx.createSelectorQuery().in(this);
        e.forEach(function(t, s) {
            var d = "#".concat(t);
            c.select(d).boundingClientRect(function(t) {
                console.log(t), t && t.height && (console.log("".concat(d, " 的高度:"), t.height), 
                o += t.height), s === e.length - 1 && (console.log("所有元素的总高度:", o), r = r - o - a, 
                n.setData({
                    usableHeight: r,
                    linemainHeight: i
                }), console.log("剩余可用", r), console.log("totalHeight", o), console.log("otherHeight", a));
            });
        }), c.exec();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = i.getCurrentPagePath();
        return console.log(e), {
            path: e + "?promoterid=" + this.data.userInfo.id
        };
    }
});