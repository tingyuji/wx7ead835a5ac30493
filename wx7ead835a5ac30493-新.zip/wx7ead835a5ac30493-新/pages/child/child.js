var e = require("../../@babel/runtime/helpers/defineProperty"), t = require("../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../utils/common"), i = require("../../utils/login.js"), r = require("../../utils/requestData"), o = getApp(), s = new n.Common(), c = new i.Login(), l = new r.requestData();

Page({
    data: {
        app: getApp(),
        pageLoading: !0,
        border: {
            color: "rgb(247, 251, 255)"
        },
        scrollViewHeight: 100,
        headerTop: o.globalData.headerTop,
        tabPanelHeight: 300,
        popupname: null,
        popupTitle: "提示"
    },
    toSetHeadimg: function(e) {
        s.isExampleChild(this.data.childid) ? wx.showToast({
            title: "系统示例，不能修改",
            icon: "none"
        }) : wx.navigateTo({
            url: "/pages/childset/headimg/headimg?cid=" + this.data.childid
        });
    },
    onTabsChange: function(e) {
        console.log("Change tab, tab-panel value is ".concat(e.detail.value, "."));
    },
    onTabsClick: function(e) {
        console.log("Click tab, tab-panel value is ".concat(e.detail.value, "."));
    },
    updateData: function() {
        var e = this;
        return a(t().mark(function a() {
            var n, i, r, o;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return n = wx.getStorageSync("isCurrentUser"), i = wx.getStorageSync("loginResData"), 
                    r = i.data.user, t.next = 5, e.getPageData();

                  case 5:
                    o = wx.getStorageSync("childsList"), e.setData({
                        weChatConfig: i.data.weChatConfig,
                        userInfo: r,
                        isCurrentUser: n,
                        pageLoading: !1,
                        childsList: o
                    }), e.calcUsableHeight([ "topBox", "divider", "pointsLog-title", "gridBlock" ], 26);

                  case 8:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    onLoad: function(e) {
        var n = this;
        return a(t().mark(function a() {
            var i;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return i = parseInt(e.id), n.setData({
                        childid: i
                    }), t.next = 4, c.userLogin(e);

                  case 4:
                    n.updateData(), n.popup = n.selectComponent("#popup");

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    calcUsableHeight: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, a = this, n = getApp().globalData.screenHeight, i = 0, r = 0, o = wx.createSelectorQuery().in(this);
        e.forEach(function(s, c) {
            var l = "#".concat(s);
            o.select(l).boundingClientRect(function(o) {
                o && o.height && (i += o.height, "gridBlock" == s && (r = o.height)), c === e.length - 1 && (n = n - getApp().globalData.CustomBar - i - t, 
                a.setData({
                    usableHeight: n,
                    gridBlockHeight: r
                }));
            });
        }), o.exec();
    },
    addpointsBtn: function(e) {
        this.handlePopup(e);
        var t = this.selectComponent("#addpointsbox"), a = t.data.noticeBarContentList, n = a[s.getRandomInt(0, a.length - 1)];
        t.setData({
            noticeBarContent: n,
            noticeBarVisible: !0
        });
    },
    showmsg: function() {
        wx.showToast({
            title: "功能开发中...",
            icon: "none"
        });
    },
    bindChildRuleBtn: function(e) {
        var n = this;
        return a(t().mark(function a() {
            var i, r, o, c, l, u;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (n.data.isCurrentUser) {
                        t.next = 9;
                        break;
                    }
                    if (i = n.data.userInfo.lastparentuserid, null, !i) {
                        t.next = 9;
                        break;
                    }
                    return o = n.data.userInfo.otherMembers, c = s.findOtherMember(o, i), r = c.notes ? "(" + c.notes + ")" : "", 
                    wx.showModal({
                        title: "提示",
                        content: "请使用【" + c.users.nickname + r + "】的账号操作此项！",
                        showCancel: !1
                    }), t.abrupt("return");

                  case 9:
                    return n.handlePopup(e), l = null, t.next = 13, n.listRules();

                  case 13:
                    u = t.sent, null !== n.data.pageData.childInfo.ruleid && n.data.pageData.childInfo.ruleid > 0 && (l = u.find(function(e) {
                        return e.id === n.data.pageData.childInfo.ruleid;
                    })), n.setData({
                        checkedRule: l
                    });

                  case 16:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    changeRuleBoxConfirmBtn: function(t) {
        var a = t.detail.checkedRuleId;
        this.setData(e({}, "pageData.childInfo.ruleid", a));
    },
    listRules: function() {
        var e = arguments, n = this;
        return a(t().mark(function a() {
            var i, r, o, s;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return i = e.length > 0 && void 0 !== e[0] ? e[0] : 0, r = [], t.next = 4, l.mainDataReq({
                        isPublic: i
                    }, "listRules");

                  case 4:
                    return o = t.sent, r = o.data.list, null, s = r.find(function(e) {
                        return e.id === n.data.pageData.childInfo.ruleid;
                    }), n.changeRuleBox = n.selectComponent("#changeRuleBox"), n.changeRuleBox.setData({
                        ruleList: o.data.list,
                        checkedRule: s
                    }), n.setData({
                        pageLoading: !1
                    }), t.abrupt("return", r);

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    handlePopup: function(e) {
        var n = this;
        return a(t().mark(function a() {
            var i, r, o, s, c, l, u;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    n.popup.handlePopup(e), n, i = e.currentTarget.dataset.popuptitle, r = e.currentTarget.dataset.popupname, 
                    o = e.currentTarget.dataset.placement, s = e.currentTarget.dataset.pop_title_left_btn, 
                    console.log(r), n.setData({
                        popuptitle: i,
                        popupname: r,
                        placement: o,
                        pop_title_left_btn: s
                    }), t.t0 = r, t.next = "addpoints" === t.t0 ? 11 : "childbindrule" === t.t0 ? 29 : 31;
                    break;

                  case 11:
                    if (!(c = n.selectComponent("#addpointsbox"))) {
                        t.next = 26;
                        break;
                    }
                    return l = {
                        childid: n.data.childid
                    }, t.prev = 14, t.next = 17, c.getCauseList(l);

                  case 17:
                    0 == (u = t.sent).data.code && n.setData({
                        nowRuleid: u.data.rule.id
                    }), t.next = 24;
                    break;

                  case 21:
                    t.prev = 21, t.t1 = t.catch(14), console.error("Error calling getCauseList:", t.t1);

                  case 24:
                    t.next = 27;
                    break;

                  case 26:
                    console.error("Component #addpointsbox not found");

                  case 27:
                    return c.setData({
                        childBindRuleid: n.data.pageData.childInfo.ruleid
                    }), t.abrupt("break", 33);

                  case 29:
                    return n.popup.setData({
                        needvip: !0
                    }), t.abrupt("break", 33);

                  case 31:
                    return console.log("a"), t.abrupt("break", 33);

                  case 33:
                  case "end":
                    return t.stop();
                }
            }, a, null, [ [ 14, 21 ] ]);
        }))();
    },
    ChangeChildBtn: function(e) {
        this.handlePopup(e), this.selectComponent("#boxChangeChild").setData({
            childsList: wx.getStorageSync("childsList"),
            childInfo: s.findChild(this.data.childid)
        });
    },
    Popup_TitleLeft_Click: function(e) {
        var t = this;
        if (s.isExampleChild(this.data.childid)) wx.showModal({
            title: "提示",
            content: "这是系统示例，不能修改，请先创建孩子信息！",
            cancelText: "取消",
            confirmText: "立即创建",
            complete: function(a) {
                a.confirm && (t.popup.handlePopup(e), t.setData({
                    popupname: "addChildBox",
                    popuptitle: "创建孩子信息",
                    pop_title_left_btn: null
                }));
            }
        }); else {
            var a = "/pages/pointsrule/rulecauselist/rulecauselist?id=" + this.data.nowRuleid;
            4 == this.data.nowRuleid && (a = "/pages/pointsrule/rulelist/rulelist"), wx.navigateTo({
                url: a
            });
        }
    },
    addpointSuccess: function(e) {
        var n = this;
        return a(t().mark(function e() {
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    n.getChildPagedata();

                  case 1:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    addChildSuccess: function(e) {
        console.log(e);
        var t = e.detail.newChildid;
        wx.redirectTo({
            url: "/pages/child/child?id=" + t
        });
    },
    getChildPagedata: function() {
        var e = this;
        return a(t().mark(function a() {
            var n;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, l.mainDataReq({
                        childid: e.data.childid
                    }, "getChildPagedata", !1);

                  case 2:
                    0 === (n = t.sent).data.code ? (e.setData({
                        pageData: n.data,
                        pageLoading: !1
                    }), s.upDateLocalChildList(n.data.childInfo)) : 1 === n.data.code && (console.log(n.data.code), 
                    wx.reLaunch({
                        url: "/pages/index/index"
                    }));

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    goPage: function(e) {
        var t = e.currentTarget.dataset.url;
        wx.navigateTo({
            url: t
        });
    },
    onReady: function() {},
    onShow: function() {
        var e = this;
        return a(t().mark(function a() {
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e.data.pageLoading) {
                        t.next = 5;
                        break;
                    }
                    return getApp().globalData.pageChildId && e.setData({
                        childid: getApp().globalData.pageChildId
                    }), getApp().globalData.pageChildId = null, t.next = 5, e.getPageData();

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    changeChildSuccess: function(e) {
        var t = e.detail.newChildid;
        this.switchChild(t);
    },
    switchChild: function(e) {
        var n = this;
        return a(t().mark(function a() {
            var i;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return null == (i = s.findChild(e)) && n.goHomePage(), n.setData({
                        childid: e,
                        childInfo: i
                    }), t.next = 5, n.getPageData();

                  case 5:
                    n.popup.close();

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    getPageData: function() {
        var e = this;
        return a(t().mark(function a() {
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    e.getChildPagedata(), e.calcUsableHeight([ "topBox", "divider", "pointsLog-title", "gridBlock" ], 27);

                  case 2:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    onHide: function() {
        console.log("onHide"), this.popup.close();
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = s.getCurrentPagePath();
        return console.log(e), {
            path: e + "?promoterid=" + this.data.userInfo.id
        };
    }
});