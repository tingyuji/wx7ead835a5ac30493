var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../@babel/runtime/helpers/asyncToGenerator"), t = require("../../utils/common"), n = getApp(), o = "https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0", s = new t.Common();

Component({
    data: {
        cur: {},
        model: n.globalData.model,
        headerTop: 0,
        nickname: "微信用户1001234",
        safeArea: n.globalData.safeArea,
        screenHeight: n.globalData.screenHeight,
        CustomBar: n.globalData.CustomBar,
        listScrollHeight: 300,
        tabbarValue: "/pages/index/index",
        userAvatar: "https://alifei04.cfp.cn/creative/vcg/800/new/VCG41N152985209.jpg",
        userInfo: {
            avatarUrl: o,
            nickName: ""
        },
        hasUserInfo: !1,
        canIUseGetUserProfile: wx.canIUse("getUserProfile"),
        canIUseNicknameComp: wx.canIUse("input.type.nickname")
    },
    methods: {
        click: function() {
            console.log("按钮被点击了！");
        },
        onChange_SF: function(e) {
            this.onClose();
            var a = parseInt(e.detail.value);
            a != n.globalData.userInfo.lasttype && s.jump2UsertypePage(a);
        },
        handlePopup: function(e) {
            this.setData({
                visible: !0
            });
        },
        onVisibleChange: function(e) {
            console.log("onVisibleChange"), this.setData({
                visible: e.detail.visible
            });
        },
        onClose: function() {
            this.setData({
                visible: !1
            });
        },
        onLoad: function(t) {
            var o = this;
            return a(e().mark(function a() {
                var t, r;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return t = n.globalData.screenHeight - n.globalData.safeArea.top - n.globalData.CustomBar - .472 * wx.getSystemInfoSync().windowWidth, 
                        o.setData({
                            listScrollHeight: t,
                            headerTop: "Windows" == o.data.model ? 30 : 4
                        }), e.next = 4, s.getWxUser();

                      case 4:
                        r = e.sent, console.log("parent onLoad"), console.log(r), 0 == r.lasttype && s.updateUserInfo(JSON.stringify({
                            lasttype: 1
                        }), n.globalData.userInfo.uid);

                      case 8:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        },
        tabChange: function(e) {
            console.log("1111"), this.setData({
                value: e
            }), console.log(e.detail);
        },
        bindViewTap: function() {
            wx.navigateTo({
                url: "../logs/logs"
            });
        },
        onChooseAvatar: function(e) {
            var a = e.detail.avatarUrl, t = this.data.userInfo.nickName;
            this.setData({
                "userInfo.avatarUrl": a,
                hasUserInfo: t && a && a !== o
            });
        },
        onInputChange: function(e) {
            var a = e.detail.value, t = this.data.userInfo.avatarUrl;
            this.setData({
                "userInfo.nickName": a,
                hasUserInfo: a && t && t !== o
            });
        },
        getUserProfile: function(e) {
            var a = this;
            wx.getUserProfile({
                desc: "展示用户信息",
                success: function(e) {
                    console.log(e), a.setData({
                        userInfo: e.userInfo,
                        hasUserInfo: !0
                    });
                }
            });
        }
    }
});