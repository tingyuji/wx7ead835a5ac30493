var t = require("../../@babel/runtime/helpers/regeneratorRuntime"), e = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../@babel/runtime/helpers/defineProperty"), n = require("../../utils/common"), r = require("../../utils/requestData"), i = new n.Common(), o = new r.requestData();

Page({
    data: {
        pageLoading: !0,
        pointsLogDateType: "",
        usableHeight: 500,
        childsList: [],
        calendar: {
            visible: !1,
            value: new Date().getTime(),
            minDate: new Date().getTime(),
            maxDate: new Date().getTime()
        }
    },
    calendarDateSet: function() {
        var t = Math.round(new Date().getTime());
        this.setData(a(a({}, "calendar.maxDate", t), "calendar.minDate", t - 31536e6));
    },
    handleCalendar: function() {
        this.setData(a({}, "calendar.visible", !0));
    },
    handleGetPointsLog: function(a) {
        var n = this;
        return e(t().mark(function e() {
            var r;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (r = a.currentTarget.dataset.target, n.setData({
                        pageLoading: !0,
                        pointsLogDateType: r
                    }), "customdate" != r) {
                        t.next = 5;
                        break;
                    }
                    return n.handleCalendar(), t.abrupt("return");

                  case 5:
                    return t.next = 7, n.listPointsLog();

                  case 7:
                    n.calcUsableHeight([ "datebtnlist", "pointsLog-title" ]);

                  case 8:
                  case "end":
                    return t.stop();
                }
            }, e);
        }))();
    },
    handleConfirm: function(n) {
        var r = this;
        return e(t().mark(function e() {
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r.setData(a(a({}, "customdate.start", n.detail.value[0] / 1e3), "customdate.over", n.detail.value[1] / 1e3 + 86400)), 
                    t.next = 3, r.listPointsLog(1);

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, e);
        }))();
    },
    pageBtn: function(t) {
        var e = t.detail.page;
        this.listPointsLog(e);
    },
    showLogDetail: function(a) {
        var n = this;
        return e(t().mark(function e() {
            var r, i, o;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    r = a.currentTarget.dataset.logid, i = n.data.pointsLogList.find(function(t) {
                        return t.id === r;
                    }), o = n.data.userInfo.nickname, i.recorder && i.recorderUser && (o = i.recorderUser.nickname), 
                    console.log(o), console.log(i);

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, e);
        }))();
    },
    listPointsLog: function() {
        var a = arguments, n = this;
        return e(t().mark(function e() {
            var r, i, s, c;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = a.length > 0 && void 0 !== a[0] ? a[0] : 1, "customdate" == (i = {
                        value: n.data.pointsLogDateType ? n.data.pointsLogDateType : "nodate"
                    }).value && (i.start = n.data.customdate.start, i.over = n.data.customdate.over), 
                    t.next = 5, o.mainDataReq({
                        childid: n.data.childInfo.id,
                        isall: 1,
                        list: 1,
                        page: r,
                        dateType: JSON.stringify(i)
                    }, "listPointsLog");

                  case 5:
                    s = t.sent, c = null, 0 === s.data.code && (c = s.data[i.value].list), n.setData({
                        page: r,
                        pageCount: s.data.pageCount,
                        pageLoading: !1,
                        pointsLogDateType: i.value,
                        pointsLogList: c
                    });

                  case 9:
                  case "end":
                    return t.stop();
                }
            }, e);
        }))();
    },
    handleRevoke: function(t) {
        var e = t.currentTarget.dataset.logid, a = t.currentTarget.dataset.enable, n = t.currentTarget.dataset.enablecause, r = this.data.pointsLogList.findIndex(function(t) {
            return t.id === e;
        }), o = this.data.pointsLogList[r];
        if (a) {
            var s = this;
            wx.showModal({
                title: "提示",
                content: "确定要撤销该条记录吗？",
                success: function(t) {
                    t.confirm ? (s.revoke(e), console.log("用户点击确定")) : t.cancel && console.log("用户点击取消");
                }
            });
        } else {
            var c = "";
            switch (n) {
              case "logtypeErr":
                c = "该条记录类型不可被撤销！";
                break;

              case "timeOut":
                c = "该条记录已超过24小时，不可撤销！";
                break;

              case "notCreator":
                c = "这是【" + o.recorderUser.nickname + "】操作的奖惩记录，您不能进行撤销操作！";
            }
            i.showmsg(c);
        }
    },
    revoke: function(a) {
        var n = this;
        return e(t().mark(function e() {
            var r, i;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, o.mainDataReq({
                        logid: a
                    }, "revoke");

                  case 2:
                    r = t.sent, wx.showToast({
                        title: r.data.msg.title,
                        icon: r.data.msg.icon
                    }), r.data.state && -1 !== (i = n.data.pointsLogList.findIndex(function(t) {
                        return t.id === a;
                    })) && (n.data.pointsLogList.splice(i, 1), n.setData({
                        pointsLogList: n.data.pointsLogList
                    }));

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, e);
        }))();
    },
    changeChildBtn: function(t) {
        this.selectComponent("#boxChangeChild").setData({
            childInfo: this.data.childInfo,
            childsList: wx.getStorageSync("childsList")
        }), this.popup.handlePopup(t);
        var e = t.currentTarget.dataset.popupname, a = t.currentTarget.dataset.popuptitle, n = t.currentTarget.dataset.placement;
        this.setData({
            popupname: e,
            popuptitle: a,
            placement: n
        });
    },
    changeChildSuccess: function(a) {
        var n = this;
        return e(t().mark(function e() {
            var r, o;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return console.log(a), r = a.detail.newChildid, null == (o = i.findChild(r)) && n.goHomePage(), 
                    n.setData({
                        childid: r,
                        childInfo: o,
                        pageLoading: !0
                    }), t.next = 7, n.listPointsLog(1);

                  case 7:
                    n.popup.close();

                  case 8:
                  case "end":
                    return t.stop();
                }
            }, e);
        }))();
    },
    calendarClose: function() {
        this.setData({
            pageLoading: !1
        });
    },
    updateData: function() {
        var a = this;
        return e(t().mark(function e() {
            var n, r, i, s, c, u;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (n = wx.getStorageSync("loginResData"), r = n.data.user, i = a.data.childid, 
                    (s = wx.getStorageSync("childsList")).length) {
                        t.next = 9;
                        break;
                    }
                    return t.next = 7, o.childsList(r.id);

                  case 7:
                    c = t.sent, s = c.data.list;

                  case 9:
                    return u = s.find(function(t) {
                        return t.id == i;
                    }), a.setData({
                        weChatConfig: n.data.weChatConfig,
                        userInfo: r,
                        app: getApp(),
                        childInfo: u,
                        childsList: s
                    }), t.next = 13, a.listPointsLog(1);

                  case 13:
                    a.calcUsableHeight([ "datebtnlist", "pointsLog-title" ]), a.calendarDateSet();

                  case 15:
                  case "end":
                    return t.stop();
                }
            }, e);
        }))();
    },
    onLoad: function(a) {
        var n = this;
        return e(t().mark(function e() {
            var r;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (n.popup = n.selectComponent("#popup"), r = parseInt(a.id), !isNaN(r)) {
                        t.next = 5;
                        break;
                    }
                    return wx.reLaunch({
                        url: "/pages/index/index"
                    }), t.abrupt("return");

                  case 5:
                    n.setData({
                        childid: r
                    }), n.updateData();

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, e);
        }))();
    },
    calcUsableHeight: function(t) {
        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, a = 0;
        this.data.pageCount > 1 && (e += 76), e > 0 && (a = e / (750 / wx.getWindowInfo().windowWidth));
        var n = this, r = getApp().globalData.screenHeight - getApp().globalData.CustomBar, i = 0, o = 0, s = wx.createSelectorQuery().in(this);
        t.forEach(function(e, c) {
            var u = "#".concat(e);
            s.select(u).boundingClientRect(function(e) {
                e && e.height && (i += e.height), c === t.length - 1 && (r = r - i - a, n.setData({
                    usableHeight: r,
                    linemainHeight: o
                }));
            });
        }), s.exec();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var t = i.getCurrentPagePath();
        return console.log(t), {
            path: t + "?promoterid=" + this.data.userInfo.id
        };
    }
});