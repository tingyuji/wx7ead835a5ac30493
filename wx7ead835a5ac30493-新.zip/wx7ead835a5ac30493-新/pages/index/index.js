var t = require("../../@babel/runtime/helpers/toConsumableArray"), e = require("../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../@babel/runtime/helpers/defineProperty"), r = require("../../utils/common"), s = require("../../utils/login"), o = require("../../utils/requestData"), i = getApp(), c = "https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0", u = new s.Login(), l = new o.requestData(), h = new r.Common();

Component({
    data: {
        isCurrentUser: !0,
        showDelChildBtn: !1,
        bodyPosition: "unset",
        app: getApp(),
        pageLoading: !0,
        cur: {},
        model: i.globalData.model,
        headerTop: 0,
        listScrollHeight: 310,
        tabbarValue: "/pages/index/index",
        userAvatar: "https://alifei04.cfp.cn/creative/vcg/800/new/VCG41N152985209.jpg",
        userInfo: null,
        draggable: {
            right: -200,
            bottom: wx.getStorageSync("tabBarHeight") + 30
        },
        popupname: null,
        rollmsgSet: {
            speed: 60,
            loop: -1,
            delay: 0,
            msg: "欢迎使用电子积分管理小程序。"
        },
        current: -1,
        toolbar: {
            animationData: {},
            isOpen: !1,
            width: 0
        }
    },
    methods: {
        draggableHandleTouchEnd: function(t) {},
        toggleTools: function(t) {
            var e = this.data.toolbar.isOpen, a = wx.createAnimation({
                duration: 500,
                timingFunction: "ease"
            });
            e ? a.translateX(0).step() : a.translateX(0 - this.data.toolbar.width).step(), this.setData(n(n({}, "toolbar.isOpen", !e), "toolbar.animationData", a.export()));
        },
        click: function() {},
        onChange_SF: function(t) {
            this.onClose();
            var e = parseInt(t.detail.value);
            e != i.globalData.userInfo.lasttype && h.jump2UsertypePage(e);
        },
        addChildBtn: function(t) {
            if (this.data.isCurrentUser) this.handlePopup(t); else {
                var e = this, a = h.findOtherMember(this.data.userInfo.otherMembers, this.data.userInfo.lastparentuserid), n = a.notes ? "(" + a.notes + ")" : "", r = a.users.nickname + n;
                wx.showModal({
                    title: "提示",
                    content: "您当前正在使用【" + r + "】的账号，确定要在 TA 的账号下创建孩子信息吗？",
                    confirmText: "确定",
                    cancelText: "切换账号",
                    complete: function(a) {
                        a.cancel ? e.switchUserBtn() : a.confirm && e.handlePopup(t);
                    }
                });
            }
        },
        addChildSuccess: function(t) {
            var n = this;
            return a(e().mark(function a() {
                var r;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        r = t.detail.childsList, n.setData({
                            childsList: r
                        }), n.popup.close();

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        },
        switchUserBtn: function(t) {
            this.popup_switchUser.show();
        },
        switchUserSuccess: function(t) {
            var n = this;
            return a(e().mark(function t() {
                return e().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, u.userLogin(null, 1);

                      case 2:
                        n.updateData();

                      case 3:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        showDelChildBtn: function(t) {
            this.setData({
                showDelChildBtn: !this.data.showDelChildBtn
            });
        },
        delChildSuceessCallback: function() {
            var t = this;
            return a(e().mark(function a() {
                var n, r, s;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (0 != (n = wx.getStorageSync("childsList")).length) {
                            e.next = 7;
                            break;
                        }
                        return e.next = 4, l.mainDataReq(null, "getChildList");

                      case 4:
                        r = e.sent, n = r.data.list, wx.setStorageSync("childsList", n);

                      case 7:
                        s = !1, n.length > 0 && (s = !0), t.setData({
                            childsList: n,
                            showDelChildBtn: s
                        });

                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        },
        handlePopup: function(t) {
            this.popup.handlePopup(t);
            var e = t.currentTarget.dataset.popupname, a = t.currentTarget.dataset.popuptitle, n = t.currentTarget.dataset.placement;
            this.setData({
                popupname: e,
                popuptitle: a,
                placement: n
            });
        },
        updateData: function() {
            var r = this;
            return a(e().mark(function a() {
                var s, o, i, c, u, d, p, g, f, m, w, x, b, v, S;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return s = r, o = wx.getStorageSync("loginResData"), i = wx.getStorageSync("example"), 
                        c = null, u = o.data.user.lastparentuserid, d = o.data.user.otherMembers, null != u && d.length > 0 && (c = h.findOtherMember(d, u)).users.viplevel < 2 && wx.showModal({
                            title: "提示",
                            content: "主账号：(" + c.users.nickname + ")的VIP已到期，请通知主账号续费！",
                            showCancel: !1,
                            complete: function(t) {
                                t.confirm && s.popup_switchUser.switchUserDo(o.data.user.id);
                            }
                        }), e.next = 9, l.mainDataReq(null, "getChildList");

                      case 9:
                        p = e.sent, g = p.data.list, 1010 == o.data.user.id && (f = i.childsList, m = [].concat(t(g), t(f)).reduce(function(t, e) {
                            return t.find(function(t) {
                                return t.id === e.id;
                            }) || t.push(e), t;
                        }, []), g = m), w = wx.getStorageSync("isCurrentUser"), (x = o.data.weChatConfig.rollmsgSet).msgList && (b = Math.floor(Math.random() * x.msgList.length), 
                        v = x.msgList[b], x.msg = v.quote + " --- " + v.author), r.setData({
                            weChatConfig: o.data.weChatConfig,
                            isCurrentUser: w,
                            parentUserinfo: c,
                            userInfo: o.data.user,
                            showNickname: o.data.user.nickname.substr(0, 6),
                            pageLoading: !1,
                            example: i,
                            childsList: g,
                            rollmsgSet: x
                        }), wx.setStorageSync("childsList", g), r.showAdd2MyMiniPro(), S = wx.createSelectorQuery(), 
                        "#hidden-buttons-container", S.select("#hidden-buttons-container").boundingClientRect(function(t) {
                            var e = 0, a = 0;
                            null !== t && (e = t.width, a = 0 - t.width), r.setData(n(n({}, "toolbar.width", e), "draggable.right", a));
                        }).exec();

                      case 21:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        },
        onLoad: function(t) {
            var r = this;
            return a(e().mark(function a() {
                var s, o, i, c, d;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (s = r, !t.hasOwnProperty("olduserid") || !t.olduserid) {
                            e.next = 17;
                            break;
                        }
                        return e.next = 4, u.loginRes(null, !0);

                      case 4:
                        return o = e.sent, wx.setStorageSync("loginResData", o), wx.setStorageSync("token", o.data.token), 
                        wx.setStorageSync("example", o.data.example), s.setData({
                            userInfo: o.data.user
                        }), e.next = 11, h.getOldUserInfo(t.olduserid);

                      case 11:
                        return e.sent, e.next = 14, l.mainDataReq(null, "getChildList");

                      case 14:
                        i = e.sent, wx.setStorageSync("childsList", i.data.list), s.setData({
                            childsList: i.data.list
                        });

                      case 17:
                        if (!t.hasOwnProperty("scene") || !t.scene) {
                            e.next = 24;
                            break;
                        }
                        return console.log("options.scene", t.scene), e.next = 21, h.getSceneContent(t.scene);

                      case 21:
                        c = e.sent, console.log("sceneInfo", c), null != c.data && c.data.hasOwnProperty("userid") && (t.promoter = c.data.userid);

                      case 24:
                        return e.next = 26, wx.getStorageSync("tabBarHeight");

                      case 26:
                        return d = e.sent, r.setData(n({
                            tabBarHeight: d,
                            headerTop: "Windows" == r.data.model ? 30 : 8
                        }, "draggable.bottom", wx.getStorageSync("tabBarHeight"))), r.calcUsableHeight([ "userinfo" ], 54 + r.data.headerTop), 
                        console.log("options", t), e.next = 32, u.userLogin(t);

                      case 32:
                        r.popup = r.selectComponent("#popup"), r.add2MyMiniPro = r.selectComponent("#add2MyMiniPro"), 
                        r.popup_switchUser = r.selectComponent("#Popup-switchUser"), r.updateData();

                      case 36:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        },
        createAnimation: function() {
            return console.log("创建动画"), wx.createAnimation({
                duration: 500,
                timingFunction: "linear"
            });
        },
        startAnimation1: function() {
            console.log("创建动画1");
            var t = this.createAnimation();
            this.data.toolbar.isOpen ? (console.log("恢复原位"), t.translateX(0).step()) : (console.log("向右移动"), 
            t.translateX("30px").step()), this.setData(n(n({}, "toolbar.animationData", t.export()), "toolbar.isOpen", !this.data.toolbar.isOpen));
        },
        test: function() {
            return a(e().mark(function t() {
                return e().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        tabbarOnload: function(t) {
            var e = t.detail.tabBarHeight;
            this.setData({
                tabBarHeight: e
            });
        },
        calcUsableHeight: function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, a = getApp().globalData.CustomBar, n = (this.data.tabBarHeight, 
            0);
            e > 0 && (n = e / (750 / wx.getSystemInfoSync().windowWidth));
            var r = this, s = getApp().globalData.screenHeight, o = 0, i = 0, c = wx.createSelectorQuery().in(this);
            t.forEach(function(e, u) {
                var l = "#".concat(e);
                c.select(l).boundingClientRect(function(e) {
                    e && e.height && (o += e.height), u === t.length - 1 && (s = s - o - n - a, r.setData({
                        usableHeight: s,
                        linemainHeight: i
                    }));
                });
            }), c.exec();
        },
        calcUsableHeight2: function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, a = this, n = getApp().globalData.screenHeight, r = 0, s = wx.createSelectorQuery().in(this);
            t.forEach(function(o, i) {
                var c = "#".concat(o);
                s.select(c).boundingClientRect(function(s) {
                    if (s && s.height && (r += s.height), i === t.length - 1) {
                        n = n - getApp().globalData.CustomBar - r - e;
                        var o = parseInt(wx.getStorageSync("tabBarHeight")), c = 0, u = setInterval(function() {
                            c += 200, "NaN" != o && o > 0 && (n = n - o - 36, clearInterval(u)), c > 1500 && clearInterval(u), 
                            a.setData({
                                usableHeight: n
                            });
                        }, 200);
                    }
                });
            }), s.exec();
        },
        showAdd2MyMiniPro: function() {
            var t = this;
            return a(e().mark(function a() {
                var n;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, h.checkMyMiniProgramStatus();

                      case 2:
                        (n = e.sent).added || wx.getStorageSync("childsList").length > 0 && setTimeout(function() {
                            t.add2MyMiniPro.show();
                        }, 3e3), n.added;

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        },
        goPage: function(t) {
            wx.navigateTo({
                url: t.currentTarget.dataset.url
            });
        },
        tabChange: function(t) {
            this.setData({
                value: t
            });
        },
        onChooseAvatar: function(t) {
            var e = t.detail.avatarUrl, a = this.data.userInfo.nickName;
            this.setData({
                "userInfo.avatarUrl": e,
                hasUserInfo: a && e && e !== c
            });
        },
        onInputChange: function(t) {
            var e = t.detail.value, a = this.data.userInfo.avatarUrl;
            this.setData({
                "userInfo.nickName": e,
                hasUserInfo: e && a && a !== c
            });
        },
        refreshBtn: function() {
            return a(e().mark(function t() {
                return e().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, u.userLogin(null, !0);

                      case 2:
                        wx.reLaunch({
                            url: "/pages/index/index"
                        });

                      case 3:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        showNotice: function(t) {
            wx.showModal({
                showCancel: !1,
                confirmText: "关闭",
                content: this.data.rollmsgSet.msg
            });
        },
        relogin: function() {
            return a(e().mark(function t() {
                return e().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, u.userLogin(null, !0);

                      case 2:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        onShow: function() {
            var t = this;
            return a(e().mark(function a() {
                var r, s, o, i, c, u;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        t.data.pageLoading || (r = wx.getStorageSync("childsList"), s = wx.getStorageSync("loginResData"), 
                        o = t.data.rollmsgSet.msgList, i = Math.floor(Math.random() * o.length), c = o[i], 
                        u = c.quote + " --- " + c.author, t.setData(n({
                            userInfo: s.data.user,
                            childsList: r,
                            showDelChildBtn: !1
                        }, "rollmsgSet.msg", u)));

                      case 1:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        },
        onShareAppMessage: function() {
            return {
                path: h.getCurrentPagePath() + "?promoterid=" + this.data.userInfo.id
            };
        }
    }
});