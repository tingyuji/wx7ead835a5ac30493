var t = require("../../@babel/runtime/helpers/defineProperty"), e = require("../../@babel/runtime/helpers/regeneratorRuntime"), n = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../utils/common"), o = require("../../utils/requestData"), i = new a.Common(), r = new o.requestData(), s = getApp();

Page({
    data: {
        app: s,
        tab_panel: 0,
        page: 0,
        pageCount: 0,
        wheelLottery: {
            wheelWidth: 300,
            fontsize: "16px",
            display: !0,
            points: 0,
            defaultConfig: [ {
                stopRange: 0,
                accelerationTime: 1500,
                decelerationTime: 1500,
                speed: 20,
                offsetDegree: 0
            } ],
            isRunning: !1,
            blocks: [ {
                padding: "10px",
                background: "#ffcf4d"
            } ],
            prizesList: [],
            buttons: [ {
                radius: "36px",
                background: "#ca1518"
            }, {
                radius: "30px",
                background: "#e62d2d",
                pointer: !0,
                fonts: [ {
                    text: "开始\n抽奖",
                    top: "-20px",
                    fontColor: "#ffef6c"
                } ]
            } ]
        },
        pageLoading: !0,
        lastLotteryLog: []
    },
    onTabsChange: function(t) {},
    onTabsClick: function(t) {
        var e = this.data.tab_panel;
        this.setData({
            tab_panel: t.detail.value
        }), e != parseInt(t.detail.value) && this.onTabsDo(t.detail.value);
    },
    onTabsDo: function(t) {
        var a = this;
        return n(e().mark(function n() {
            var o;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return o = [ "topinfo", "tabmaintitle", "line_main" ], e.next = 3, a.getChildLotteryLog(1);

                  case 3:
                    0 == t && (o = [ "topinfo", "tabmaintitle" ], a.setData({
                        pageCount: 1
                    })), a.calcUsableHeight(o);

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, n);
        }))();
    },
    getChildLotteryLogBtn: function(t) {
        var e = t.detail.page;
        this.getChildLotteryLog(e), console.log(e);
    },
    getChildLotteryLog: function() {
        var t = arguments, a = this;
        return n(e().mark(function n() {
            var o, i, s, c;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return o = t.length > 0 && void 0 !== t[0] ? t[0] : 1, i = -1, a.data.tab_panel > 0 && 1 == a.data.tab_panel && (i = 1), 
                    s = a.data.childid, e.next = 6, r.mainDataReq({
                        childid: s,
                        page: o,
                        iswin: i
                    }, "getChildLotteryLog", !0);

                  case 6:
                    if (null === (c = e.sent).data.msg) {
                        e.next = 10;
                        break;
                    }
                    return wx.showModal({
                        title: "提示",
                        content: c.data.msg
                    }), e.abrupt("return");

                  case 10:
                    return a.setData({
                        childLotteryLog: c.data.list,
                        page: o > 0 ? o : 1,
                        pageCount: c.data.pageCount,
                        pageLoading: !1
                    }), e.abrupt("return", c.data.pageCount);

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, n);
        }))();
    },
    prizesUsed: function(t) {
        var a = this;
        return n(e().mark(function o() {
            var i, s, c, l, d, u;
            return e().wrap(function(o) {
                for (;;) switch (o.prev = o.next) {
                  case 0:
                    i = a.data.childInfo, s = a.data.childLotteryLog, c = t.currentTarget.dataset.prizes, 
                    l = "该奖品(" + c.prizesname + ")已于" + c.usetime + "兑现！", d = !1, u = a, c.used || (l = "确定该奖品(" + c.prizesname + ")已为【" + i.nickname + "】兑现了吗？", 
                    d = !0), wx.showModal({
                        title: "提示",
                        content: l,
                        showCancel: d,
                        success: function() {
                            var t = n(e().mark(function t(n) {
                                var a, o;
                                return e().wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                      case 0:
                                        if (!n.confirm || c.used) {
                                            t.next = 6;
                                            break;
                                        }
                                        return t.next = 3, r.mainDataReq({
                                            childid: i.id,
                                            logid: c.id
                                        }, "prizesUsed");

                                      case 3:
                                        0 == (a = t.sent).data.code && (c.used = 1, c.usetime = a.data.usetime, o = s.findIndex(function(t) {
                                            return t.id === c.id;
                                        }), s[o] = c, u.setData({
                                            childLotteryLog: s
                                        })), wx.showToast(a.data.msg);

                                      case 6:
                                      case "end":
                                        return t.stop();
                                    }
                                }, t);
                            }));
                            return function(e) {
                                return t.apply(this, arguments);
                            };
                        }()
                    });

                  case 8:
                  case "end":
                    return o.stop();
                }
            }, o);
        }))();
    },
    popupClose: function() {
        this.setData(t({}, "wheelLottery.display", !0));
    },
    changeChildBtn: function(e) {
        console.log("chengeChildBtn"), this.popup.handlePopup(e);
        var n = e.currentTarget.dataset.popupname, a = e.currentTarget.dataset.popuptitle, o = e.currentTarget.dataset.placement;
        this.setData(t({
            popupname: n,
            popuptitle: a,
            placement: o
        }, "wheelLottery.display", !1)), this.selectComponent("#boxChangeChild").setData({
            childsList: wx.getStorageSync("childsList"),
            childInfo: i.findChild(this.data.childid)
        });
    },
    changeChildSuccess: function(a) {
        var o = this;
        return n(e().mark(function n() {
            var r, s;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return o.popup.close(), wx.showLoading({
                        title: "Loading"
                    }), r = a.detail.newChildid, s = i.findChild(r), o.setData(t({
                        childid: r,
                        childInfo: s,
                        pageLoading: !0,
                        page: 1
                    }, "wheelLottery.display", !0)), getApp().globalData.pageChildId = r, o.getLotteryPrizes(), 
                    e.next = 9, o.getChildLotteryLog(1);

                  case 9:
                    o.onTabsDo(o.data.tab_panel), wx.hideLoading();

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, n);
        }))();
    },
    getLotteryPrizes: function() {
        var a = this;
        return n(e().mark(function n() {
            var o, i, s, c, l, d;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return console.log("getLotteryPrizes"), o = a, e.next = 4, r.mainDataReq(null, "getLotteryPrizesList");

                  case 4:
                    i = e.sent, s = i.data.lotteryPrizes.list, c = [], s.length > 0 && (l = 0, s.forEach(function(t, e) {
                        var n = new o.wheelPrizes();
                        l += Number(t.range), n.background = "#ffe4d6", n.fonts[0].text = t.prizesname, 
                        o.isEvenOrOdd(e, 2) && (n.background = "#fff8f4"), c.push(n);
                    }), l < 100 && ((d = new o.wheelPrizes()).background = "#fbeded", d.imgs[0].src = "/images/goodluck.png", 
                    c.push(d)), a.setData(t(t({}, "wheelLottery.prizesList", c), "pageLoading", !1)));

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, n);
        }))();
    },
    wheelPrizes: function() {
        this.background = "#ffe4d6", this.fonts = [ {
            fontColor: "#792d13",
            fontSize: "15px",
            lineHeight: "17px",
            text: "未中奖",
            top: "30%"
        } ], this.imgs = [ {
            src: "/images/gift.png",
            top: "5%",
            width: "60rpx"
        } ], this.index, this.range = 0;
    },
    allWinRange: function(t) {
        var e = 0;
        try {
            t.forEach(function(t, n, a) {
                e += Number(t.range);
            });
        } catch (t) {}
        return e;
    },
    start: function() {
        var a = this;
        return n(e().mark(function n() {
            var o, s, c, l, d;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (o = a, !a.data.wheelLottery.isRunning) {
                        e.next = 3;
                        break;
                    }
                    return e.abrupt("return");

                  case 3:
                    return s = a.selectComponent("#lucky-wheel"), 2500, c = -1, e.next = 8, r.mainDataReq({
                        childid: a.data.childid
                    }, "lottery", !1);

                  case 8:
                    0 == (l = e.sent).data.code ? (-1 == (c = l.data.prizes.index) && (c = a.data.wheelLottery.prizesList.length - 1), 
                    s.lucky.play(), (d = o.data.childInfo).points = d.points - o.data.userInfo.lotterypoints, 
                    o.setData(t(t(t({}, "wheelLottery.isRunning", !0), "childInfo", d), "lastLotteryLog", l.data.prizes)), 
                    i.upDateLocalChildList(d), setTimeout(function() {
                        s.lucky.stop(c);
                    }, 2500)) : i._showMsg(l.data.msg);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, n);
        }))();
    },
    end: function(e) {
        console.log(e);
        var n = this.data.lastLotteryLog, a = this.data.childLotteryLog;
        1 == this.data.page && (a.unshift({
            child_id: this.data.childid,
            datetime: n.datetime,
            id: n.logid,
            iswin: n.iswin,
            prizesname: n.prizesname,
            used: 0,
            usepoints: n.usepoints,
            usetime: null
        }), a.pop()), this.setData(t(t(t({}, "wheelLottery.isRunning", !1), "childLotteryLog", a), "lastLotteryLog", {})), 
        wx.showModal({
            title: "抽奖结果：",
            showCancel: !1,
            content: e.detail.fonts[0].text
        });
    },
    calcWheelWidth: function() {
        var e = getApp().globalData.screenWidth - 10, n = getApp().globalData.screenHeight - getApp().globalData.CustomBar - 96 / (750 / wx.getSystemInfoSync().windowWidth);
        e > n && (e = n), "Windows" == getApp().globalData.model && console.log("isWindows"), 
        this.setData(t({}, "wheelLottery.wheelWidth", e)), console.log(e);
    },
    isEvenOrOdd: function(t, e) {
        return t % e == 0;
    },
    goPage: function(t) {
        wx.navigateTo({
            url: t.currentTarget.dataset.url
        });
    },
    calcUsableHeight: function(t) {
        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, n = 0;
        this.data.pageCount > 1 && (n += 80), e > 0 && (n = e / (750 / wx.getSystemInfoSync().windowWidth));
        var a = this, o = getApp().globalData.screenHeight - getApp().globalData.CustomBar, i = 0, r = wx.createSelectorQuery().in(this);
        t.forEach(function(e, s) {
            var c = "#".concat(e);
            r.select(c).boundingClientRect(function(e) {
                console.log(e), e && e.height && (console.log("".concat(c, " 的高度:"), e.height), 
                i += e.height), s === t.length - 1 && (console.log(o), console.log("totalHeight", i), 
                console.log("otherHeight", n), console.log("所有元素的总高度:", i), o = o - i - n, a.setData({
                    usableHeight: o
                }), console.log("剩余可用", o));
            });
        }), r.exec();
    },
    onLoad: function(t) {
        var a = this;
        return n(e().mark(function n() {
            var o, i, r, s, c;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    a.calcUsableHeight([ "topinfo", "tabmaintitle" ]), a.popup = a.selectComponent("#popup"), 
                    o = parseInt(t.childid), ((i = wx.getStorageSync("childsList")).length < 1 || "undefined" == o) && a.goHomePage(), 
                    (r = i.findIndex(function(t) {
                        return t.id === o;
                    })) < 0 && a.goHomePage(), s = wx.getStorageSync("loginResData"), c = s.data.user, 
                    a.setData({
                        childid: t.childid,
                        childInfo: i[r],
                        childsList: i,
                        userInfo: c
                    }), a.getLotteryPrizes(), a.calcWheelWidth();

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, n);
        }))();
    },
    onReady: function() {},
    onShow: function() {
        this.data.pageLoading || (this.getLotteryPrizes(), console.log("onShow"));
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var t = i.getCurrentPagePath();
        return console.log(t), {
            path: t + "?promoterid=" + this.data.userInfo.id
        };
    }
});