var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../../utils/requestData"), n = require("../../../utils/common"), o = require("../../../utils/safecode"), r = new a.requestData(), s = new n.Common(), i = new o.Safecode();

Page({
    data: {
        showDelBtn: !1,
        allWinRange: 0,
        pageLoading: !0,
        safeCodeLen: 4
    },
    showDelBtn: function() {
        this.setData({
            showDelBtn: !this.data.showDelBtn
        });
    },
    addnewPrizesBtn: function(e) {
        this.handlePopup(e), this.data.showDelBtn && this.setData({
            showDelBtn: !this.data.showDelBtn
        });
    },
    lotteryPrizesSuccess: function(e) {
        var t = e.detail.lotteryPrizes;
        this.setData({
            lotteryPrizes: t,
            allWinRange: this.allWinRange(t.list)
        }), this.popup.close();
    },
    editPrizesBtn: function(e) {
        this.data.lotteryPrizes.isDefault || this.handlePopup(e);
    },
    delPrizesBtn: function(a) {
        var n = this;
        return t(e().mark(function o() {
            var i, c, l;
            return e().wrap(function(o) {
                for (;;) switch (o.prev = o.next) {
                  case 0:
                    i = n, c = a.currentTarget.dataset.prizes, l = c.id, wx.showModal({
                        title: "提示",
                        confirmText: "确定删除",
                        content: "确定要删除【" + c.prizesname + "】吗？",
                        complete: function() {
                            var a = t(e().mark(function t(a) {
                                var o;
                                return e().wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                      case 0:
                                        if (!a.confirm) {
                                            e.next = 10;
                                            break;
                                        }
                                        if (!i.data.lotteryPrizes.isDefault) {
                                            e.next = 5;
                                            break;
                                        }
                                        return s.showmsg("当前是系统示例，不能删除！新增自己的奖品后会自动消失！"), i.setData({
                                            showDelBtn: !1
                                        }), e.abrupt("return");

                                      case 5:
                                        return e.next = 7, r.mainDataReq({
                                            id: l
                                        }, "delLotteryPrizes");

                                      case 7:
                                        o = e.sent, wx.showToast({
                                            title: o.data.msg.title,
                                            icon: o.data.msg.icon
                                        }), 0 === o.data.code && i.setData({
                                            lotteryPrizes: o.data.lotteryPrizes,
                                            allWinRange: n.allWinRange(o.data.lotteryPrizes.list)
                                        });

                                      case 10:
                                      case "end":
                                        return e.stop();
                                    }
                                }, t);
                            }));
                            return function(e) {
                                return a.apply(this, arguments);
                            };
                        }()
                    });

                  case 4:
                  case "end":
                    return o.stop();
                }
            }, o);
        }))();
    },
    handlePopup: function(e) {
        this.popup.handlePopup();
        var t = e.currentTarget.dataset.popupname, a = e.currentTarget.dataset.popuptitle, n = e.currentTarget.dataset.placement, o = e.currentTarget.dataset.prizes;
        this.setData({
            popupname: t,
            popuptitle: a,
            placement: n,
            editprizes: o
        });
    },
    updateData: function() {
        var a = this;
        return t(e().mark(function t() {
            var n, o, s, i;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, r.mainDataReq(null, "getLotteryPrizesList");

                  case 2:
                    n = e.sent, o = n.data.lotteryPrizes, s = wx.getStorageSync("loginResData"), i = a.allWinRange(o.list), 
                    a.calcUsableHeight([ "bottominfo", "line_main", "allWinRange", "note" ], 4), a.setData({
                        weChatConfig: s.data.weChatConfig,
                        lotteryPrizes: o,
                        allWinRange: i,
                        pageLoading: !1
                    });

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    safecodeCheckCallbak: function(e) {
        this.setData({
            safecodeState: !0
        }), this.safecodeBox.close(), this.updateData();
    },
    checkSafecodeBoxCancel: function() {
        this.safecodeBox.close(), wx.navigateBack();
    },
    onLoad: function(a) {
        var n = this;
        return t(e().mark(function t() {
            var a;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n.popup = n.selectComponent("#popup"), n.safecodeBox = n.selectComponent("#safecodeBox"), 
                    e.next = 4, i.safecodeState();

                  case 4:
                    (a = e.sent) ? n.updateData() : (n.setData({
                        popupname: "checksafecode",
                        placement: "center",
                        popuptitle: "请输入安全码",
                        safecodeCheckCallbak: "safecodeCheckCallbak"
                    }), n.safecodeBox.show()), n.setData({
                        safecodeState: a
                    });

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    allWinRange: function(e) {
        var t = 0;
        try {
            e.forEach(function(e, a, n) {
                t += Number(e.range);
            });
        } catch (e) {}
        return t;
    },
    calcUsableHeight: function(e) {
        var t = this, a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, n = this, o = getApp().globalData.screenHeight, r = 0, s = wx.createSelectorQuery().in(this);
        e.forEach(function(i, c) {
            var l = "#".concat(i);
            s.select(l).boundingClientRect(function(s) {
                console.log(s), s && s.height && "allWinRange" != i && (console.log("".concat(l, " 的高度:"), s.height), 
                r += s.height), s && s.height && "allWinRange" == i && t.setData({
                    allWinRangeLineHeight: s.height
                }), c === e.length - 1 && (console.log("所有元素的总高度:", r), o = o - getApp().globalData.CustomBar - r - a, 
                n.setData({
                    usableHeight: o
                }), console.log("剩余可用", o));
            });
        }), s.exec();
    },
    onReady: function() {},
    onShow: function() {
        var a = this;
        return t(e().mark(function t() {
            var n, o;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (a.data.pageLoading) {
                        e.next = 6;
                        break;
                    }
                    return e.next = 3, r.mainDataReq(null, "getLotteryPrizesList");

                  case 3:
                    n = e.sent, o = a.allWinRange(n.data.list), a.setData({
                        lotteryPrizeslist: n.data.list,
                        allWinRange: o
                    });

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = s.getCurrentPagePath();
        return console.log(e), {
            path: e + "?promoterid=" + this.data.userInfo.id
        };
    }
});