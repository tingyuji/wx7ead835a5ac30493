var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), n = new (require("../../utils/requestData").requestData)(), r = new Array(12).fill({
    label: "标题文字",
    image: "https://tdesign.gtimg.com/mobile/demos/example2.png"
}, 0, 12);

Page({
    offsetTopList: [],
    data: {
        app: getApp(),
        sideBarIndex: 1,
        scrollTop: 0,
        categories: [ {
            label: "推广码",
            title: "推广码",
            badgeProps: {},
            items: r
        }, {
            label: "推广成果",
            title: "推广成果",
            badgeProps: {
                dot: !0
            },
            items: r.slice(0, 9)
        }, {
            label: "我的信息",
            title: "我的信息"
        } ],
        navbarHeight: 0,
        userInfo: null,
        promoterInfo: null
    },
    test2: function() {
        return t(e().mark(function t() {
            var r;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, n.getPromoterQRcode(null);

                  case 2:
                    return r = e.sent, console.log(r.data.data.qrcodeUrl), e.abrupt("return");

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onLoad: function(r) {
        var a = this;
        return t(e().mark(function t() {
            var r, o;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = wx.getStorageSync("loginResData"), e.next = 3, n.mainDataReq(null, "getPromoter");

                  case 3:
                    if (2 != (o = e.sent).data.code) {
                        e.next = 7;
                        break;
                    }
                    return wx.reLaunch({
                        url: "/pages/index/index"
                    }), e.abrupt("return");

                  case 7:
                    a.setData({
                        userInfo: r.data.user,
                        promoterInfo: o.data
                    }), console.log(o), a.getCustomNavbarHeight();

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    getCustomNavbarHeight: function() {
        var e = this, t = wx.createSelectorQuery();
        t.select(".custom-navbar").boundingClientRect(), t.exec(function(t) {
            var n = (t[0] || {}).height, r = void 0 === n ? 0 : n;
            e.setData({
                navbarHeight: r
            });
        });
    },
    onSideBarChange: function(e) {
        var t = e.detail.value;
        this.setData({
            sideBarIndex: t,
            scrollTop: 0
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});