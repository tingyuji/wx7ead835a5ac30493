var t = require("../../utils/util.js");

Component({
    data: {
        logs: []
    },
    lifetimes: {
        attached: function() {
            this.setData({
                logs: (wx.getStorageSync("logs") || []).map(function(e) {
                    return {
                        date: t.formatTime(new Date(e)),
                        timeStamp: e
                    };
                })
            });
        }
    }
});