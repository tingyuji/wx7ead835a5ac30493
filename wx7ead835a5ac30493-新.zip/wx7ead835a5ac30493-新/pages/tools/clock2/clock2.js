Page({
    data: {
        hours: [ "0", "0" ],
        minutes: [ "0", "0" ],
        seconds: [ "0", "0" ],
        nextHours: [ "0", "0" ],
        nextMinutes: [ "0", "0" ],
        nextSeconds: [ "0", "0" ],
        isFlipping: !1
    },
    onLoad: function() {
        this.updateClock(), this.intervalId = setInterval(this.updateClock, 1e3);
    },
    onUnload: function() {
        clearInterval(this.intervalId);
    },
    updateClock: function() {
        var t = this, i = new Date(), s = String(i.getHours()).padStart(2, "0").split(""), n = String(i.getMinutes()).padStart(2, "0").split(""), e = String(i.getSeconds()).padStart(2, "0").split("");
        if (this.shouldFlip(this.data.hours, s) || this.shouldFlip(this.data.minutes, n) || this.shouldFlip(this.data.seconds, e)) {
            if (this.data.isFlipping) return;
            this.setData({
                nextHours: s,
                nextMinutes: n,
                nextSeconds: e,
                isFlipping: !0
            }), setTimeout(function() {
                t.setData({
                    hours: s,
                    minutes: n,
                    seconds: e,
                    isFlipping: !1
                });
            }, 500);
        }
    },
    shouldFlip: function(t, i) {
        for (var s = 0; s < t.length; s++) if (t[s] !== i[s]) return !0;
        return !1;
    }
});