var e = wx.worklet;

e.shared, e.spring;

Page({
    data: {
        nowDate: "",
        rotate: 0,
        isShowNavbar: !1,
        clockwidth: getApp().globalData.safeArea.width,
        clockheight: getApp().globalData.safeArea.height,
        CustomBar: getApp().globalData.CustomBar,
        showBrightnessTool: !1,
        newBrightness: null
    },
    showBrightnessTool: function() {
        this.setData({
            isShowNavbar: !this.data.isShowNavbar
        }), this.data.isShowNavbar;
    },
    hideBrightnessTool: function() {
        var e = this;
        console.log("hideBrightnessTool"), setTimeout(function() {
            e.setData({
                isShowNavbar: !1
            });
        }, 2e3);
    },
    handleChange: function(e) {
        var t = e.detail.value / 100;
        wx.setScreenBrightness({
            value: t
        }), this.setData({
            showBrightnessTool: !0,
            newBrightness: t
        }), console.log(e.detail.value / 100);
    },
    onLoad: function() {
        var e = this;
        wx.getScreenBrightness({
            success: function(t) {
                1 != t.value && wx.setScreenBrightness({
                    value: t.value
                }), e.setData({
                    defaultBrightness: t.value
                }), console.log(t.value), console.log(e.data.defaultBrightness);
            }
        }), wx.setKeepScreenOn({
            keepScreenOn: !0
        }), wx.setScreenBrightness({
            value: 1
        }), this.setTimeRunner();
    },
    setTimeRunner: function() {
        var e = this;
        this.timeRunner = setInterval(function() {
            e.getTimeStr(), e.getTimeArr();
        }, 200);
    },
    getTimeStr: function() {
        var e = new Date(), t = (("0" + e.getHours()).slice(-2) + ("0" + e.getMinutes()).slice(-2) + ("0" + e.getSeconds()).slice(-2)).split(""), s = e.getFullYear(), a = ("0" + (e.getMonth() + 1)).slice(-2), n = ("0" + e.getDate()).slice(-2), i = s + " 年 " + a + " 月 " + n + " 日";
        this.setData({
            timeStr: t,
            dateStr: i,
            year: s,
            month: a,
            date: n
        });
    },
    getTimeArr: function() {
        var e = this.data.timeStr.map(function(e, t) {
            var s;
            return !0 & t ? s = 9 : 0 == t ? s = 2 : (2 == t || 4 == t) && (s = 5), {
                max: s,
                current: Number(e)
            };
        });
        this.setData({
            timeArr: e
        });
    },
    beforeDestroy: function() {
        clearInterval(this.timeRunner);
    },
    onUnload: function() {
        this.beforeDestroy();
    }
});