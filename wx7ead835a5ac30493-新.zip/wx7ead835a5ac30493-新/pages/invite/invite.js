var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), n = require("../../@babel/runtime/helpers/asyncToGenerator"), t = require("../../utils/common"), r = require("../../utils/requestData"), a = require("../../utils/login"), i = new r.requestData(), o = new t.Common(), s = new a.Login();

Page({
    data: {
        timeOut: !0,
        isSelf: !1
    },
    accepted: function(t) {
        var r = this;
        return n(e().mark(function n() {
            var t, a, u;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return t = r.data.inviteId, e.next = 3, i.mainDataReq({
                        inviteId: t
                    }, "acceptInvite");

                  case 3:
                    if (a = e.sent, o._showMsg(a.data.msg), 0 != a.data.code) {
                        e.next = 11;
                        break;
                    }
                    return e.next = 8, s.userLogin(null, !0);

                  case 8:
                    u = wx.getStorageSync("loginResData"), r.setData({
                        userInfo: u.data.user
                    }), setTimeout(function() {
                        wx.switchTab({
                            url: "/pages/index/index"
                        });
                    }, 1e3);

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, n);
        }))();
    },
    refuse: function(e) {},
    onLoad: function(t) {
        var r = this;
        return n(e().mark(function n() {
            var a, o;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (a = wx.getStorageSync("loginResData")) {
                        e.next = 5;
                        break;
                    }
                    return e.next = 4, s.userLogin(t);

                  case 4:
                    a = wx.getStorageSync("loginResData");

                  case 5:
                    if ("inviteid" in t) {
                        e.next = 8;
                        break;
                    }
                    return wx.navigateTo({
                        url: "/pages/index/index?from=invite"
                    }), e.abrupt("return");

                  case 8:
                    return console.log(t), o = parseInt(t.inviteid), e.next = 12, i.mainDataReq({
                        inviteId: o
                    }, "getInvite");

                  case 12:
                    return e.sent.userid == a.data.user.id && r.setData({
                        isSelf: !0
                    }), r.setData({
                        inviteId: o
                    }), e.abrupt("return");

                  case 20:
                  case "end":
                    return e.stop();
                }
            }, n);
        }))();
    },
    getInvite: function(t) {
        return n(e().mark(function n() {
            var t;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, i.mainDataReq({}, "getInvite");

                  case 2:
                    t = e.sent, console.log(t);

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, n);
        }))();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});