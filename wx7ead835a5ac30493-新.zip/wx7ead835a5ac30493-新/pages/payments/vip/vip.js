var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), n = require("../../../@babel/runtime/helpers/asyncToGenerator"), t = new (require("../../../utils/requestData").requestData)();

Page({
    data: {
        current: 3
    },
    gopay: function() {
        var a = this;
        return n(e().mark(function n() {
            var r, i, o, u;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r = a.data.current, i = a.data.viplevels, "" != (o = i[r]).price.trim()) {
                        e.next = 6;
                        break;
                    }
                    return wx.showToast({
                        title: "金额错误",
                        icon: "none",
                        duration: 1e3
                    }), e.abrupt("return", !1);

                  case 6:
                    return e.next = 8, t.orderDataReq({
                        id: a.data.userInfo.id,
                        vipid: o.id,
                        type: "buyvip"
                    });

                  case 8:
                    return u = e.sent, console.log(u), wx.requestOrderPayment({
                        timeStamp: String(u.data.timeStamp),
                        nonceStr: u.data.nonceStr,
                        package: u.data.package,
                        signType: "RSA",
                        paySign: u.data.paySign,
                        success: function(e) {
                            console.log(e), wx.showToast({
                                title: "支付成功!",
                                icon: "success",
                                duration: 1e3
                            });
                        },
                        fail: function(e) {
                            console.log(e);
                        }
                    }), e.abrupt("return");

                  case 14:
                  case "end":
                    return e.stop();
                }
            }, n);
        }))();
    },
    onChange: function(e) {
        var n = e.detail.value;
        this.setData({
            current: n
        });
    },
    find: function(e) {
        var n = this.data.viplevels, t = n.findIndex(function(n) {
            return n.id === e;
        });
        return t >= 0 ? n[t] : null;
    },
    onLoad: function(a) {
        var r = this;
        return n(e().mark(function n() {
            var a, i, o, u;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a = wx.getStorageSync("loginResData"), i = a.data.user, e.next = 4, t.mainDataReq(null, "getVipPrice");

                  case 4:
                    o = e.sent, u = o.data.findIndex(function(e) {
                        return 1 == e.default;
                    }), r.setData({
                        userInfo: i,
                        weChatConfig: a.data.weChatConfig,
                        viplevels: o.data,
                        current: u
                    });

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, n);
        }))();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});