var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../../@babel/runtime/helpers/defineProperty"), n = require("../../../utils/requestData"), o = require("../../../utils/common"), i = require("../../../utils/login"), s = new n.requestData(), r = new o.Common(), u = new i.Login();

Page({
    data: {
        switchVal_isPublic: !0,
        showDelBtn: !1,
        isDisable: !0,
        pageLoading: !0,
        editRulenameInputVal: ""
    },
    switchHandleChange: function(e) {
        this.setData({
            switchVal_isPublic: e.detail.value
        });
    },
    inputDisabled: function() {
        this.setData({
            isDisable: !1
        });
    },
    showDelBtn: function() {
        this.setData({
            showDelBtn: !this.data.showDelBtn
        });
    },
    addRuleCauseBtn: function(e) {
        this.data.rule.editable ? this.handlePopup(e) : wx.showToast({
            title: "无权限",
            icon: "error"
        });
    },
    saveCauseSuccess: function(e) {
        var t = e.detail.causelist;
        e.detail.type;
        this.setData(a({}, "rule.causelist", t)), this.popup.close();
    },
    editRuleCauseBtn: function(e) {
        this.data.rule.editable && this.handlePopup(e);
    },
    editRuleinfoBtn: function(e) {
        this.data.rule.editable ? this.handlePopup(e) : wx.showToast({
            title: "无权限",
            icon: "error"
        });
    },
    handDelBtn: function(n) {
        if (1001 != this.data.rule.info.create_userid) {
            var o, i = this, r = n.currentTarget.dataset.index, u = n.currentTarget.dataset.causeid;
            wx.showModal({
                title: "提示",
                content: "确定要删除第【" + (r + 1) + "】个事件吗？",
                success: (o = t(e().mark(function t(n) {
                    var o, l, c, d;
                    return e().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (!n.confirm) {
                                e.next = 10;
                                break;
                            }
                            return console.log("用户点击确定"), o = {
                                index: r,
                                causeid: u
                            }, e.next = 5, s.mainDataReq(o, "delRuleCause");

                          case 5:
                            (l = e.sent).data.state && (i.data.rule.causelist.splice(r, 1), c = i.data.rule.causelist.length, 
                            d = i.data.showDelBtn, c <= 0 && (d = !1), i.setData(a(a({
                                pageLoading: !1
                            }, "rule.causelist", i.data.rule.causelist), "showDelBtn", d))), wx.showToast({
                                title: l.data.msg.title,
                                icon: l.data.msg.icon
                            }), e.next = 11;
                            break;

                          case 10:
                            n.cancel && console.log("用户点击取消");

                          case 11:
                          case "end":
                            return e.stop();
                        }
                    }, t);
                })), function(e) {
                    return o.apply(this, arguments);
                })
            });
        } else wx.showModal({
            title: "提示",
            content: "这是系统默认事件作为演示用，不能删除！"
        });
    },
    handlePopup: function(e) {
        this.data.showDelBtn && this.setData({
            showDelBtn: !1
        }), this.popup.handlePopup(e), console.log(e);
        var t = e.currentTarget.dataset.popupname, a = e.currentTarget.dataset.placement, n = e.currentTarget.dataset.popuptitle;
        switch (this.setData({
            popupname: t
        }), t) {
          case "editRuleCause":
            this.selectComponent("#addrulecauseBox").setData({
                editItem: e.currentTarget.dataset.item
            });
        }
        this.setData({
            popupname: t,
            popuptitle: n,
            placement: a
        });
    },
    closePopup: function() {
        this.popup.close();
    },
    showDescBtn: function(e) {
        console.log(e), this.handlePopup(e);
    },
    editRuleinfo: function(e) {
        this.handlePopup(e);
    },
    copy2MyBtn: function() {
        this.copyRule2My();
    },
    copyRule2My: function() {
        var a = this;
        return t(e().mark(function t() {
            var n;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, s.mainDataReq({
                        fromRuleid: a.data.ruleid
                    }, "copyRule2My");

                  case 2:
                    (n = e.sent).data.state ? wx.showModal({
                        title: "提示",
                        content: n.data.msg.title,
                        showCancel: !1,
                        complete: function(e) {
                            e.confirm && wx.navigateTo({
                                url: "/pages/pointsrule/rulelist/rulelist"
                            });
                        }
                    }) : wx.showToast({
                        title: n.data.msg.title,
                        icon: n.data.msg.icon
                    });

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    handleDelRule: function() {
        var e = this;
        wx.showModal({
            title: "提示",
            content: "确定要删除本规则吗？",
            success: function(t) {
                t.confirm && 1001 != e.data.rule.info.create_userid && e.delRule(e.data.rule.info.id);
            }
        });
    },
    delRule: function(a) {
        return t(e().mark(function t() {
            var n;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, s.mainDataReq({
                        ruleid: a
                    }, "delRule");

                  case 2:
                    n = e.sent, wx.showToast({
                        title: n.data.msg.title,
                        icon: n.data.msg.icon
                    }), n.data.state && setTimeout(function() {
                        wx.navigateBack();
                    }, 1500);

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    changeEditRulenameInputVal: function(e) {
        var t = e.detail.value;
        this.setData({
            editRulenameInputVal: t
        });
    },
    calcUsableHeight: function(e) {
        var t = this, a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, n = this;
        console.log(this.data.tabSelectIndex);
        var o = getApp().globalData.screenHeight;
        console.log(getApp().globalData.screenHeight), console.log(getApp().globalData.CustomBar);
        var i = 0, s = wx.createSelectorQuery().in(this);
        e.forEach(function(r, u) {
            var l = "#".concat(r);
            s.select(l).boundingClientRect(function(s) {
                console.log(s), s && s.height && (console.log("".concat(l, " 的高度:"), s.height), 
                i += s.height, "bottominfo" == r && t.setData({
                    bottominfoHeight: s.height
                })), u === e.length - 1 && (console.log("所有元素的总高度:", i), o = o - getApp().globalData.CustomBar - i - a, 
                n.setData({
                    usableHeight: o
                }), console.log("剩余可用", o));
            });
        }), s.exec();
    },
    updateData: function() {
        var a = this;
        return t(e().mark(function t() {
            var n, o, i;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n = wx.getStorageSync("loginResData"), o = a.data.ruleid, e.next = 4, s.mainDataReq({
                        id: o,
                        showCauselist: 1
                    }, "getRule");

                  case 4:
                    i = e.sent, a.setData({
                        weChatConfig: n.data.weChatConfig,
                        userInfo: n.data.user,
                        pageLoading: !1,
                        rule: i.data
                    }), a.calcUsableHeight([ "ruleName", "toolsList", "itemListMain", "bottominfo" ], 10);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onLoad: function(a) {
        var n = this;
        return t(e().mark(function t() {
            var o;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    o = a.id, n.setData({
                        ruleid: o
                    }), u.userLogin(), n.updateData(), n.popup = n.selectComponent("#popup");

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onReady: function() {},
    onShow: function() {
        var a = this;
        return t(e().mark(function t() {
            var n, o;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (a.data.pageLoading) {
                        e.next = 6;
                        break;
                    }
                    return n = a.data.ruleid, e.next = 4, s.mainDataReq({
                        id: n,
                        showCauselist: 1
                    }, "getRule");

                  case 4:
                    o = e.sent, a.setData({
                        pageLoading: !1,
                        rule: o.data
                    });

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = r.getCurrentPagePath();
        return console.log(e), {
            path: e + "?promoterid=" + this.data.userInfo.id
        };
    }
});