var e = require("../../../@babel/runtime/helpers/defineProperty"), t = require("../../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../../utils/login"), o = require("../../../utils/requestData"), s = require("../../../utils/safecode"), i = (new n.Login(), 
new o.requestData()), l = new s.Safecode();

Page({
    data: {
        tabSelectIndex: 0,
        pageLoading: !0,
        tabPanelstyle: "display:flex;justify-content:center;align-items:center;",
        xx: 0
    },
    onTabsChange: function(e) {
        var n = this;
        return a(t().mark(function a() {
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    n.setData({
                        ruleList: null,
                        pageLoading: !0,
                        tabSelectIndex: e.detail.value
                    }), n.listRules(e.detail.value);

                  case 2:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    onTabsClick: function(e) {
        console.log("Click tab, tab-panel value is ".concat(e.detail.value, "."));
    },
    listRules: function() {
        var e = arguments, n = this;
        return a(t().mark(function a() {
            var o, s;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return o = e.length > 0 && void 0 !== e[0] ? e[0] : 0, t.next = 3, i.mainDataReq({
                        isPublic: o
                    }, "listRules");

                  case 3:
                    s = t.sent, n.setData({
                        pageLoading: !1,
                        ruleList: s.data.list
                    });

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    showDelRuleBtn: function() {
        console.log("showDelRuleBtn"), this.setData({
            showDelRuleBtn: !this.data.showDelRuleBtn
        });
    },
    handleDelRule: function(e) {
        console.log(e);
        var t = this, a = (e.currentTarget.dataset.index, e.currentTarget.dataset.ruleid), n = "确定要删除【" + e.currentTarget.dataset.rulename + "】吗？", o = this.data.ruleList.find(function(e) {
            return e.id === a;
        });
        1001 == o.create_userid && (n = "这是系统默认规则作为演示用，不能删除。当您添加自己的规则后，该条规则会自动消失！"), wx.showModal({
            title: "提示",
            content: n,
            success: function(e) {
                e.confirm ? 1001 != o.create_userid && t.delRule(a) : e.cancel && console.log("用户点击取消");
            }
        });
    },
    delRule: function(n) {
        var o = this;
        return a(t().mark(function a() {
            var s, l;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return s = o, t.next = 3, i.mainDataReq({
                        ruleid: n
                    }, "delRule");

                  case 3:
                    (l = t.sent).data.state && s.setData(e({}, "ruleList", l.data.list)), wx.showToast({
                        title: l.data.msg.title,
                        icon: l.data.msg.icon
                    });

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    addNewRuleBtn: function(e) {
        0 === this.data.ruleList.length && (this.addnewrulebox = this.selectComponent("#addnewrulebox"), 
        this.addnewrulebox.setData({
            switchVal_isDefault: !0,
            isDisabled: !0
        }), console.log(this.addnewrulebox)), this.popup.handlePopup(e);
    },
    goPage1: function(e) {
        this.data.showDelRuleBtn || this.goPage(e);
    },
    goPage: function(e) {
        var t = e.currentTarget.dataset.url;
        wx.navigateTo({
            url: t
        });
    },
    calcUsableHeight: function(e) {
        var t = this, a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, n = this;
        console.log(this.data.tabSelectIndex);
        var o = getApp().globalData.screenHeight;
        console.log(getApp().globalData.screenHeight), console.log(getApp().globalData.CustomBar);
        var s = 0, i = wx.createSelectorQuery().in(this);
        e.forEach(function(l, r) {
            var c = "#".concat(l);
            i.select(c).boundingClientRect(function(i) {
                console.log(i), i && i.height && (console.log("".concat(c, " 的高度:"), i.height), 
                s += i.height, "bottominfo" == l && t.setData({
                    bottominfoHeight: i.height
                })), r === e.length - 1 && (console.log("所有元素的总高度:", s), o = o - getApp().globalData.CustomBar - s - a, 
                n.setData({
                    usableHeight: o
                }), console.log("剩余可用", o));
            });
        }), i.exec();
    },
    onLoad: function(e) {
        var n = this;
        return a(t().mark(function e() {
            var a;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n.safecodeBox = n.selectComponent("#safecodeBox"), e.next = 3, l.safecodeState();

                  case 3:
                    a = e.sent, n.setData({
                        safecodeState: a
                    }), a ? n.updateData() : (n.setData({
                        popupname: "checksafecode",
                        placement: "center",
                        popupTitle: "请输入安全码",
                        safecodeCheckCallbak: "safecodeCheckCallbak"
                    }), n.safecodeBox.show());

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    safecodeCheckCallbak: function(e) {
        this.setData({
            safecodeState: !0
        }), this.safecodeBox.close(), this.updateData();
    },
    checkSafecodeBoxCancel: function() {
        this.safecodeBox.close(), wx.navigateBack();
    },
    updateData: function() {
        this.listRules();
        var e = wx.getStorageSync("loginResData");
        this.setData({
            weChatConfig: e.data.weChatConfig,
            userInfo: e.data.user
        }), this.calcUsableHeight([ "tabmaintitle", "bottominfo" ], 0), this.popup = this.selectComponent("#popup");
    },
    onReady: function() {},
    onShow: function() {
        this.data.pageLoading || this.listRules(this.data.tabSelectIndex);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = common.getCurrentPagePath();
        return console.log(e), {
            path: e + "?promoterid=" + this.data.userInfo.id
        };
    }
});