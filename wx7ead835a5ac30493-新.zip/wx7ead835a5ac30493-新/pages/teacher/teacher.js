var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../@babel/runtime/helpers/asyncToGenerator"), t = require("../../utils/common"), o = getApp(), n = "https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0", r = new t.Common();

Component({
    data: {
        model: o.globalData.model,
        headerTop: 0,
        nickname: "微信用户1001234",
        safeArea: o.globalData.safeArea,
        screenHeight: o.globalData.screenHeight,
        CustomBar: o.globalData.CustomBar,
        listScrollHeight: 300,
        tabbarValue: "/pages/index/index",
        userAvatar: "https://alifei04.cfp.cn/creative/vcg/800/new/VCG41N152985209.jpg",
        motto: "Hello World",
        userInfo: {
            avatarUrl: n,
            nickName: ""
        },
        hasUserInfo: !1,
        canIUseGetUserProfile: wx.canIUse("getUserProfile"),
        canIUseNicknameComp: wx.canIUse("input.type.nickname")
    },
    methods: {
        click: function() {
            console.log("按钮被点击了！");
        },
        onLoad: function(t) {
            var n = this;
            return a(e().mark(function a() {
                var t, s;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return t = o.globalData.screenHeight - o.globalData.safeArea.top - o.globalData.CustomBar - .472 * wx.getSystemInfoSync().windowWidth, 
                        n.setData({
                            listScrollHeight: t,
                            headerTop: "Windows" == n.data.model ? 30 : 4
                        }), e.next = 4, r.getWxUser();

                      case 4:
                        s = e.sent, console.log("teacher onLoad"), console.log(s), 0 == s.lasttype && r.updateUserInfo(JSON.stringify({
                            lasttype: 2
                        }), o.globalData.userInfo.uid);

                      case 8:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        },
        tabChange: function(e) {
            console.log("1111"), this.setData({
                value: e
            }), console.log(e.detail);
        },
        bindViewTap: function() {
            wx.navigateTo({
                url: "../logs/logs"
            });
        },
        onChooseAvatar: function(e) {
            var a = e.detail.avatarUrl, t = this.data.userInfo.nickName;
            this.setData({
                "userInfo.avatarUrl": a,
                hasUserInfo: t && a && a !== n
            });
        },
        onInputChange: function(e) {
            var a = e.detail.value, t = this.data.userInfo.avatarUrl;
            this.setData({
                "userInfo.nickName": a,
                hasUserInfo: a && t && t !== n
            });
        },
        getUserProfile: function(e) {
            var a = this;
            wx.getUserProfile({
                desc: "展示用户信息",
                success: function(e) {
                    console.log(e), a.setData({
                        userInfo: e.userInfo,
                        hasUserInfo: !0
                    });
                }
            });
        }
    }
});